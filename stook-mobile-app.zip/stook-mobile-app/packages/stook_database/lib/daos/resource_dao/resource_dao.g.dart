// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'resource_dao.dart';

// ignore_for_file: type=lint
mixin _$ResourceDaoMixin on DatabaseAccessor<DatabaseContext> {
  $ResourcesTable get resources => attachedDatabase.resources;
}
