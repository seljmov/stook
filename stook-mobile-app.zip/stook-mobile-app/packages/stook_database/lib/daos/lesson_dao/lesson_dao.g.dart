// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'lesson_dao.dart';

// ignore_for_file: type=lint
mixin _$LessonsDaoMixin on DatabaseAccessor<DatabaseContext> {
  $LessonsTable get lessons => attachedDatabase.lessons;
}
