// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'note_dao.dart';

// ignore_for_file: type=lint
mixin _$NoteDaoMixin on DatabaseAccessor<DatabaseContext> {
  $NotesTable get notes => attachedDatabase.notes;
}
