// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database_context.dart';

// ignore_for_file: type=lint
class $LessonsTable extends Lessons with TableInfo<$LessonsTable, Lesson> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $LessonsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _titleMeta = const VerificationMeta('title');
  @override
  late final GeneratedColumn<String> title = GeneratedColumn<String>(
      'title', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _placeMeta = const VerificationMeta('place');
  @override
  late final GeneratedColumn<String> place = GeneratedColumn<String>(
      'place', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _teacherMeta =
      const VerificationMeta('teacher');
  @override
  late final GeneratedColumn<String> teacher = GeneratedColumn<String>(
      'teacher', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _timeStartMeta =
      const VerificationMeta('timeStart');
  @override
  late final GeneratedColumn<DateTime> timeStart = GeneratedColumn<DateTime>(
      'time_start', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _timeEndMeta =
      const VerificationMeta('timeEnd');
  @override
  late final GeneratedColumn<DateTime> timeEnd = GeneratedColumn<DateTime>(
      'time_end', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _weekNumberMeta =
      const VerificationMeta('weekNumber');
  @override
  late final GeneratedColumn<int> weekNumber = GeneratedColumn<int>(
      'week_number', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _dayOfWeekMeta =
      const VerificationMeta('dayOfWeek');
  @override
  late final GeneratedColumnWithTypeConverter<DayOfWeek, int> dayOfWeek =
      GeneratedColumn<int>('day_of_week', aliasedName, false,
              type: DriftSqlType.int, requiredDuringInsert: true)
          .withConverter<DayOfWeek>($LessonsTable.$converterdayOfWeek);
  static const VerificationMeta _lessonTypeMeta =
      const VerificationMeta('lessonType');
  @override
  late final GeneratedColumnWithTypeConverter<LessonType, int> lessonType =
      GeneratedColumn<int>('lesson_type', aliasedName, false,
              type: DriftSqlType.int, requiredDuringInsert: true)
          .withConverter<LessonType>($LessonsTable.$converterlessonType);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        title,
        place,
        teacher,
        timeStart,
        timeEnd,
        weekNumber,
        dayOfWeek,
        lessonType
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'lessons';
  @override
  VerificationContext validateIntegrity(Insertable<Lesson> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('title')) {
      context.handle(
          _titleMeta, title.isAcceptableOrUnknown(data['title']!, _titleMeta));
    } else if (isInserting) {
      context.missing(_titleMeta);
    }
    if (data.containsKey('place')) {
      context.handle(
          _placeMeta, place.isAcceptableOrUnknown(data['place']!, _placeMeta));
    } else if (isInserting) {
      context.missing(_placeMeta);
    }
    if (data.containsKey('teacher')) {
      context.handle(_teacherMeta,
          teacher.isAcceptableOrUnknown(data['teacher']!, _teacherMeta));
    } else if (isInserting) {
      context.missing(_teacherMeta);
    }
    if (data.containsKey('time_start')) {
      context.handle(_timeStartMeta,
          timeStart.isAcceptableOrUnknown(data['time_start']!, _timeStartMeta));
    } else if (isInserting) {
      context.missing(_timeStartMeta);
    }
    if (data.containsKey('time_end')) {
      context.handle(_timeEndMeta,
          timeEnd.isAcceptableOrUnknown(data['time_end']!, _timeEndMeta));
    } else if (isInserting) {
      context.missing(_timeEndMeta);
    }
    if (data.containsKey('week_number')) {
      context.handle(
          _weekNumberMeta,
          weekNumber.isAcceptableOrUnknown(
              data['week_number']!, _weekNumberMeta));
    } else if (isInserting) {
      context.missing(_weekNumberMeta);
    }
    context.handle(_dayOfWeekMeta, const VerificationResult.success());
    context.handle(_lessonTypeMeta, const VerificationResult.success());
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Lesson map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Lesson(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      title: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}title'])!,
      place: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}place'])!,
      teacher: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}teacher'])!,
      timeStart: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}time_start'])!,
      timeEnd: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}time_end'])!,
      weekNumber: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}week_number'])!,
      dayOfWeek: $LessonsTable.$converterdayOfWeek.fromSql(attachedDatabase
          .typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}day_of_week'])!),
      lessonType: $LessonsTable.$converterlessonType.fromSql(attachedDatabase
          .typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}lesson_type'])!),
    );
  }

  @override
  $LessonsTable createAlias(String alias) {
    return $LessonsTable(attachedDatabase, alias);
  }

  static JsonTypeConverter2<DayOfWeek, int, int> $converterdayOfWeek =
      const EnumIndexConverter<DayOfWeek>(DayOfWeek.values);
  static JsonTypeConverter2<LessonType, int, int> $converterlessonType =
      const EnumIndexConverter<LessonType>(LessonType.values);
}

class Lesson extends DataClass implements Insertable<Lesson> {
  /// Идентификатор.
  final int id;

  /// Название.
  final String title;

  /// Место проведения.
  final String place;

  /// Преподаватель.
  final String teacher;

  /// Время начала.
  final DateTime timeStart;

  /// Время окончания.
  final DateTime timeEnd;

  /// Номер недели.
  final int weekNumber;

  /// День недели.
  final DayOfWeek dayOfWeek;

  /// Тип занятия.
  final LessonType lessonType;
  const Lesson(
      {required this.id,
      required this.title,
      required this.place,
      required this.teacher,
      required this.timeStart,
      required this.timeEnd,
      required this.weekNumber,
      required this.dayOfWeek,
      required this.lessonType});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['title'] = Variable<String>(title);
    map['place'] = Variable<String>(place);
    map['teacher'] = Variable<String>(teacher);
    map['time_start'] = Variable<DateTime>(timeStart);
    map['time_end'] = Variable<DateTime>(timeEnd);
    map['week_number'] = Variable<int>(weekNumber);
    {
      map['day_of_week'] =
          Variable<int>($LessonsTable.$converterdayOfWeek.toSql(dayOfWeek));
    }
    {
      map['lesson_type'] =
          Variable<int>($LessonsTable.$converterlessonType.toSql(lessonType));
    }
    return map;
  }

  LessonsCompanion toCompanion(bool nullToAbsent) {
    return LessonsCompanion(
      id: Value(id),
      title: Value(title),
      place: Value(place),
      teacher: Value(teacher),
      timeStart: Value(timeStart),
      timeEnd: Value(timeEnd),
      weekNumber: Value(weekNumber),
      dayOfWeek: Value(dayOfWeek),
      lessonType: Value(lessonType),
    );
  }

  factory Lesson.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Lesson(
      id: serializer.fromJson<int>(json['id']),
      title: serializer.fromJson<String>(json['title']),
      place: serializer.fromJson<String>(json['place']),
      teacher: serializer.fromJson<String>(json['teacher']),
      timeStart: serializer.fromJson<DateTime>(json['timeStart']),
      timeEnd: serializer.fromJson<DateTime>(json['timeEnd']),
      weekNumber: serializer.fromJson<int>(json['weekNumber']),
      dayOfWeek: $LessonsTable.$converterdayOfWeek
          .fromJson(serializer.fromJson<int>(json['dayOfWeek'])),
      lessonType: $LessonsTable.$converterlessonType
          .fromJson(serializer.fromJson<int>(json['lessonType'])),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'title': serializer.toJson<String>(title),
      'place': serializer.toJson<String>(place),
      'teacher': serializer.toJson<String>(teacher),
      'timeStart': serializer.toJson<DateTime>(timeStart),
      'timeEnd': serializer.toJson<DateTime>(timeEnd),
      'weekNumber': serializer.toJson<int>(weekNumber),
      'dayOfWeek': serializer
          .toJson<int>($LessonsTable.$converterdayOfWeek.toJson(dayOfWeek)),
      'lessonType': serializer
          .toJson<int>($LessonsTable.$converterlessonType.toJson(lessonType)),
    };
  }

  Lesson copyWith(
          {int? id,
          String? title,
          String? place,
          String? teacher,
          DateTime? timeStart,
          DateTime? timeEnd,
          int? weekNumber,
          DayOfWeek? dayOfWeek,
          LessonType? lessonType}) =>
      Lesson(
        id: id ?? this.id,
        title: title ?? this.title,
        place: place ?? this.place,
        teacher: teacher ?? this.teacher,
        timeStart: timeStart ?? this.timeStart,
        timeEnd: timeEnd ?? this.timeEnd,
        weekNumber: weekNumber ?? this.weekNumber,
        dayOfWeek: dayOfWeek ?? this.dayOfWeek,
        lessonType: lessonType ?? this.lessonType,
      );
  @override
  String toString() {
    return (StringBuffer('Lesson(')
          ..write('id: $id, ')
          ..write('title: $title, ')
          ..write('place: $place, ')
          ..write('teacher: $teacher, ')
          ..write('timeStart: $timeStart, ')
          ..write('timeEnd: $timeEnd, ')
          ..write('weekNumber: $weekNumber, ')
          ..write('dayOfWeek: $dayOfWeek, ')
          ..write('lessonType: $lessonType')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, title, place, teacher, timeStart, timeEnd,
      weekNumber, dayOfWeek, lessonType);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Lesson &&
          other.id == this.id &&
          other.title == this.title &&
          other.place == this.place &&
          other.teacher == this.teacher &&
          other.timeStart == this.timeStart &&
          other.timeEnd == this.timeEnd &&
          other.weekNumber == this.weekNumber &&
          other.dayOfWeek == this.dayOfWeek &&
          other.lessonType == this.lessonType);
}

class LessonsCompanion extends UpdateCompanion<Lesson> {
  final Value<int> id;
  final Value<String> title;
  final Value<String> place;
  final Value<String> teacher;
  final Value<DateTime> timeStart;
  final Value<DateTime> timeEnd;
  final Value<int> weekNumber;
  final Value<DayOfWeek> dayOfWeek;
  final Value<LessonType> lessonType;
  const LessonsCompanion({
    this.id = const Value.absent(),
    this.title = const Value.absent(),
    this.place = const Value.absent(),
    this.teacher = const Value.absent(),
    this.timeStart = const Value.absent(),
    this.timeEnd = const Value.absent(),
    this.weekNumber = const Value.absent(),
    this.dayOfWeek = const Value.absent(),
    this.lessonType = const Value.absent(),
  });
  LessonsCompanion.insert({
    this.id = const Value.absent(),
    required String title,
    required String place,
    required String teacher,
    required DateTime timeStart,
    required DateTime timeEnd,
    required int weekNumber,
    required DayOfWeek dayOfWeek,
    required LessonType lessonType,
  })  : title = Value(title),
        place = Value(place),
        teacher = Value(teacher),
        timeStart = Value(timeStart),
        timeEnd = Value(timeEnd),
        weekNumber = Value(weekNumber),
        dayOfWeek = Value(dayOfWeek),
        lessonType = Value(lessonType);
  static Insertable<Lesson> custom({
    Expression<int>? id,
    Expression<String>? title,
    Expression<String>? place,
    Expression<String>? teacher,
    Expression<DateTime>? timeStart,
    Expression<DateTime>? timeEnd,
    Expression<int>? weekNumber,
    Expression<int>? dayOfWeek,
    Expression<int>? lessonType,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (title != null) 'title': title,
      if (place != null) 'place': place,
      if (teacher != null) 'teacher': teacher,
      if (timeStart != null) 'time_start': timeStart,
      if (timeEnd != null) 'time_end': timeEnd,
      if (weekNumber != null) 'week_number': weekNumber,
      if (dayOfWeek != null) 'day_of_week': dayOfWeek,
      if (lessonType != null) 'lesson_type': lessonType,
    });
  }

  LessonsCompanion copyWith(
      {Value<int>? id,
      Value<String>? title,
      Value<String>? place,
      Value<String>? teacher,
      Value<DateTime>? timeStart,
      Value<DateTime>? timeEnd,
      Value<int>? weekNumber,
      Value<DayOfWeek>? dayOfWeek,
      Value<LessonType>? lessonType}) {
    return LessonsCompanion(
      id: id ?? this.id,
      title: title ?? this.title,
      place: place ?? this.place,
      teacher: teacher ?? this.teacher,
      timeStart: timeStart ?? this.timeStart,
      timeEnd: timeEnd ?? this.timeEnd,
      weekNumber: weekNumber ?? this.weekNumber,
      dayOfWeek: dayOfWeek ?? this.dayOfWeek,
      lessonType: lessonType ?? this.lessonType,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (title.present) {
      map['title'] = Variable<String>(title.value);
    }
    if (place.present) {
      map['place'] = Variable<String>(place.value);
    }
    if (teacher.present) {
      map['teacher'] = Variable<String>(teacher.value);
    }
    if (timeStart.present) {
      map['time_start'] = Variable<DateTime>(timeStart.value);
    }
    if (timeEnd.present) {
      map['time_end'] = Variable<DateTime>(timeEnd.value);
    }
    if (weekNumber.present) {
      map['week_number'] = Variable<int>(weekNumber.value);
    }
    if (dayOfWeek.present) {
      map['day_of_week'] = Variable<int>(
          $LessonsTable.$converterdayOfWeek.toSql(dayOfWeek.value));
    }
    if (lessonType.present) {
      map['lesson_type'] = Variable<int>(
          $LessonsTable.$converterlessonType.toSql(lessonType.value));
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('LessonsCompanion(')
          ..write('id: $id, ')
          ..write('title: $title, ')
          ..write('place: $place, ')
          ..write('teacher: $teacher, ')
          ..write('timeStart: $timeStart, ')
          ..write('timeEnd: $timeEnd, ')
          ..write('weekNumber: $weekNumber, ')
          ..write('dayOfWeek: $dayOfWeek, ')
          ..write('lessonType: $lessonType')
          ..write(')'))
        .toString();
  }
}

class $TasksTable extends Tasks with TableInfo<$TasksTable, Task> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TasksTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _titleMeta = const VerificationMeta('title');
  @override
  late final GeneratedColumn<String> title = GeneratedColumn<String>(
      'title', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _descriptionMeta =
      const VerificationMeta('description');
  @override
  late final GeneratedColumn<String> description = GeneratedColumn<String>(
      'description', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _createdDateMeta =
      const VerificationMeta('createdDate');
  @override
  late final GeneratedColumn<DateTime> createdDate = GeneratedColumn<DateTime>(
      'created_date', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _deadlineDateMeta =
      const VerificationMeta('deadlineDate');
  @override
  late final GeneratedColumn<DateTime> deadlineDate = GeneratedColumn<DateTime>(
      'deadline_date', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _priorityMeta =
      const VerificationMeta('priority');
  @override
  late final GeneratedColumnWithTypeConverter<TaskPriority?, int> priority =
      GeneratedColumn<int>('priority', aliasedName, true,
              type: DriftSqlType.int, requiredDuringInsert: false)
          .withConverter<TaskPriority?>($TasksTable.$converterpriorityn);
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumnWithTypeConverter<TaskStatus, int> status =
      GeneratedColumn<int>('status', aliasedName, false,
              type: DriftSqlType.int, requiredDuringInsert: true)
          .withConverter<TaskStatus>($TasksTable.$converterstatus);
  @override
  List<GeneratedColumn> get $columns =>
      [id, title, description, createdDate, deadlineDate, priority, status];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tasks';
  @override
  VerificationContext validateIntegrity(Insertable<Task> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('title')) {
      context.handle(
          _titleMeta, title.isAcceptableOrUnknown(data['title']!, _titleMeta));
    } else if (isInserting) {
      context.missing(_titleMeta);
    }
    if (data.containsKey('description')) {
      context.handle(
          _descriptionMeta,
          description.isAcceptableOrUnknown(
              data['description']!, _descriptionMeta));
    } else if (isInserting) {
      context.missing(_descriptionMeta);
    }
    if (data.containsKey('created_date')) {
      context.handle(
          _createdDateMeta,
          createdDate.isAcceptableOrUnknown(
              data['created_date']!, _createdDateMeta));
    }
    if (data.containsKey('deadline_date')) {
      context.handle(
          _deadlineDateMeta,
          deadlineDate.isAcceptableOrUnknown(
              data['deadline_date']!, _deadlineDateMeta));
    }
    context.handle(_priorityMeta, const VerificationResult.success());
    context.handle(_statusMeta, const VerificationResult.success());
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Task map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Task(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      title: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}title'])!,
      description: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}description'])!,
      createdDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_date']),
      deadlineDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}deadline_date']),
      priority: $TasksTable.$converterpriorityn.fromSql(attachedDatabase
          .typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}priority'])),
      status: $TasksTable.$converterstatus.fromSql(attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}status'])!),
    );
  }

  @override
  $TasksTable createAlias(String alias) {
    return $TasksTable(attachedDatabase, alias);
  }

  static JsonTypeConverter2<TaskPriority, int, int> $converterpriority =
      const EnumIndexConverter<TaskPriority>(TaskPriority.values);
  static JsonTypeConverter2<TaskPriority?, int?, int?> $converterpriorityn =
      JsonTypeConverter2.asNullable($converterpriority);
  static JsonTypeConverter2<TaskStatus, int, int> $converterstatus =
      const EnumIndexConverter<TaskStatus>(TaskStatus.values);
}

class Task extends DataClass implements Insertable<Task> {
  /// Идентификатор.
  final int id;

  /// Название.
  final String title;

  /// Описание.
  final String description;

  /// Дата создания.
  final DateTime? createdDate;

  /// Дата последнего изменения.
  final DateTime? deadlineDate;

  /// Приоритет.
  final TaskPriority? priority;

  /// Статус.
  final TaskStatus status;
  const Task(
      {required this.id,
      required this.title,
      required this.description,
      this.createdDate,
      this.deadlineDate,
      this.priority,
      required this.status});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['title'] = Variable<String>(title);
    map['description'] = Variable<String>(description);
    if (!nullToAbsent || createdDate != null) {
      map['created_date'] = Variable<DateTime>(createdDate);
    }
    if (!nullToAbsent || deadlineDate != null) {
      map['deadline_date'] = Variable<DateTime>(deadlineDate);
    }
    if (!nullToAbsent || priority != null) {
      map['priority'] =
          Variable<int>($TasksTable.$converterpriorityn.toSql(priority));
    }
    {
      map['status'] = Variable<int>($TasksTable.$converterstatus.toSql(status));
    }
    return map;
  }

  TasksCompanion toCompanion(bool nullToAbsent) {
    return TasksCompanion(
      id: Value(id),
      title: Value(title),
      description: Value(description),
      createdDate: createdDate == null && nullToAbsent
          ? const Value.absent()
          : Value(createdDate),
      deadlineDate: deadlineDate == null && nullToAbsent
          ? const Value.absent()
          : Value(deadlineDate),
      priority: priority == null && nullToAbsent
          ? const Value.absent()
          : Value(priority),
      status: Value(status),
    );
  }

  factory Task.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Task(
      id: serializer.fromJson<int>(json['id']),
      title: serializer.fromJson<String>(json['title']),
      description: serializer.fromJson<String>(json['description']),
      createdDate: serializer.fromJson<DateTime?>(json['createdDate']),
      deadlineDate: serializer.fromJson<DateTime?>(json['deadlineDate']),
      priority: $TasksTable.$converterpriorityn
          .fromJson(serializer.fromJson<int?>(json['priority'])),
      status: $TasksTable.$converterstatus
          .fromJson(serializer.fromJson<int>(json['status'])),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'title': serializer.toJson<String>(title),
      'description': serializer.toJson<String>(description),
      'createdDate': serializer.toJson<DateTime?>(createdDate),
      'deadlineDate': serializer.toJson<DateTime?>(deadlineDate),
      'priority': serializer
          .toJson<int?>($TasksTable.$converterpriorityn.toJson(priority)),
      'status':
          serializer.toJson<int>($TasksTable.$converterstatus.toJson(status)),
    };
  }

  Task copyWith(
          {int? id,
          String? title,
          String? description,
          Value<DateTime?> createdDate = const Value.absent(),
          Value<DateTime?> deadlineDate = const Value.absent(),
          Value<TaskPriority?> priority = const Value.absent(),
          TaskStatus? status}) =>
      Task(
        id: id ?? this.id,
        title: title ?? this.title,
        description: description ?? this.description,
        createdDate: createdDate.present ? createdDate.value : this.createdDate,
        deadlineDate:
            deadlineDate.present ? deadlineDate.value : this.deadlineDate,
        priority: priority.present ? priority.value : this.priority,
        status: status ?? this.status,
      );
  @override
  String toString() {
    return (StringBuffer('Task(')
          ..write('id: $id, ')
          ..write('title: $title, ')
          ..write('description: $description, ')
          ..write('createdDate: $createdDate, ')
          ..write('deadlineDate: $deadlineDate, ')
          ..write('priority: $priority, ')
          ..write('status: $status')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, title, description, createdDate, deadlineDate, priority, status);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Task &&
          other.id == this.id &&
          other.title == this.title &&
          other.description == this.description &&
          other.createdDate == this.createdDate &&
          other.deadlineDate == this.deadlineDate &&
          other.priority == this.priority &&
          other.status == this.status);
}

class TasksCompanion extends UpdateCompanion<Task> {
  final Value<int> id;
  final Value<String> title;
  final Value<String> description;
  final Value<DateTime?> createdDate;
  final Value<DateTime?> deadlineDate;
  final Value<TaskPriority?> priority;
  final Value<TaskStatus> status;
  const TasksCompanion({
    this.id = const Value.absent(),
    this.title = const Value.absent(),
    this.description = const Value.absent(),
    this.createdDate = const Value.absent(),
    this.deadlineDate = const Value.absent(),
    this.priority = const Value.absent(),
    this.status = const Value.absent(),
  });
  TasksCompanion.insert({
    this.id = const Value.absent(),
    required String title,
    required String description,
    this.createdDate = const Value.absent(),
    this.deadlineDate = const Value.absent(),
    this.priority = const Value.absent(),
    required TaskStatus status,
  })  : title = Value(title),
        description = Value(description),
        status = Value(status);
  static Insertable<Task> custom({
    Expression<int>? id,
    Expression<String>? title,
    Expression<String>? description,
    Expression<DateTime>? createdDate,
    Expression<DateTime>? deadlineDate,
    Expression<int>? priority,
    Expression<int>? status,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (title != null) 'title': title,
      if (description != null) 'description': description,
      if (createdDate != null) 'created_date': createdDate,
      if (deadlineDate != null) 'deadline_date': deadlineDate,
      if (priority != null) 'priority': priority,
      if (status != null) 'status': status,
    });
  }

  TasksCompanion copyWith(
      {Value<int>? id,
      Value<String>? title,
      Value<String>? description,
      Value<DateTime?>? createdDate,
      Value<DateTime?>? deadlineDate,
      Value<TaskPriority?>? priority,
      Value<TaskStatus>? status}) {
    return TasksCompanion(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      createdDate: createdDate ?? this.createdDate,
      deadlineDate: deadlineDate ?? this.deadlineDate,
      priority: priority ?? this.priority,
      status: status ?? this.status,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (title.present) {
      map['title'] = Variable<String>(title.value);
    }
    if (description.present) {
      map['description'] = Variable<String>(description.value);
    }
    if (createdDate.present) {
      map['created_date'] = Variable<DateTime>(createdDate.value);
    }
    if (deadlineDate.present) {
      map['deadline_date'] = Variable<DateTime>(deadlineDate.value);
    }
    if (priority.present) {
      map['priority'] =
          Variable<int>($TasksTable.$converterpriorityn.toSql(priority.value));
    }
    if (status.present) {
      map['status'] =
          Variable<int>($TasksTable.$converterstatus.toSql(status.value));
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TasksCompanion(')
          ..write('id: $id, ')
          ..write('title: $title, ')
          ..write('description: $description, ')
          ..write('createdDate: $createdDate, ')
          ..write('deadlineDate: $deadlineDate, ')
          ..write('priority: $priority, ')
          ..write('status: $status')
          ..write(')'))
        .toString();
  }
}

class $ResourcesTable extends Resources
    with TableInfo<$ResourcesTable, Resource> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ResourcesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _titleMeta = const VerificationMeta('title');
  @override
  late final GeneratedColumn<String> title = GeneratedColumn<String>(
      'title', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _descriptionMeta =
      const VerificationMeta('description');
  @override
  late final GeneratedColumn<String> description = GeneratedColumn<String>(
      'description', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _urlMeta = const VerificationMeta('url');
  @override
  late final GeneratedColumn<String> url = GeneratedColumn<String>(
      'url', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _typeMeta = const VerificationMeta('type');
  @override
  late final GeneratedColumnWithTypeConverter<ResourceType, int> type =
      GeneratedColumn<int>('type', aliasedName, false,
              type: DriftSqlType.int, requiredDuringInsert: true)
          .withConverter<ResourceType>($ResourcesTable.$convertertype);
  static const VerificationMeta _createdDateMeta =
      const VerificationMeta('createdDate');
  @override
  late final GeneratedColumn<DateTime> createdDate = GeneratedColumn<DateTime>(
      'created_date', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  static const VerificationMeta _isFavoriteMeta =
      const VerificationMeta('isFavorite');
  @override
  late final GeneratedColumn<bool> isFavorite = GeneratedColumn<bool>(
      'is_favorite', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_favorite" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns =>
      [id, title, description, url, type, createdDate, isFavorite];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'resources';
  @override
  VerificationContext validateIntegrity(Insertable<Resource> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('title')) {
      context.handle(
          _titleMeta, title.isAcceptableOrUnknown(data['title']!, _titleMeta));
    } else if (isInserting) {
      context.missing(_titleMeta);
    }
    if (data.containsKey('description')) {
      context.handle(
          _descriptionMeta,
          description.isAcceptableOrUnknown(
              data['description']!, _descriptionMeta));
    }
    if (data.containsKey('url')) {
      context.handle(
          _urlMeta, url.isAcceptableOrUnknown(data['url']!, _urlMeta));
    }
    context.handle(_typeMeta, const VerificationResult.success());
    if (data.containsKey('created_date')) {
      context.handle(
          _createdDateMeta,
          createdDate.isAcceptableOrUnknown(
              data['created_date']!, _createdDateMeta));
    }
    if (data.containsKey('is_favorite')) {
      context.handle(
          _isFavoriteMeta,
          isFavorite.isAcceptableOrUnknown(
              data['is_favorite']!, _isFavoriteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Resource map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Resource(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      title: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}title'])!,
      description: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}description']),
      url: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}url']),
      type: $ResourcesTable.$convertertype.fromSql(attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}type'])!),
      createdDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_date'])!,
      isFavorite: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_favorite'])!,
    );
  }

  @override
  $ResourcesTable createAlias(String alias) {
    return $ResourcesTable(attachedDatabase, alias);
  }

  static JsonTypeConverter2<ResourceType, int, int> $convertertype =
      const EnumIndexConverter<ResourceType>(ResourceType.values);
}

class Resource extends DataClass implements Insertable<Resource> {
  /// Идентификатор.
  final int id;

  /// Название.
  final String title;

  /// Описание.
  final String? description;

  /// URL.
  final String? url;

  /// Тип ресурса.
  final ResourceType type;

  /// Дата создания.
  final DateTime createdDate;

  /// Признак избранного ресурса.
  final bool isFavorite;
  const Resource(
      {required this.id,
      required this.title,
      this.description,
      this.url,
      required this.type,
      required this.createdDate,
      required this.isFavorite});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['title'] = Variable<String>(title);
    if (!nullToAbsent || description != null) {
      map['description'] = Variable<String>(description);
    }
    if (!nullToAbsent || url != null) {
      map['url'] = Variable<String>(url);
    }
    {
      map['type'] = Variable<int>($ResourcesTable.$convertertype.toSql(type));
    }
    map['created_date'] = Variable<DateTime>(createdDate);
    map['is_favorite'] = Variable<bool>(isFavorite);
    return map;
  }

  ResourcesCompanion toCompanion(bool nullToAbsent) {
    return ResourcesCompanion(
      id: Value(id),
      title: Value(title),
      description: description == null && nullToAbsent
          ? const Value.absent()
          : Value(description),
      url: url == null && nullToAbsent ? const Value.absent() : Value(url),
      type: Value(type),
      createdDate: Value(createdDate),
      isFavorite: Value(isFavorite),
    );
  }

  factory Resource.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Resource(
      id: serializer.fromJson<int>(json['id']),
      title: serializer.fromJson<String>(json['title']),
      description: serializer.fromJson<String?>(json['description']),
      url: serializer.fromJson<String?>(json['url']),
      type: $ResourcesTable.$convertertype
          .fromJson(serializer.fromJson<int>(json['type'])),
      createdDate: serializer.fromJson<DateTime>(json['createdDate']),
      isFavorite: serializer.fromJson<bool>(json['isFavorite']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'title': serializer.toJson<String>(title),
      'description': serializer.toJson<String?>(description),
      'url': serializer.toJson<String?>(url),
      'type':
          serializer.toJson<int>($ResourcesTable.$convertertype.toJson(type)),
      'createdDate': serializer.toJson<DateTime>(createdDate),
      'isFavorite': serializer.toJson<bool>(isFavorite),
    };
  }

  Resource copyWith(
          {int? id,
          String? title,
          Value<String?> description = const Value.absent(),
          Value<String?> url = const Value.absent(),
          ResourceType? type,
          DateTime? createdDate,
          bool? isFavorite}) =>
      Resource(
        id: id ?? this.id,
        title: title ?? this.title,
        description: description.present ? description.value : this.description,
        url: url.present ? url.value : this.url,
        type: type ?? this.type,
        createdDate: createdDate ?? this.createdDate,
        isFavorite: isFavorite ?? this.isFavorite,
      );
  @override
  String toString() {
    return (StringBuffer('Resource(')
          ..write('id: $id, ')
          ..write('title: $title, ')
          ..write('description: $description, ')
          ..write('url: $url, ')
          ..write('type: $type, ')
          ..write('createdDate: $createdDate, ')
          ..write('isFavorite: $isFavorite')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, title, description, url, type, createdDate, isFavorite);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Resource &&
          other.id == this.id &&
          other.title == this.title &&
          other.description == this.description &&
          other.url == this.url &&
          other.type == this.type &&
          other.createdDate == this.createdDate &&
          other.isFavorite == this.isFavorite);
}

class ResourcesCompanion extends UpdateCompanion<Resource> {
  final Value<int> id;
  final Value<String> title;
  final Value<String?> description;
  final Value<String?> url;
  final Value<ResourceType> type;
  final Value<DateTime> createdDate;
  final Value<bool> isFavorite;
  const ResourcesCompanion({
    this.id = const Value.absent(),
    this.title = const Value.absent(),
    this.description = const Value.absent(),
    this.url = const Value.absent(),
    this.type = const Value.absent(),
    this.createdDate = const Value.absent(),
    this.isFavorite = const Value.absent(),
  });
  ResourcesCompanion.insert({
    this.id = const Value.absent(),
    required String title,
    this.description = const Value.absent(),
    this.url = const Value.absent(),
    required ResourceType type,
    this.createdDate = const Value.absent(),
    this.isFavorite = const Value.absent(),
  })  : title = Value(title),
        type = Value(type);
  static Insertable<Resource> custom({
    Expression<int>? id,
    Expression<String>? title,
    Expression<String>? description,
    Expression<String>? url,
    Expression<int>? type,
    Expression<DateTime>? createdDate,
    Expression<bool>? isFavorite,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (title != null) 'title': title,
      if (description != null) 'description': description,
      if (url != null) 'url': url,
      if (type != null) 'type': type,
      if (createdDate != null) 'created_date': createdDate,
      if (isFavorite != null) 'is_favorite': isFavorite,
    });
  }

  ResourcesCompanion copyWith(
      {Value<int>? id,
      Value<String>? title,
      Value<String?>? description,
      Value<String?>? url,
      Value<ResourceType>? type,
      Value<DateTime>? createdDate,
      Value<bool>? isFavorite}) {
    return ResourcesCompanion(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      url: url ?? this.url,
      type: type ?? this.type,
      createdDate: createdDate ?? this.createdDate,
      isFavorite: isFavorite ?? this.isFavorite,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (title.present) {
      map['title'] = Variable<String>(title.value);
    }
    if (description.present) {
      map['description'] = Variable<String>(description.value);
    }
    if (url.present) {
      map['url'] = Variable<String>(url.value);
    }
    if (type.present) {
      map['type'] =
          Variable<int>($ResourcesTable.$convertertype.toSql(type.value));
    }
    if (createdDate.present) {
      map['created_date'] = Variable<DateTime>(createdDate.value);
    }
    if (isFavorite.present) {
      map['is_favorite'] = Variable<bool>(isFavorite.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ResourcesCompanion(')
          ..write('id: $id, ')
          ..write('title: $title, ')
          ..write('description: $description, ')
          ..write('url: $url, ')
          ..write('type: $type, ')
          ..write('createdDate: $createdDate, ')
          ..write('isFavorite: $isFavorite')
          ..write(')'))
        .toString();
  }
}

class $NotesTable extends Notes with TableInfo<$NotesTable, Note> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $NotesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _titleMeta = const VerificationMeta('title');
  @override
  late final GeneratedColumn<String> title = GeneratedColumn<String>(
      'title', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _contentMeta =
      const VerificationMeta('content');
  @override
  late final GeneratedColumn<String> content = GeneratedColumn<String>(
      'content', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _createdDateMeta =
      const VerificationMeta('createdDate');
  @override
  late final GeneratedColumn<DateTime> createdDate = GeneratedColumn<DateTime>(
      'created_date', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  static const VerificationMeta _lastModifiedDateMeta =
      const VerificationMeta('lastModifiedDate');
  @override
  late final GeneratedColumn<DateTime> lastModifiedDate =
      GeneratedColumn<DateTime>('last_modified_date', aliasedName, false,
          type: DriftSqlType.dateTime,
          requiredDuringInsert: false,
          defaultValue: currentDateAndTime);
  static const VerificationMeta _isFavoriteMeta =
      const VerificationMeta('isFavorite');
  @override
  late final GeneratedColumn<bool> isFavorite = GeneratedColumn<bool>(
      'is_favorite', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_favorite" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns =>
      [id, title, content, createdDate, lastModifiedDate, isFavorite];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'notes';
  @override
  VerificationContext validateIntegrity(Insertable<Note> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('title')) {
      context.handle(
          _titleMeta, title.isAcceptableOrUnknown(data['title']!, _titleMeta));
    } else if (isInserting) {
      context.missing(_titleMeta);
    }
    if (data.containsKey('content')) {
      context.handle(_contentMeta,
          content.isAcceptableOrUnknown(data['content']!, _contentMeta));
    } else if (isInserting) {
      context.missing(_contentMeta);
    }
    if (data.containsKey('created_date')) {
      context.handle(
          _createdDateMeta,
          createdDate.isAcceptableOrUnknown(
              data['created_date']!, _createdDateMeta));
    }
    if (data.containsKey('last_modified_date')) {
      context.handle(
          _lastModifiedDateMeta,
          lastModifiedDate.isAcceptableOrUnknown(
              data['last_modified_date']!, _lastModifiedDateMeta));
    }
    if (data.containsKey('is_favorite')) {
      context.handle(
          _isFavoriteMeta,
          isFavorite.isAcceptableOrUnknown(
              data['is_favorite']!, _isFavoriteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Note map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Note(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      title: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}title'])!,
      content: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}content'])!,
      createdDate: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_date'])!,
      lastModifiedDate: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}last_modified_date'])!,
      isFavorite: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_favorite'])!,
    );
  }

  @override
  $NotesTable createAlias(String alias) {
    return $NotesTable(attachedDatabase, alias);
  }
}

class Note extends DataClass implements Insertable<Note> {
  /// Идентификатор.
  final int id;

  /// Название.
  final String title;

  /// Содержимое.
  final String content;

  /// Дата создания.
  final DateTime createdDate;

  /// Дата последнего изменения.
  final DateTime lastModifiedDate;

  /// Признак избранной заметки.
  final bool isFavorite;
  const Note(
      {required this.id,
      required this.title,
      required this.content,
      required this.createdDate,
      required this.lastModifiedDate,
      required this.isFavorite});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['title'] = Variable<String>(title);
    map['content'] = Variable<String>(content);
    map['created_date'] = Variable<DateTime>(createdDate);
    map['last_modified_date'] = Variable<DateTime>(lastModifiedDate);
    map['is_favorite'] = Variable<bool>(isFavorite);
    return map;
  }

  NotesCompanion toCompanion(bool nullToAbsent) {
    return NotesCompanion(
      id: Value(id),
      title: Value(title),
      content: Value(content),
      createdDate: Value(createdDate),
      lastModifiedDate: Value(lastModifiedDate),
      isFavorite: Value(isFavorite),
    );
  }

  factory Note.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Note(
      id: serializer.fromJson<int>(json['id']),
      title: serializer.fromJson<String>(json['title']),
      content: serializer.fromJson<String>(json['content']),
      createdDate: serializer.fromJson<DateTime>(json['createdDate']),
      lastModifiedDate: serializer.fromJson<DateTime>(json['lastModifiedDate']),
      isFavorite: serializer.fromJson<bool>(json['isFavorite']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'title': serializer.toJson<String>(title),
      'content': serializer.toJson<String>(content),
      'createdDate': serializer.toJson<DateTime>(createdDate),
      'lastModifiedDate': serializer.toJson<DateTime>(lastModifiedDate),
      'isFavorite': serializer.toJson<bool>(isFavorite),
    };
  }

  Note copyWith(
          {int? id,
          String? title,
          String? content,
          DateTime? createdDate,
          DateTime? lastModifiedDate,
          bool? isFavorite}) =>
      Note(
        id: id ?? this.id,
        title: title ?? this.title,
        content: content ?? this.content,
        createdDate: createdDate ?? this.createdDate,
        lastModifiedDate: lastModifiedDate ?? this.lastModifiedDate,
        isFavorite: isFavorite ?? this.isFavorite,
      );
  @override
  String toString() {
    return (StringBuffer('Note(')
          ..write('id: $id, ')
          ..write('title: $title, ')
          ..write('content: $content, ')
          ..write('createdDate: $createdDate, ')
          ..write('lastModifiedDate: $lastModifiedDate, ')
          ..write('isFavorite: $isFavorite')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, title, content, createdDate, lastModifiedDate, isFavorite);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Note &&
          other.id == this.id &&
          other.title == this.title &&
          other.content == this.content &&
          other.createdDate == this.createdDate &&
          other.lastModifiedDate == this.lastModifiedDate &&
          other.isFavorite == this.isFavorite);
}

class NotesCompanion extends UpdateCompanion<Note> {
  final Value<int> id;
  final Value<String> title;
  final Value<String> content;
  final Value<DateTime> createdDate;
  final Value<DateTime> lastModifiedDate;
  final Value<bool> isFavorite;
  const NotesCompanion({
    this.id = const Value.absent(),
    this.title = const Value.absent(),
    this.content = const Value.absent(),
    this.createdDate = const Value.absent(),
    this.lastModifiedDate = const Value.absent(),
    this.isFavorite = const Value.absent(),
  });
  NotesCompanion.insert({
    this.id = const Value.absent(),
    required String title,
    required String content,
    this.createdDate = const Value.absent(),
    this.lastModifiedDate = const Value.absent(),
    this.isFavorite = const Value.absent(),
  })  : title = Value(title),
        content = Value(content);
  static Insertable<Note> custom({
    Expression<int>? id,
    Expression<String>? title,
    Expression<String>? content,
    Expression<DateTime>? createdDate,
    Expression<DateTime>? lastModifiedDate,
    Expression<bool>? isFavorite,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (title != null) 'title': title,
      if (content != null) 'content': content,
      if (createdDate != null) 'created_date': createdDate,
      if (lastModifiedDate != null) 'last_modified_date': lastModifiedDate,
      if (isFavorite != null) 'is_favorite': isFavorite,
    });
  }

  NotesCompanion copyWith(
      {Value<int>? id,
      Value<String>? title,
      Value<String>? content,
      Value<DateTime>? createdDate,
      Value<DateTime>? lastModifiedDate,
      Value<bool>? isFavorite}) {
    return NotesCompanion(
      id: id ?? this.id,
      title: title ?? this.title,
      content: content ?? this.content,
      createdDate: createdDate ?? this.createdDate,
      lastModifiedDate: lastModifiedDate ?? this.lastModifiedDate,
      isFavorite: isFavorite ?? this.isFavorite,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (title.present) {
      map['title'] = Variable<String>(title.value);
    }
    if (content.present) {
      map['content'] = Variable<String>(content.value);
    }
    if (createdDate.present) {
      map['created_date'] = Variable<DateTime>(createdDate.value);
    }
    if (lastModifiedDate.present) {
      map['last_modified_date'] = Variable<DateTime>(lastModifiedDate.value);
    }
    if (isFavorite.present) {
      map['is_favorite'] = Variable<bool>(isFavorite.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('NotesCompanion(')
          ..write('id: $id, ')
          ..write('title: $title, ')
          ..write('content: $content, ')
          ..write('createdDate: $createdDate, ')
          ..write('lastModifiedDate: $lastModifiedDate, ')
          ..write('isFavorite: $isFavorite')
          ..write(')'))
        .toString();
  }
}

class $SchedulesTable extends Schedules
    with TableInfo<$SchedulesTable, Schedule> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SchedulesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _titleMeta = const VerificationMeta('title');
  @override
  late final GeneratedColumn<String> title = GeneratedColumn<String>(
      'title', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _isActiveMeta =
      const VerificationMeta('isActive');
  @override
  late final GeneratedColumn<bool> isActive = GeneratedColumn<bool>(
      'is_active', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_active" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns => [id, title, isActive];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'schedules';
  @override
  VerificationContext validateIntegrity(Insertable<Schedule> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('title')) {
      context.handle(
          _titleMeta, title.isAcceptableOrUnknown(data['title']!, _titleMeta));
    } else if (isInserting) {
      context.missing(_titleMeta);
    }
    if (data.containsKey('is_active')) {
      context.handle(_isActiveMeta,
          isActive.isAcceptableOrUnknown(data['is_active']!, _isActiveMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Schedule map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Schedule(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      title: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}title'])!,
      isActive: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_active'])!,
    );
  }

  @override
  $SchedulesTable createAlias(String alias) {
    return $SchedulesTable(attachedDatabase, alias);
  }
}

class Schedule extends DataClass implements Insertable<Schedule> {
  /// Идентификатор.
  final int id;

  /// Название.
  final String title;

  /// Признак активности.
  final bool isActive;
  const Schedule(
      {required this.id, required this.title, required this.isActive});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['title'] = Variable<String>(title);
    map['is_active'] = Variable<bool>(isActive);
    return map;
  }

  SchedulesCompanion toCompanion(bool nullToAbsent) {
    return SchedulesCompanion(
      id: Value(id),
      title: Value(title),
      isActive: Value(isActive),
    );
  }

  factory Schedule.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Schedule(
      id: serializer.fromJson<int>(json['id']),
      title: serializer.fromJson<String>(json['title']),
      isActive: serializer.fromJson<bool>(json['isActive']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'title': serializer.toJson<String>(title),
      'isActive': serializer.toJson<bool>(isActive),
    };
  }

  Schedule copyWith({int? id, String? title, bool? isActive}) => Schedule(
        id: id ?? this.id,
        title: title ?? this.title,
        isActive: isActive ?? this.isActive,
      );
  @override
  String toString() {
    return (StringBuffer('Schedule(')
          ..write('id: $id, ')
          ..write('title: $title, ')
          ..write('isActive: $isActive')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, title, isActive);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Schedule &&
          other.id == this.id &&
          other.title == this.title &&
          other.isActive == this.isActive);
}

class SchedulesCompanion extends UpdateCompanion<Schedule> {
  final Value<int> id;
  final Value<String> title;
  final Value<bool> isActive;
  const SchedulesCompanion({
    this.id = const Value.absent(),
    this.title = const Value.absent(),
    this.isActive = const Value.absent(),
  });
  SchedulesCompanion.insert({
    this.id = const Value.absent(),
    required String title,
    this.isActive = const Value.absent(),
  }) : title = Value(title);
  static Insertable<Schedule> custom({
    Expression<int>? id,
    Expression<String>? title,
    Expression<bool>? isActive,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (title != null) 'title': title,
      if (isActive != null) 'is_active': isActive,
    });
  }

  SchedulesCompanion copyWith(
      {Value<int>? id, Value<String>? title, Value<bool>? isActive}) {
    return SchedulesCompanion(
      id: id ?? this.id,
      title: title ?? this.title,
      isActive: isActive ?? this.isActive,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (title.present) {
      map['title'] = Variable<String>(title.value);
    }
    if (isActive.present) {
      map['is_active'] = Variable<bool>(isActive.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SchedulesCompanion(')
          ..write('id: $id, ')
          ..write('title: $title, ')
          ..write('isActive: $isActive')
          ..write(')'))
        .toString();
  }
}

class $TaskSubtaskRelationsTable extends TaskSubtaskRelations
    with TableInfo<$TaskSubtaskRelationsTable, TaskSubtaskRelation> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TaskSubtaskRelationsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _taskIdMeta = const VerificationMeta('taskId');
  @override
  late final GeneratedColumn<int> taskId = GeneratedColumn<int>(
      'task_id', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _subtaskIdMeta =
      const VerificationMeta('subtaskId');
  @override
  late final GeneratedColumn<int> subtaskId = GeneratedColumn<int>(
      'subtask_id', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns => [id, taskId, subtaskId];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'task_subtask_relations';
  @override
  VerificationContext validateIntegrity(
      Insertable<TaskSubtaskRelation> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('task_id')) {
      context.handle(_taskIdMeta,
          taskId.isAcceptableOrUnknown(data['task_id']!, _taskIdMeta));
    } else if (isInserting) {
      context.missing(_taskIdMeta);
    }
    if (data.containsKey('subtask_id')) {
      context.handle(_subtaskIdMeta,
          subtaskId.isAcceptableOrUnknown(data['subtask_id']!, _subtaskIdMeta));
    } else if (isInserting) {
      context.missing(_subtaskIdMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TaskSubtaskRelation map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TaskSubtaskRelation(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      taskId: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}task_id'])!,
      subtaskId: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}subtask_id'])!,
    );
  }

  @override
  $TaskSubtaskRelationsTable createAlias(String alias) {
    return $TaskSubtaskRelationsTable(attachedDatabase, alias);
  }
}

class TaskSubtaskRelation extends DataClass
    implements Insertable<TaskSubtaskRelation> {
  /// Идентификатор.
  final int id;

  /// Идентификатор задачи.
  final int taskId;

  /// Идентификатор подзадачи.
  final int subtaskId;
  const TaskSubtaskRelation(
      {required this.id, required this.taskId, required this.subtaskId});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['task_id'] = Variable<int>(taskId);
    map['subtask_id'] = Variable<int>(subtaskId);
    return map;
  }

  TaskSubtaskRelationsCompanion toCompanion(bool nullToAbsent) {
    return TaskSubtaskRelationsCompanion(
      id: Value(id),
      taskId: Value(taskId),
      subtaskId: Value(subtaskId),
    );
  }

  factory TaskSubtaskRelation.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TaskSubtaskRelation(
      id: serializer.fromJson<int>(json['id']),
      taskId: serializer.fromJson<int>(json['taskId']),
      subtaskId: serializer.fromJson<int>(json['subtaskId']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'taskId': serializer.toJson<int>(taskId),
      'subtaskId': serializer.toJson<int>(subtaskId),
    };
  }

  TaskSubtaskRelation copyWith({int? id, int? taskId, int? subtaskId}) =>
      TaskSubtaskRelation(
        id: id ?? this.id,
        taskId: taskId ?? this.taskId,
        subtaskId: subtaskId ?? this.subtaskId,
      );
  @override
  String toString() {
    return (StringBuffer('TaskSubtaskRelation(')
          ..write('id: $id, ')
          ..write('taskId: $taskId, ')
          ..write('subtaskId: $subtaskId')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, taskId, subtaskId);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TaskSubtaskRelation &&
          other.id == this.id &&
          other.taskId == this.taskId &&
          other.subtaskId == this.subtaskId);
}

class TaskSubtaskRelationsCompanion
    extends UpdateCompanion<TaskSubtaskRelation> {
  final Value<int> id;
  final Value<int> taskId;
  final Value<int> subtaskId;
  const TaskSubtaskRelationsCompanion({
    this.id = const Value.absent(),
    this.taskId = const Value.absent(),
    this.subtaskId = const Value.absent(),
  });
  TaskSubtaskRelationsCompanion.insert({
    this.id = const Value.absent(),
    required int taskId,
    required int subtaskId,
  })  : taskId = Value(taskId),
        subtaskId = Value(subtaskId);
  static Insertable<TaskSubtaskRelation> custom({
    Expression<int>? id,
    Expression<int>? taskId,
    Expression<int>? subtaskId,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (taskId != null) 'task_id': taskId,
      if (subtaskId != null) 'subtask_id': subtaskId,
    });
  }

  TaskSubtaskRelationsCompanion copyWith(
      {Value<int>? id, Value<int>? taskId, Value<int>? subtaskId}) {
    return TaskSubtaskRelationsCompanion(
      id: id ?? this.id,
      taskId: taskId ?? this.taskId,
      subtaskId: subtaskId ?? this.subtaskId,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (taskId.present) {
      map['task_id'] = Variable<int>(taskId.value);
    }
    if (subtaskId.present) {
      map['subtask_id'] = Variable<int>(subtaskId.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TaskSubtaskRelationsCompanion(')
          ..write('id: $id, ')
          ..write('taskId: $taskId, ')
          ..write('subtaskId: $subtaskId')
          ..write(')'))
        .toString();
  }
}

class $TaskDependOnRelationsTable extends TaskDependOnRelations
    with TableInfo<$TaskDependOnRelationsTable, TaskDependOnRelation> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TaskDependOnRelationsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _taskIdMeta = const VerificationMeta('taskId');
  @override
  late final GeneratedColumn<int> taskId = GeneratedColumn<int>(
      'task_id', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _dependOnTaskIdMeta =
      const VerificationMeta('dependOnTaskId');
  @override
  late final GeneratedColumn<int> dependOnTaskId = GeneratedColumn<int>(
      'depend_on_task_id', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns => [id, taskId, dependOnTaskId];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'task_depend_on_relations';
  @override
  VerificationContext validateIntegrity(
      Insertable<TaskDependOnRelation> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('task_id')) {
      context.handle(_taskIdMeta,
          taskId.isAcceptableOrUnknown(data['task_id']!, _taskIdMeta));
    } else if (isInserting) {
      context.missing(_taskIdMeta);
    }
    if (data.containsKey('depend_on_task_id')) {
      context.handle(
          _dependOnTaskIdMeta,
          dependOnTaskId.isAcceptableOrUnknown(
              data['depend_on_task_id']!, _dependOnTaskIdMeta));
    } else if (isInserting) {
      context.missing(_dependOnTaskIdMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TaskDependOnRelation map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TaskDependOnRelation(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      taskId: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}task_id'])!,
      dependOnTaskId: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}depend_on_task_id'])!,
    );
  }

  @override
  $TaskDependOnRelationsTable createAlias(String alias) {
    return $TaskDependOnRelationsTable(attachedDatabase, alias);
  }
}

class TaskDependOnRelation extends DataClass
    implements Insertable<TaskDependOnRelation> {
  /// Идентификатор.
  final int id;

  /// Идентификатор задачи.
  final int taskId;

  /// Идентификатор зависимой задачи.
  final int dependOnTaskId;
  const TaskDependOnRelation(
      {required this.id, required this.taskId, required this.dependOnTaskId});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['task_id'] = Variable<int>(taskId);
    map['depend_on_task_id'] = Variable<int>(dependOnTaskId);
    return map;
  }

  TaskDependOnRelationsCompanion toCompanion(bool nullToAbsent) {
    return TaskDependOnRelationsCompanion(
      id: Value(id),
      taskId: Value(taskId),
      dependOnTaskId: Value(dependOnTaskId),
    );
  }

  factory TaskDependOnRelation.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TaskDependOnRelation(
      id: serializer.fromJson<int>(json['id']),
      taskId: serializer.fromJson<int>(json['taskId']),
      dependOnTaskId: serializer.fromJson<int>(json['dependOnTaskId']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'taskId': serializer.toJson<int>(taskId),
      'dependOnTaskId': serializer.toJson<int>(dependOnTaskId),
    };
  }

  TaskDependOnRelation copyWith({int? id, int? taskId, int? dependOnTaskId}) =>
      TaskDependOnRelation(
        id: id ?? this.id,
        taskId: taskId ?? this.taskId,
        dependOnTaskId: dependOnTaskId ?? this.dependOnTaskId,
      );
  @override
  String toString() {
    return (StringBuffer('TaskDependOnRelation(')
          ..write('id: $id, ')
          ..write('taskId: $taskId, ')
          ..write('dependOnTaskId: $dependOnTaskId')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, taskId, dependOnTaskId);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TaskDependOnRelation &&
          other.id == this.id &&
          other.taskId == this.taskId &&
          other.dependOnTaskId == this.dependOnTaskId);
}

class TaskDependOnRelationsCompanion
    extends UpdateCompanion<TaskDependOnRelation> {
  final Value<int> id;
  final Value<int> taskId;
  final Value<int> dependOnTaskId;
  const TaskDependOnRelationsCompanion({
    this.id = const Value.absent(),
    this.taskId = const Value.absent(),
    this.dependOnTaskId = const Value.absent(),
  });
  TaskDependOnRelationsCompanion.insert({
    this.id = const Value.absent(),
    required int taskId,
    required int dependOnTaskId,
  })  : taskId = Value(taskId),
        dependOnTaskId = Value(dependOnTaskId);
  static Insertable<TaskDependOnRelation> custom({
    Expression<int>? id,
    Expression<int>? taskId,
    Expression<int>? dependOnTaskId,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (taskId != null) 'task_id': taskId,
      if (dependOnTaskId != null) 'depend_on_task_id': dependOnTaskId,
    });
  }

  TaskDependOnRelationsCompanion copyWith(
      {Value<int>? id, Value<int>? taskId, Value<int>? dependOnTaskId}) {
    return TaskDependOnRelationsCompanion(
      id: id ?? this.id,
      taskId: taskId ?? this.taskId,
      dependOnTaskId: dependOnTaskId ?? this.dependOnTaskId,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (taskId.present) {
      map['task_id'] = Variable<int>(taskId.value);
    }
    if (dependOnTaskId.present) {
      map['depend_on_task_id'] = Variable<int>(dependOnTaskId.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TaskDependOnRelationsCompanion(')
          ..write('id: $id, ')
          ..write('taskId: $taskId, ')
          ..write('dependOnTaskId: $dependOnTaskId')
          ..write(')'))
        .toString();
  }
}

abstract class _$DatabaseContext extends GeneratedDatabase {
  _$DatabaseContext(QueryExecutor e) : super(e);
  late final $LessonsTable lessons = $LessonsTable(this);
  late final $TasksTable tasks = $TasksTable(this);
  late final $ResourcesTable resources = $ResourcesTable(this);
  late final $NotesTable notes = $NotesTable(this);
  late final $SchedulesTable schedules = $SchedulesTable(this);
  late final $TaskSubtaskRelationsTable taskSubtaskRelations =
      $TaskSubtaskRelationsTable(this);
  late final $TaskDependOnRelationsTable taskDependOnRelations =
      $TaskDependOnRelationsTable(this);
  late final LessonsDao lessonsDao = LessonsDao(this as DatabaseContext);
  late final TasksDao tasksDao = TasksDao(this as DatabaseContext);
  late final NoteDao noteDao = NoteDao(this as DatabaseContext);
  late final ResourceDao resourceDao = ResourceDao(this as DatabaseContext);
  late final TaskSubtaskRelationsDao taskSubtaskRelationsDao =
      TaskSubtaskRelationsDao(this as DatabaseContext);
  late final TaskDependOnRelationsDao taskDependOnRelationsDao =
      TaskDependOnRelationsDao(this as DatabaseContext);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        lessons,
        tasks,
        resources,
        notes,
        schedules,
        taskSubtaskRelations,
        taskDependOnRelations
      ];
}
