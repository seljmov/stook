// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'task_depend_on_relation_dao.dart';

// ignore_for_file: type=lint
mixin _$TaskDependOnRelationsDaoMixin on DatabaseAccessor<DatabaseContext> {
  $TaskDependOnRelationsTable get taskDependOnRelations =>
      attachedDatabase.taskDependOnRelations;
}
