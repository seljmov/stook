// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'task_dao.dart';

// ignore_for_file: type=lint
mixin _$TasksDaoMixin on DatabaseAccessor<DatabaseContext> {
  $TasksTable get tasks => attachedDatabase.tasks;
}
