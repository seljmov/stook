// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'task_subtask_relation_dao.dart';

// ignore_for_file: type=lint
mixin _$TaskSubtaskRelationsDaoMixin on DatabaseAccessor<DatabaseContext> {
  $TaskSubtaskRelationsTable get taskSubtaskRelations =>
      attachedDatabase.taskSubtaskRelations;
}
