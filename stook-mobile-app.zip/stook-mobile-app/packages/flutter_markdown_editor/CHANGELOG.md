## [2.0.0] - 23/10/2020.

* Upgrade SDK.

## [1.1.1] - 23/10/2020.

* Preview text is selectable.

## [1.1.0] - 22/10/2020.

* Prompt for urls when inserting a url or image.
* Upgraded to markdoen 3.0.0 and flutter_markdown 0.5.0
* enhanced documentation.

## [1.0.0] - 13/10/2020.

* Allow link tapping.

## [0.0.3] - 13/10/2020.

* Edited description.

## [0.0.2] - 13/10/2020.

* Edited readme.


## [0.0.1] - 12/10/2020.

* Initial release.
