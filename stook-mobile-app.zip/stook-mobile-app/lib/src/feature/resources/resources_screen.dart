import 'package:flutter/material.dart';

/// Страница экрана ресурсов.
class ResourcesScreen extends StatelessWidget {
  const ResourcesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('Ресурсы'),
    );
  }
}
