// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'resource_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$ResourceEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function(int? resourceId, int fromScreenIndex) putResource,
    required TResult Function(int resourceId, int fromScreenIndex)
        deleteResource,
    required TResult Function(Resource resource, int fromScreenIndex)
        savePuttedResource,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function(int? resourceId, int fromScreenIndex)? putResource,
    TResult? Function(int resourceId, int fromScreenIndex)? deleteResource,
    TResult? Function(Resource resource, int fromScreenIndex)?
        savePuttedResource,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function(int? resourceId, int fromScreenIndex)? putResource,
    TResult Function(int resourceId, int fromScreenIndex)? deleteResource,
    TResult Function(Resource resource, int fromScreenIndex)?
        savePuttedResource,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Load value) load,
    required TResult Function(_PutResource value) putResource,
    required TResult Function(_DeleteResource value) deleteResource,
    required TResult Function(_SavePuttedResource value) savePuttedResource,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Load value)? load,
    TResult? Function(_PutResource value)? putResource,
    TResult? Function(_DeleteResource value)? deleteResource,
    TResult? Function(_SavePuttedResource value)? savePuttedResource,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Load value)? load,
    TResult Function(_PutResource value)? putResource,
    TResult Function(_DeleteResource value)? deleteResource,
    TResult Function(_SavePuttedResource value)? savePuttedResource,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ResourceEventCopyWith<$Res> {
  factory $ResourceEventCopyWith(
          ResourceEvent value, $Res Function(ResourceEvent) then) =
      _$ResourceEventCopyWithImpl<$Res, ResourceEvent>;
}

/// @nodoc
class _$ResourceEventCopyWithImpl<$Res, $Val extends ResourceEvent>
    implements $ResourceEventCopyWith<$Res> {
  _$ResourceEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$LoadImplCopyWith<$Res> {
  factory _$$LoadImplCopyWith(
          _$LoadImpl value, $Res Function(_$LoadImpl) then) =
      __$$LoadImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$LoadImplCopyWithImpl<$Res>
    extends _$ResourceEventCopyWithImpl<$Res, _$LoadImpl>
    implements _$$LoadImplCopyWith<$Res> {
  __$$LoadImplCopyWithImpl(_$LoadImpl _value, $Res Function(_$LoadImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$LoadImpl implements _Load {
  const _$LoadImpl();

  @override
  String toString() {
    return 'ResourceEvent.load()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$LoadImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function(int? resourceId, int fromScreenIndex) putResource,
    required TResult Function(int resourceId, int fromScreenIndex)
        deleteResource,
    required TResult Function(Resource resource, int fromScreenIndex)
        savePuttedResource,
  }) {
    return load();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function(int? resourceId, int fromScreenIndex)? putResource,
    TResult? Function(int resourceId, int fromScreenIndex)? deleteResource,
    TResult? Function(Resource resource, int fromScreenIndex)?
        savePuttedResource,
  }) {
    return load?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function(int? resourceId, int fromScreenIndex)? putResource,
    TResult Function(int resourceId, int fromScreenIndex)? deleteResource,
    TResult Function(Resource resource, int fromScreenIndex)?
        savePuttedResource,
    required TResult orElse(),
  }) {
    if (load != null) {
      return load();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Load value) load,
    required TResult Function(_PutResource value) putResource,
    required TResult Function(_DeleteResource value) deleteResource,
    required TResult Function(_SavePuttedResource value) savePuttedResource,
  }) {
    return load(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Load value)? load,
    TResult? Function(_PutResource value)? putResource,
    TResult? Function(_DeleteResource value)? deleteResource,
    TResult? Function(_SavePuttedResource value)? savePuttedResource,
  }) {
    return load?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Load value)? load,
    TResult Function(_PutResource value)? putResource,
    TResult Function(_DeleteResource value)? deleteResource,
    TResult Function(_SavePuttedResource value)? savePuttedResource,
    required TResult orElse(),
  }) {
    if (load != null) {
      return load(this);
    }
    return orElse();
  }
}

abstract class _Load implements ResourceEvent {
  const factory _Load() = _$LoadImpl;
}

/// @nodoc
abstract class _$$PutResourceImplCopyWith<$Res> {
  factory _$$PutResourceImplCopyWith(
          _$PutResourceImpl value, $Res Function(_$PutResourceImpl) then) =
      __$$PutResourceImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int? resourceId, int fromScreenIndex});
}

/// @nodoc
class __$$PutResourceImplCopyWithImpl<$Res>
    extends _$ResourceEventCopyWithImpl<$Res, _$PutResourceImpl>
    implements _$$PutResourceImplCopyWith<$Res> {
  __$$PutResourceImplCopyWithImpl(
      _$PutResourceImpl _value, $Res Function(_$PutResourceImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? resourceId = freezed,
    Object? fromScreenIndex = null,
  }) {
    return _then(_$PutResourceImpl(
      resourceId: freezed == resourceId
          ? _value.resourceId
          : resourceId // ignore: cast_nullable_to_non_nullable
              as int?,
      fromScreenIndex: null == fromScreenIndex
          ? _value.fromScreenIndex
          : fromScreenIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$PutResourceImpl implements _PutResource {
  const _$PutResourceImpl(
      {required this.resourceId, required this.fromScreenIndex});

  @override
  final int? resourceId;
  @override
  final int fromScreenIndex;

  @override
  String toString() {
    return 'ResourceEvent.putResource(resourceId: $resourceId, fromScreenIndex: $fromScreenIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PutResourceImpl &&
            (identical(other.resourceId, resourceId) ||
                other.resourceId == resourceId) &&
            (identical(other.fromScreenIndex, fromScreenIndex) ||
                other.fromScreenIndex == fromScreenIndex));
  }

  @override
  int get hashCode => Object.hash(runtimeType, resourceId, fromScreenIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PutResourceImplCopyWith<_$PutResourceImpl> get copyWith =>
      __$$PutResourceImplCopyWithImpl<_$PutResourceImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function(int? resourceId, int fromScreenIndex) putResource,
    required TResult Function(int resourceId, int fromScreenIndex)
        deleteResource,
    required TResult Function(Resource resource, int fromScreenIndex)
        savePuttedResource,
  }) {
    return putResource(resourceId, fromScreenIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function(int? resourceId, int fromScreenIndex)? putResource,
    TResult? Function(int resourceId, int fromScreenIndex)? deleteResource,
    TResult? Function(Resource resource, int fromScreenIndex)?
        savePuttedResource,
  }) {
    return putResource?.call(resourceId, fromScreenIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function(int? resourceId, int fromScreenIndex)? putResource,
    TResult Function(int resourceId, int fromScreenIndex)? deleteResource,
    TResult Function(Resource resource, int fromScreenIndex)?
        savePuttedResource,
    required TResult orElse(),
  }) {
    if (putResource != null) {
      return putResource(resourceId, fromScreenIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Load value) load,
    required TResult Function(_PutResource value) putResource,
    required TResult Function(_DeleteResource value) deleteResource,
    required TResult Function(_SavePuttedResource value) savePuttedResource,
  }) {
    return putResource(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Load value)? load,
    TResult? Function(_PutResource value)? putResource,
    TResult? Function(_DeleteResource value)? deleteResource,
    TResult? Function(_SavePuttedResource value)? savePuttedResource,
  }) {
    return putResource?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Load value)? load,
    TResult Function(_PutResource value)? putResource,
    TResult Function(_DeleteResource value)? deleteResource,
    TResult Function(_SavePuttedResource value)? savePuttedResource,
    required TResult orElse(),
  }) {
    if (putResource != null) {
      return putResource(this);
    }
    return orElse();
  }
}

abstract class _PutResource implements ResourceEvent {
  const factory _PutResource(
      {required final int? resourceId,
      required final int fromScreenIndex}) = _$PutResourceImpl;

  int? get resourceId;
  int get fromScreenIndex;
  @JsonKey(ignore: true)
  _$$PutResourceImplCopyWith<_$PutResourceImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$DeleteResourceImplCopyWith<$Res> {
  factory _$$DeleteResourceImplCopyWith(_$DeleteResourceImpl value,
          $Res Function(_$DeleteResourceImpl) then) =
      __$$DeleteResourceImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int resourceId, int fromScreenIndex});
}

/// @nodoc
class __$$DeleteResourceImplCopyWithImpl<$Res>
    extends _$ResourceEventCopyWithImpl<$Res, _$DeleteResourceImpl>
    implements _$$DeleteResourceImplCopyWith<$Res> {
  __$$DeleteResourceImplCopyWithImpl(
      _$DeleteResourceImpl _value, $Res Function(_$DeleteResourceImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? resourceId = null,
    Object? fromScreenIndex = null,
  }) {
    return _then(_$DeleteResourceImpl(
      resourceId: null == resourceId
          ? _value.resourceId
          : resourceId // ignore: cast_nullable_to_non_nullable
              as int,
      fromScreenIndex: null == fromScreenIndex
          ? _value.fromScreenIndex
          : fromScreenIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$DeleteResourceImpl implements _DeleteResource {
  const _$DeleteResourceImpl(
      {required this.resourceId, required this.fromScreenIndex});

  @override
  final int resourceId;
  @override
  final int fromScreenIndex;

  @override
  String toString() {
    return 'ResourceEvent.deleteResource(resourceId: $resourceId, fromScreenIndex: $fromScreenIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DeleteResourceImpl &&
            (identical(other.resourceId, resourceId) ||
                other.resourceId == resourceId) &&
            (identical(other.fromScreenIndex, fromScreenIndex) ||
                other.fromScreenIndex == fromScreenIndex));
  }

  @override
  int get hashCode => Object.hash(runtimeType, resourceId, fromScreenIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DeleteResourceImplCopyWith<_$DeleteResourceImpl> get copyWith =>
      __$$DeleteResourceImplCopyWithImpl<_$DeleteResourceImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function(int? resourceId, int fromScreenIndex) putResource,
    required TResult Function(int resourceId, int fromScreenIndex)
        deleteResource,
    required TResult Function(Resource resource, int fromScreenIndex)
        savePuttedResource,
  }) {
    return deleteResource(resourceId, fromScreenIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function(int? resourceId, int fromScreenIndex)? putResource,
    TResult? Function(int resourceId, int fromScreenIndex)? deleteResource,
    TResult? Function(Resource resource, int fromScreenIndex)?
        savePuttedResource,
  }) {
    return deleteResource?.call(resourceId, fromScreenIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function(int? resourceId, int fromScreenIndex)? putResource,
    TResult Function(int resourceId, int fromScreenIndex)? deleteResource,
    TResult Function(Resource resource, int fromScreenIndex)?
        savePuttedResource,
    required TResult orElse(),
  }) {
    if (deleteResource != null) {
      return deleteResource(resourceId, fromScreenIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Load value) load,
    required TResult Function(_PutResource value) putResource,
    required TResult Function(_DeleteResource value) deleteResource,
    required TResult Function(_SavePuttedResource value) savePuttedResource,
  }) {
    return deleteResource(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Load value)? load,
    TResult? Function(_PutResource value)? putResource,
    TResult? Function(_DeleteResource value)? deleteResource,
    TResult? Function(_SavePuttedResource value)? savePuttedResource,
  }) {
    return deleteResource?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Load value)? load,
    TResult Function(_PutResource value)? putResource,
    TResult Function(_DeleteResource value)? deleteResource,
    TResult Function(_SavePuttedResource value)? savePuttedResource,
    required TResult orElse(),
  }) {
    if (deleteResource != null) {
      return deleteResource(this);
    }
    return orElse();
  }
}

abstract class _DeleteResource implements ResourceEvent {
  const factory _DeleteResource(
      {required final int resourceId,
      required final int fromScreenIndex}) = _$DeleteResourceImpl;

  int get resourceId;
  int get fromScreenIndex;
  @JsonKey(ignore: true)
  _$$DeleteResourceImplCopyWith<_$DeleteResourceImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SavePuttedResourceImplCopyWith<$Res> {
  factory _$$SavePuttedResourceImplCopyWith(_$SavePuttedResourceImpl value,
          $Res Function(_$SavePuttedResourceImpl) then) =
      __$$SavePuttedResourceImplCopyWithImpl<$Res>;
  @useResult
  $Res call({Resource resource, int fromScreenIndex});
}

/// @nodoc
class __$$SavePuttedResourceImplCopyWithImpl<$Res>
    extends _$ResourceEventCopyWithImpl<$Res, _$SavePuttedResourceImpl>
    implements _$$SavePuttedResourceImplCopyWith<$Res> {
  __$$SavePuttedResourceImplCopyWithImpl(_$SavePuttedResourceImpl _value,
      $Res Function(_$SavePuttedResourceImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? resource = null,
    Object? fromScreenIndex = null,
  }) {
    return _then(_$SavePuttedResourceImpl(
      resource: null == resource
          ? _value.resource
          : resource // ignore: cast_nullable_to_non_nullable
              as Resource,
      fromScreenIndex: null == fromScreenIndex
          ? _value.fromScreenIndex
          : fromScreenIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$SavePuttedResourceImpl implements _SavePuttedResource {
  const _$SavePuttedResourceImpl(
      {required this.resource, required this.fromScreenIndex});

  @override
  final Resource resource;
  @override
  final int fromScreenIndex;

  @override
  String toString() {
    return 'ResourceEvent.savePuttedResource(resource: $resource, fromScreenIndex: $fromScreenIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SavePuttedResourceImpl &&
            (identical(other.resource, resource) ||
                other.resource == resource) &&
            (identical(other.fromScreenIndex, fromScreenIndex) ||
                other.fromScreenIndex == fromScreenIndex));
  }

  @override
  int get hashCode => Object.hash(runtimeType, resource, fromScreenIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SavePuttedResourceImplCopyWith<_$SavePuttedResourceImpl> get copyWith =>
      __$$SavePuttedResourceImplCopyWithImpl<_$SavePuttedResourceImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function(int? resourceId, int fromScreenIndex) putResource,
    required TResult Function(int resourceId, int fromScreenIndex)
        deleteResource,
    required TResult Function(Resource resource, int fromScreenIndex)
        savePuttedResource,
  }) {
    return savePuttedResource(resource, fromScreenIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function(int? resourceId, int fromScreenIndex)? putResource,
    TResult? Function(int resourceId, int fromScreenIndex)? deleteResource,
    TResult? Function(Resource resource, int fromScreenIndex)?
        savePuttedResource,
  }) {
    return savePuttedResource?.call(resource, fromScreenIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function(int? resourceId, int fromScreenIndex)? putResource,
    TResult Function(int resourceId, int fromScreenIndex)? deleteResource,
    TResult Function(Resource resource, int fromScreenIndex)?
        savePuttedResource,
    required TResult orElse(),
  }) {
    if (savePuttedResource != null) {
      return savePuttedResource(resource, fromScreenIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Load value) load,
    required TResult Function(_PutResource value) putResource,
    required TResult Function(_DeleteResource value) deleteResource,
    required TResult Function(_SavePuttedResource value) savePuttedResource,
  }) {
    return savePuttedResource(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Load value)? load,
    TResult? Function(_PutResource value)? putResource,
    TResult? Function(_DeleteResource value)? deleteResource,
    TResult? Function(_SavePuttedResource value)? savePuttedResource,
  }) {
    return savePuttedResource?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Load value)? load,
    TResult Function(_PutResource value)? putResource,
    TResult Function(_DeleteResource value)? deleteResource,
    TResult Function(_SavePuttedResource value)? savePuttedResource,
    required TResult orElse(),
  }) {
    if (savePuttedResource != null) {
      return savePuttedResource(this);
    }
    return orElse();
  }
}

abstract class _SavePuttedResource implements ResourceEvent {
  const factory _SavePuttedResource(
      {required final Resource resource,
      required final int fromScreenIndex}) = _$SavePuttedResourceImpl;

  Resource get resource;
  int get fromScreenIndex;
  @JsonKey(ignore: true)
  _$$SavePuttedResourceImplCopyWith<_$SavePuttedResourceImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$ResourceState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(List<Resource> resources) loaded,
    required TResult Function(Resource? resource) openPutResourceScreen,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(List<Resource> resources)? loaded,
    TResult? Function(Resource? resource)? openPutResourceScreen,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(List<Resource> resources)? loaded,
    TResult Function(Resource? resource)? openPutResourceScreen,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ResourceLoaderShowState value) loaderShow,
    required TResult Function(_ResourceLoaderHideState value) loaderHide,
    required TResult Function(_LoadedState value) loaded,
    required TResult Function(_ResourceOpenedPutScreen value)
        openPutResourceScreen,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ResourceLoaderShowState value)? loaderShow,
    TResult? Function(_ResourceLoaderHideState value)? loaderHide,
    TResult? Function(_LoadedState value)? loaded,
    TResult? Function(_ResourceOpenedPutScreen value)? openPutResourceScreen,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ResourceLoaderShowState value)? loaderShow,
    TResult Function(_ResourceLoaderHideState value)? loaderHide,
    TResult Function(_LoadedState value)? loaded,
    TResult Function(_ResourceOpenedPutScreen value)? openPutResourceScreen,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ResourceStateCopyWith<$Res> {
  factory $ResourceStateCopyWith(
          ResourceState value, $Res Function(ResourceState) then) =
      _$ResourceStateCopyWithImpl<$Res, ResourceState>;
}

/// @nodoc
class _$ResourceStateCopyWithImpl<$Res, $Val extends ResourceState>
    implements $ResourceStateCopyWith<$Res> {
  _$ResourceStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$ResourceLoaderShowStateImplCopyWith<$Res> {
  factory _$$ResourceLoaderShowStateImplCopyWith(
          _$ResourceLoaderShowStateImpl value,
          $Res Function(_$ResourceLoaderShowStateImpl) then) =
      __$$ResourceLoaderShowStateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ResourceLoaderShowStateImplCopyWithImpl<$Res>
    extends _$ResourceStateCopyWithImpl<$Res, _$ResourceLoaderShowStateImpl>
    implements _$$ResourceLoaderShowStateImplCopyWith<$Res> {
  __$$ResourceLoaderShowStateImplCopyWithImpl(
      _$ResourceLoaderShowStateImpl _value,
      $Res Function(_$ResourceLoaderShowStateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ResourceLoaderShowStateImpl implements _ResourceLoaderShowState {
  const _$ResourceLoaderShowStateImpl();

  @override
  String toString() {
    return 'ResourceState.loaderShow()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ResourceLoaderShowStateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(List<Resource> resources) loaded,
    required TResult Function(Resource? resource) openPutResourceScreen,
  }) {
    return loaderShow();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(List<Resource> resources)? loaded,
    TResult? Function(Resource? resource)? openPutResourceScreen,
  }) {
    return loaderShow?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(List<Resource> resources)? loaded,
    TResult Function(Resource? resource)? openPutResourceScreen,
    required TResult orElse(),
  }) {
    if (loaderShow != null) {
      return loaderShow();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ResourceLoaderShowState value) loaderShow,
    required TResult Function(_ResourceLoaderHideState value) loaderHide,
    required TResult Function(_LoadedState value) loaded,
    required TResult Function(_ResourceOpenedPutScreen value)
        openPutResourceScreen,
  }) {
    return loaderShow(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ResourceLoaderShowState value)? loaderShow,
    TResult? Function(_ResourceLoaderHideState value)? loaderHide,
    TResult? Function(_LoadedState value)? loaded,
    TResult? Function(_ResourceOpenedPutScreen value)? openPutResourceScreen,
  }) {
    return loaderShow?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ResourceLoaderShowState value)? loaderShow,
    TResult Function(_ResourceLoaderHideState value)? loaderHide,
    TResult Function(_LoadedState value)? loaded,
    TResult Function(_ResourceOpenedPutScreen value)? openPutResourceScreen,
    required TResult orElse(),
  }) {
    if (loaderShow != null) {
      return loaderShow(this);
    }
    return orElse();
  }
}

abstract class _ResourceLoaderShowState implements ResourceState {
  const factory _ResourceLoaderShowState() = _$ResourceLoaderShowStateImpl;
}

/// @nodoc
abstract class _$$ResourceLoaderHideStateImplCopyWith<$Res> {
  factory _$$ResourceLoaderHideStateImplCopyWith(
          _$ResourceLoaderHideStateImpl value,
          $Res Function(_$ResourceLoaderHideStateImpl) then) =
      __$$ResourceLoaderHideStateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ResourceLoaderHideStateImplCopyWithImpl<$Res>
    extends _$ResourceStateCopyWithImpl<$Res, _$ResourceLoaderHideStateImpl>
    implements _$$ResourceLoaderHideStateImplCopyWith<$Res> {
  __$$ResourceLoaderHideStateImplCopyWithImpl(
      _$ResourceLoaderHideStateImpl _value,
      $Res Function(_$ResourceLoaderHideStateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ResourceLoaderHideStateImpl implements _ResourceLoaderHideState {
  const _$ResourceLoaderHideStateImpl();

  @override
  String toString() {
    return 'ResourceState.loaderHide()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ResourceLoaderHideStateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(List<Resource> resources) loaded,
    required TResult Function(Resource? resource) openPutResourceScreen,
  }) {
    return loaderHide();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(List<Resource> resources)? loaded,
    TResult? Function(Resource? resource)? openPutResourceScreen,
  }) {
    return loaderHide?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(List<Resource> resources)? loaded,
    TResult Function(Resource? resource)? openPutResourceScreen,
    required TResult orElse(),
  }) {
    if (loaderHide != null) {
      return loaderHide();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ResourceLoaderShowState value) loaderShow,
    required TResult Function(_ResourceLoaderHideState value) loaderHide,
    required TResult Function(_LoadedState value) loaded,
    required TResult Function(_ResourceOpenedPutScreen value)
        openPutResourceScreen,
  }) {
    return loaderHide(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ResourceLoaderShowState value)? loaderShow,
    TResult? Function(_ResourceLoaderHideState value)? loaderHide,
    TResult? Function(_LoadedState value)? loaded,
    TResult? Function(_ResourceOpenedPutScreen value)? openPutResourceScreen,
  }) {
    return loaderHide?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ResourceLoaderShowState value)? loaderShow,
    TResult Function(_ResourceLoaderHideState value)? loaderHide,
    TResult Function(_LoadedState value)? loaded,
    TResult Function(_ResourceOpenedPutScreen value)? openPutResourceScreen,
    required TResult orElse(),
  }) {
    if (loaderHide != null) {
      return loaderHide(this);
    }
    return orElse();
  }
}

abstract class _ResourceLoaderHideState implements ResourceState {
  const factory _ResourceLoaderHideState() = _$ResourceLoaderHideStateImpl;
}

/// @nodoc
abstract class _$$LoadedStateImplCopyWith<$Res> {
  factory _$$LoadedStateImplCopyWith(
          _$LoadedStateImpl value, $Res Function(_$LoadedStateImpl) then) =
      __$$LoadedStateImplCopyWithImpl<$Res>;
  @useResult
  $Res call({List<Resource> resources});
}

/// @nodoc
class __$$LoadedStateImplCopyWithImpl<$Res>
    extends _$ResourceStateCopyWithImpl<$Res, _$LoadedStateImpl>
    implements _$$LoadedStateImplCopyWith<$Res> {
  __$$LoadedStateImplCopyWithImpl(
      _$LoadedStateImpl _value, $Res Function(_$LoadedStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? resources = null,
  }) {
    return _then(_$LoadedStateImpl(
      resources: null == resources
          ? _value._resources
          : resources // ignore: cast_nullable_to_non_nullable
              as List<Resource>,
    ));
  }
}

/// @nodoc

class _$LoadedStateImpl implements _LoadedState {
  const _$LoadedStateImpl({required final List<Resource> resources})
      : _resources = resources;

  final List<Resource> _resources;
  @override
  List<Resource> get resources {
    if (_resources is EqualUnmodifiableListView) return _resources;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_resources);
  }

  @override
  String toString() {
    return 'ResourceState.loaded(resources: $resources)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$LoadedStateImpl &&
            const DeepCollectionEquality()
                .equals(other._resources, _resources));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_resources));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$LoadedStateImplCopyWith<_$LoadedStateImpl> get copyWith =>
      __$$LoadedStateImplCopyWithImpl<_$LoadedStateImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(List<Resource> resources) loaded,
    required TResult Function(Resource? resource) openPutResourceScreen,
  }) {
    return loaded(resources);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(List<Resource> resources)? loaded,
    TResult? Function(Resource? resource)? openPutResourceScreen,
  }) {
    return loaded?.call(resources);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(List<Resource> resources)? loaded,
    TResult Function(Resource? resource)? openPutResourceScreen,
    required TResult orElse(),
  }) {
    if (loaded != null) {
      return loaded(resources);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ResourceLoaderShowState value) loaderShow,
    required TResult Function(_ResourceLoaderHideState value) loaderHide,
    required TResult Function(_LoadedState value) loaded,
    required TResult Function(_ResourceOpenedPutScreen value)
        openPutResourceScreen,
  }) {
    return loaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ResourceLoaderShowState value)? loaderShow,
    TResult? Function(_ResourceLoaderHideState value)? loaderHide,
    TResult? Function(_LoadedState value)? loaded,
    TResult? Function(_ResourceOpenedPutScreen value)? openPutResourceScreen,
  }) {
    return loaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ResourceLoaderShowState value)? loaderShow,
    TResult Function(_ResourceLoaderHideState value)? loaderHide,
    TResult Function(_LoadedState value)? loaded,
    TResult Function(_ResourceOpenedPutScreen value)? openPutResourceScreen,
    required TResult orElse(),
  }) {
    if (loaded != null) {
      return loaded(this);
    }
    return orElse();
  }
}

abstract class _LoadedState implements ResourceState {
  const factory _LoadedState({required final List<Resource> resources}) =
      _$LoadedStateImpl;

  List<Resource> get resources;
  @JsonKey(ignore: true)
  _$$LoadedStateImplCopyWith<_$LoadedStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$ResourceOpenedPutScreenImplCopyWith<$Res> {
  factory _$$ResourceOpenedPutScreenImplCopyWith(
          _$ResourceOpenedPutScreenImpl value,
          $Res Function(_$ResourceOpenedPutScreenImpl) then) =
      __$$ResourceOpenedPutScreenImplCopyWithImpl<$Res>;
  @useResult
  $Res call({Resource? resource});
}

/// @nodoc
class __$$ResourceOpenedPutScreenImplCopyWithImpl<$Res>
    extends _$ResourceStateCopyWithImpl<$Res, _$ResourceOpenedPutScreenImpl>
    implements _$$ResourceOpenedPutScreenImplCopyWith<$Res> {
  __$$ResourceOpenedPutScreenImplCopyWithImpl(
      _$ResourceOpenedPutScreenImpl _value,
      $Res Function(_$ResourceOpenedPutScreenImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? resource = freezed,
  }) {
    return _then(_$ResourceOpenedPutScreenImpl(
      resource: freezed == resource
          ? _value.resource
          : resource // ignore: cast_nullable_to_non_nullable
              as Resource?,
    ));
  }
}

/// @nodoc

class _$ResourceOpenedPutScreenImpl implements _ResourceOpenedPutScreen {
  const _$ResourceOpenedPutScreenImpl({required this.resource});

  @override
  final Resource? resource;

  @override
  String toString() {
    return 'ResourceState.openPutResourceScreen(resource: $resource)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ResourceOpenedPutScreenImpl &&
            (identical(other.resource, resource) ||
                other.resource == resource));
  }

  @override
  int get hashCode => Object.hash(runtimeType, resource);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ResourceOpenedPutScreenImplCopyWith<_$ResourceOpenedPutScreenImpl>
      get copyWith => __$$ResourceOpenedPutScreenImplCopyWithImpl<
          _$ResourceOpenedPutScreenImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(List<Resource> resources) loaded,
    required TResult Function(Resource? resource) openPutResourceScreen,
  }) {
    return openPutResourceScreen(resource);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(List<Resource> resources)? loaded,
    TResult? Function(Resource? resource)? openPutResourceScreen,
  }) {
    return openPutResourceScreen?.call(resource);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(List<Resource> resources)? loaded,
    TResult Function(Resource? resource)? openPutResourceScreen,
    required TResult orElse(),
  }) {
    if (openPutResourceScreen != null) {
      return openPutResourceScreen(resource);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_ResourceLoaderShowState value) loaderShow,
    required TResult Function(_ResourceLoaderHideState value) loaderHide,
    required TResult Function(_LoadedState value) loaded,
    required TResult Function(_ResourceOpenedPutScreen value)
        openPutResourceScreen,
  }) {
    return openPutResourceScreen(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_ResourceLoaderShowState value)? loaderShow,
    TResult? Function(_ResourceLoaderHideState value)? loaderHide,
    TResult? Function(_LoadedState value)? loaded,
    TResult? Function(_ResourceOpenedPutScreen value)? openPutResourceScreen,
  }) {
    return openPutResourceScreen?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_ResourceLoaderShowState value)? loaderShow,
    TResult Function(_ResourceLoaderHideState value)? loaderHide,
    TResult Function(_LoadedState value)? loaded,
    TResult Function(_ResourceOpenedPutScreen value)? openPutResourceScreen,
    required TResult orElse(),
  }) {
    if (openPutResourceScreen != null) {
      return openPutResourceScreen(this);
    }
    return orElse();
  }
}

abstract class _ResourceOpenedPutScreen implements ResourceState {
  const factory _ResourceOpenedPutScreen({required final Resource? resource}) =
      _$ResourceOpenedPutScreenImpl;

  Resource? get resource;
  @JsonKey(ignore: true)
  _$$ResourceOpenedPutScreenImplCopyWith<_$ResourceOpenedPutScreenImpl>
      get copyWith => throw _privateConstructorUsedError;
}
