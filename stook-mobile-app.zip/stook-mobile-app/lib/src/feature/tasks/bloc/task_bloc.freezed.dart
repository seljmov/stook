// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'task_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$TaskEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function(int? taskId, int fromScreenIndex) openPutTask,
    required TResult Function(TaskEntity task) savePuttedTask,
    required TResult Function(TaskEntity task, int fromScreenIndex) deleteTask,
    required TResult Function(
            int taskId, TaskStatus status, int fromScreenIndex)
        changeTaskStatus,
    required TResult Function() runImportanceAlgorithm,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function(int? taskId, int fromScreenIndex)? openPutTask,
    TResult? Function(TaskEntity task)? savePuttedTask,
    TResult? Function(TaskEntity task, int fromScreenIndex)? deleteTask,
    TResult? Function(int taskId, TaskStatus status, int fromScreenIndex)?
        changeTaskStatus,
    TResult? Function()? runImportanceAlgorithm,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function(int? taskId, int fromScreenIndex)? openPutTask,
    TResult Function(TaskEntity task)? savePuttedTask,
    TResult Function(TaskEntity task, int fromScreenIndex)? deleteTask,
    TResult Function(int taskId, TaskStatus status, int fromScreenIndex)?
        changeTaskStatus,
    TResult Function()? runImportanceAlgorithm,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_TaskLoadEvent value) load,
    required TResult Function(_TaskOpenPutTaskEvent value) openPutTask,
    required TResult Function(_TaskSavePuttedTaskEvent value) savePuttedTask,
    required TResult Function(_TaskDeleteTaskEvent value) deleteTask,
    required TResult Function(_TaskChangeTaskStatusEvent value)
        changeTaskStatus,
    required TResult Function(_TaskRunImportanceAlgorithmEvent value)
        runImportanceAlgorithm,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_TaskLoadEvent value)? load,
    TResult? Function(_TaskOpenPutTaskEvent value)? openPutTask,
    TResult? Function(_TaskSavePuttedTaskEvent value)? savePuttedTask,
    TResult? Function(_TaskDeleteTaskEvent value)? deleteTask,
    TResult? Function(_TaskChangeTaskStatusEvent value)? changeTaskStatus,
    TResult? Function(_TaskRunImportanceAlgorithmEvent value)?
        runImportanceAlgorithm,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_TaskLoadEvent value)? load,
    TResult Function(_TaskOpenPutTaskEvent value)? openPutTask,
    TResult Function(_TaskSavePuttedTaskEvent value)? savePuttedTask,
    TResult Function(_TaskDeleteTaskEvent value)? deleteTask,
    TResult Function(_TaskChangeTaskStatusEvent value)? changeTaskStatus,
    TResult Function(_TaskRunImportanceAlgorithmEvent value)?
        runImportanceAlgorithm,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $TaskEventCopyWith<$Res> {
  factory $TaskEventCopyWith(TaskEvent value, $Res Function(TaskEvent) then) =
      _$TaskEventCopyWithImpl<$Res, TaskEvent>;
}

/// @nodoc
class _$TaskEventCopyWithImpl<$Res, $Val extends TaskEvent>
    implements $TaskEventCopyWith<$Res> {
  _$TaskEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$TaskLoadEventImplCopyWith<$Res> {
  factory _$$TaskLoadEventImplCopyWith(
          _$TaskLoadEventImpl value, $Res Function(_$TaskLoadEventImpl) then) =
      __$$TaskLoadEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$TaskLoadEventImplCopyWithImpl<$Res>
    extends _$TaskEventCopyWithImpl<$Res, _$TaskLoadEventImpl>
    implements _$$TaskLoadEventImplCopyWith<$Res> {
  __$$TaskLoadEventImplCopyWithImpl(
      _$TaskLoadEventImpl _value, $Res Function(_$TaskLoadEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$TaskLoadEventImpl implements _TaskLoadEvent {
  const _$TaskLoadEventImpl();

  @override
  String toString() {
    return 'TaskEvent.load()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$TaskLoadEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function(int? taskId, int fromScreenIndex) openPutTask,
    required TResult Function(TaskEntity task) savePuttedTask,
    required TResult Function(TaskEntity task, int fromScreenIndex) deleteTask,
    required TResult Function(
            int taskId, TaskStatus status, int fromScreenIndex)
        changeTaskStatus,
    required TResult Function() runImportanceAlgorithm,
  }) {
    return load();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function(int? taskId, int fromScreenIndex)? openPutTask,
    TResult? Function(TaskEntity task)? savePuttedTask,
    TResult? Function(TaskEntity task, int fromScreenIndex)? deleteTask,
    TResult? Function(int taskId, TaskStatus status, int fromScreenIndex)?
        changeTaskStatus,
    TResult? Function()? runImportanceAlgorithm,
  }) {
    return load?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function(int? taskId, int fromScreenIndex)? openPutTask,
    TResult Function(TaskEntity task)? savePuttedTask,
    TResult Function(TaskEntity task, int fromScreenIndex)? deleteTask,
    TResult Function(int taskId, TaskStatus status, int fromScreenIndex)?
        changeTaskStatus,
    TResult Function()? runImportanceAlgorithm,
    required TResult orElse(),
  }) {
    if (load != null) {
      return load();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_TaskLoadEvent value) load,
    required TResult Function(_TaskOpenPutTaskEvent value) openPutTask,
    required TResult Function(_TaskSavePuttedTaskEvent value) savePuttedTask,
    required TResult Function(_TaskDeleteTaskEvent value) deleteTask,
    required TResult Function(_TaskChangeTaskStatusEvent value)
        changeTaskStatus,
    required TResult Function(_TaskRunImportanceAlgorithmEvent value)
        runImportanceAlgorithm,
  }) {
    return load(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_TaskLoadEvent value)? load,
    TResult? Function(_TaskOpenPutTaskEvent value)? openPutTask,
    TResult? Function(_TaskSavePuttedTaskEvent value)? savePuttedTask,
    TResult? Function(_TaskDeleteTaskEvent value)? deleteTask,
    TResult? Function(_TaskChangeTaskStatusEvent value)? changeTaskStatus,
    TResult? Function(_TaskRunImportanceAlgorithmEvent value)?
        runImportanceAlgorithm,
  }) {
    return load?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_TaskLoadEvent value)? load,
    TResult Function(_TaskOpenPutTaskEvent value)? openPutTask,
    TResult Function(_TaskSavePuttedTaskEvent value)? savePuttedTask,
    TResult Function(_TaskDeleteTaskEvent value)? deleteTask,
    TResult Function(_TaskChangeTaskStatusEvent value)? changeTaskStatus,
    TResult Function(_TaskRunImportanceAlgorithmEvent value)?
        runImportanceAlgorithm,
    required TResult orElse(),
  }) {
    if (load != null) {
      return load(this);
    }
    return orElse();
  }
}

abstract class _TaskLoadEvent implements TaskEvent {
  const factory _TaskLoadEvent() = _$TaskLoadEventImpl;
}

/// @nodoc
abstract class _$$TaskOpenPutTaskEventImplCopyWith<$Res> {
  factory _$$TaskOpenPutTaskEventImplCopyWith(_$TaskOpenPutTaskEventImpl value,
          $Res Function(_$TaskOpenPutTaskEventImpl) then) =
      __$$TaskOpenPutTaskEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int? taskId, int fromScreenIndex});
}

/// @nodoc
class __$$TaskOpenPutTaskEventImplCopyWithImpl<$Res>
    extends _$TaskEventCopyWithImpl<$Res, _$TaskOpenPutTaskEventImpl>
    implements _$$TaskOpenPutTaskEventImplCopyWith<$Res> {
  __$$TaskOpenPutTaskEventImplCopyWithImpl(_$TaskOpenPutTaskEventImpl _value,
      $Res Function(_$TaskOpenPutTaskEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? taskId = freezed,
    Object? fromScreenIndex = null,
  }) {
    return _then(_$TaskOpenPutTaskEventImpl(
      taskId: freezed == taskId
          ? _value.taskId
          : taskId // ignore: cast_nullable_to_non_nullable
              as int?,
      fromScreenIndex: null == fromScreenIndex
          ? _value.fromScreenIndex
          : fromScreenIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$TaskOpenPutTaskEventImpl implements _TaskOpenPutTaskEvent {
  const _$TaskOpenPutTaskEventImpl(
      {required this.taskId, required this.fromScreenIndex});

  @override
  final int? taskId;
  @override
  final int fromScreenIndex;

  @override
  String toString() {
    return 'TaskEvent.openPutTask(taskId: $taskId, fromScreenIndex: $fromScreenIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$TaskOpenPutTaskEventImpl &&
            (identical(other.taskId, taskId) || other.taskId == taskId) &&
            (identical(other.fromScreenIndex, fromScreenIndex) ||
                other.fromScreenIndex == fromScreenIndex));
  }

  @override
  int get hashCode => Object.hash(runtimeType, taskId, fromScreenIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$TaskOpenPutTaskEventImplCopyWith<_$TaskOpenPutTaskEventImpl>
      get copyWith =>
          __$$TaskOpenPutTaskEventImplCopyWithImpl<_$TaskOpenPutTaskEventImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function(int? taskId, int fromScreenIndex) openPutTask,
    required TResult Function(TaskEntity task) savePuttedTask,
    required TResult Function(TaskEntity task, int fromScreenIndex) deleteTask,
    required TResult Function(
            int taskId, TaskStatus status, int fromScreenIndex)
        changeTaskStatus,
    required TResult Function() runImportanceAlgorithm,
  }) {
    return openPutTask(taskId, fromScreenIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function(int? taskId, int fromScreenIndex)? openPutTask,
    TResult? Function(TaskEntity task)? savePuttedTask,
    TResult? Function(TaskEntity task, int fromScreenIndex)? deleteTask,
    TResult? Function(int taskId, TaskStatus status, int fromScreenIndex)?
        changeTaskStatus,
    TResult? Function()? runImportanceAlgorithm,
  }) {
    return openPutTask?.call(taskId, fromScreenIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function(int? taskId, int fromScreenIndex)? openPutTask,
    TResult Function(TaskEntity task)? savePuttedTask,
    TResult Function(TaskEntity task, int fromScreenIndex)? deleteTask,
    TResult Function(int taskId, TaskStatus status, int fromScreenIndex)?
        changeTaskStatus,
    TResult Function()? runImportanceAlgorithm,
    required TResult orElse(),
  }) {
    if (openPutTask != null) {
      return openPutTask(taskId, fromScreenIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_TaskLoadEvent value) load,
    required TResult Function(_TaskOpenPutTaskEvent value) openPutTask,
    required TResult Function(_TaskSavePuttedTaskEvent value) savePuttedTask,
    required TResult Function(_TaskDeleteTaskEvent value) deleteTask,
    required TResult Function(_TaskChangeTaskStatusEvent value)
        changeTaskStatus,
    required TResult Function(_TaskRunImportanceAlgorithmEvent value)
        runImportanceAlgorithm,
  }) {
    return openPutTask(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_TaskLoadEvent value)? load,
    TResult? Function(_TaskOpenPutTaskEvent value)? openPutTask,
    TResult? Function(_TaskSavePuttedTaskEvent value)? savePuttedTask,
    TResult? Function(_TaskDeleteTaskEvent value)? deleteTask,
    TResult? Function(_TaskChangeTaskStatusEvent value)? changeTaskStatus,
    TResult? Function(_TaskRunImportanceAlgorithmEvent value)?
        runImportanceAlgorithm,
  }) {
    return openPutTask?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_TaskLoadEvent value)? load,
    TResult Function(_TaskOpenPutTaskEvent value)? openPutTask,
    TResult Function(_TaskSavePuttedTaskEvent value)? savePuttedTask,
    TResult Function(_TaskDeleteTaskEvent value)? deleteTask,
    TResult Function(_TaskChangeTaskStatusEvent value)? changeTaskStatus,
    TResult Function(_TaskRunImportanceAlgorithmEvent value)?
        runImportanceAlgorithm,
    required TResult orElse(),
  }) {
    if (openPutTask != null) {
      return openPutTask(this);
    }
    return orElse();
  }
}

abstract class _TaskOpenPutTaskEvent implements TaskEvent {
  const factory _TaskOpenPutTaskEvent(
      {required final int? taskId,
      required final int fromScreenIndex}) = _$TaskOpenPutTaskEventImpl;

  int? get taskId;
  int get fromScreenIndex;
  @JsonKey(ignore: true)
  _$$TaskOpenPutTaskEventImplCopyWith<_$TaskOpenPutTaskEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$TaskSavePuttedTaskEventImplCopyWith<$Res> {
  factory _$$TaskSavePuttedTaskEventImplCopyWith(
          _$TaskSavePuttedTaskEventImpl value,
          $Res Function(_$TaskSavePuttedTaskEventImpl) then) =
      __$$TaskSavePuttedTaskEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({TaskEntity task});
}

/// @nodoc
class __$$TaskSavePuttedTaskEventImplCopyWithImpl<$Res>
    extends _$TaskEventCopyWithImpl<$Res, _$TaskSavePuttedTaskEventImpl>
    implements _$$TaskSavePuttedTaskEventImplCopyWith<$Res> {
  __$$TaskSavePuttedTaskEventImplCopyWithImpl(
      _$TaskSavePuttedTaskEventImpl _value,
      $Res Function(_$TaskSavePuttedTaskEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? task = null,
  }) {
    return _then(_$TaskSavePuttedTaskEventImpl(
      task: null == task
          ? _value.task
          : task // ignore: cast_nullable_to_non_nullable
              as TaskEntity,
    ));
  }
}

/// @nodoc

class _$TaskSavePuttedTaskEventImpl implements _TaskSavePuttedTaskEvent {
  const _$TaskSavePuttedTaskEventImpl({required this.task});

  @override
  final TaskEntity task;

  @override
  String toString() {
    return 'TaskEvent.savePuttedTask(task: $task)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$TaskSavePuttedTaskEventImpl &&
            (identical(other.task, task) || other.task == task));
  }

  @override
  int get hashCode => Object.hash(runtimeType, task);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$TaskSavePuttedTaskEventImplCopyWith<_$TaskSavePuttedTaskEventImpl>
      get copyWith => __$$TaskSavePuttedTaskEventImplCopyWithImpl<
          _$TaskSavePuttedTaskEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function(int? taskId, int fromScreenIndex) openPutTask,
    required TResult Function(TaskEntity task) savePuttedTask,
    required TResult Function(TaskEntity task, int fromScreenIndex) deleteTask,
    required TResult Function(
            int taskId, TaskStatus status, int fromScreenIndex)
        changeTaskStatus,
    required TResult Function() runImportanceAlgorithm,
  }) {
    return savePuttedTask(task);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function(int? taskId, int fromScreenIndex)? openPutTask,
    TResult? Function(TaskEntity task)? savePuttedTask,
    TResult? Function(TaskEntity task, int fromScreenIndex)? deleteTask,
    TResult? Function(int taskId, TaskStatus status, int fromScreenIndex)?
        changeTaskStatus,
    TResult? Function()? runImportanceAlgorithm,
  }) {
    return savePuttedTask?.call(task);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function(int? taskId, int fromScreenIndex)? openPutTask,
    TResult Function(TaskEntity task)? savePuttedTask,
    TResult Function(TaskEntity task, int fromScreenIndex)? deleteTask,
    TResult Function(int taskId, TaskStatus status, int fromScreenIndex)?
        changeTaskStatus,
    TResult Function()? runImportanceAlgorithm,
    required TResult orElse(),
  }) {
    if (savePuttedTask != null) {
      return savePuttedTask(task);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_TaskLoadEvent value) load,
    required TResult Function(_TaskOpenPutTaskEvent value) openPutTask,
    required TResult Function(_TaskSavePuttedTaskEvent value) savePuttedTask,
    required TResult Function(_TaskDeleteTaskEvent value) deleteTask,
    required TResult Function(_TaskChangeTaskStatusEvent value)
        changeTaskStatus,
    required TResult Function(_TaskRunImportanceAlgorithmEvent value)
        runImportanceAlgorithm,
  }) {
    return savePuttedTask(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_TaskLoadEvent value)? load,
    TResult? Function(_TaskOpenPutTaskEvent value)? openPutTask,
    TResult? Function(_TaskSavePuttedTaskEvent value)? savePuttedTask,
    TResult? Function(_TaskDeleteTaskEvent value)? deleteTask,
    TResult? Function(_TaskChangeTaskStatusEvent value)? changeTaskStatus,
    TResult? Function(_TaskRunImportanceAlgorithmEvent value)?
        runImportanceAlgorithm,
  }) {
    return savePuttedTask?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_TaskLoadEvent value)? load,
    TResult Function(_TaskOpenPutTaskEvent value)? openPutTask,
    TResult Function(_TaskSavePuttedTaskEvent value)? savePuttedTask,
    TResult Function(_TaskDeleteTaskEvent value)? deleteTask,
    TResult Function(_TaskChangeTaskStatusEvent value)? changeTaskStatus,
    TResult Function(_TaskRunImportanceAlgorithmEvent value)?
        runImportanceAlgorithm,
    required TResult orElse(),
  }) {
    if (savePuttedTask != null) {
      return savePuttedTask(this);
    }
    return orElse();
  }
}

abstract class _TaskSavePuttedTaskEvent implements TaskEvent {
  const factory _TaskSavePuttedTaskEvent({required final TaskEntity task}) =
      _$TaskSavePuttedTaskEventImpl;

  TaskEntity get task;
  @JsonKey(ignore: true)
  _$$TaskSavePuttedTaskEventImplCopyWith<_$TaskSavePuttedTaskEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$TaskDeleteTaskEventImplCopyWith<$Res> {
  factory _$$TaskDeleteTaskEventImplCopyWith(_$TaskDeleteTaskEventImpl value,
          $Res Function(_$TaskDeleteTaskEventImpl) then) =
      __$$TaskDeleteTaskEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({TaskEntity task, int fromScreenIndex});
}

/// @nodoc
class __$$TaskDeleteTaskEventImplCopyWithImpl<$Res>
    extends _$TaskEventCopyWithImpl<$Res, _$TaskDeleteTaskEventImpl>
    implements _$$TaskDeleteTaskEventImplCopyWith<$Res> {
  __$$TaskDeleteTaskEventImplCopyWithImpl(_$TaskDeleteTaskEventImpl _value,
      $Res Function(_$TaskDeleteTaskEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? task = null,
    Object? fromScreenIndex = null,
  }) {
    return _then(_$TaskDeleteTaskEventImpl(
      task: null == task
          ? _value.task
          : task // ignore: cast_nullable_to_non_nullable
              as TaskEntity,
      fromScreenIndex: null == fromScreenIndex
          ? _value.fromScreenIndex
          : fromScreenIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$TaskDeleteTaskEventImpl implements _TaskDeleteTaskEvent {
  const _$TaskDeleteTaskEventImpl(
      {required this.task, required this.fromScreenIndex});

  @override
  final TaskEntity task;
  @override
  final int fromScreenIndex;

  @override
  String toString() {
    return 'TaskEvent.deleteTask(task: $task, fromScreenIndex: $fromScreenIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$TaskDeleteTaskEventImpl &&
            (identical(other.task, task) || other.task == task) &&
            (identical(other.fromScreenIndex, fromScreenIndex) ||
                other.fromScreenIndex == fromScreenIndex));
  }

  @override
  int get hashCode => Object.hash(runtimeType, task, fromScreenIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$TaskDeleteTaskEventImplCopyWith<_$TaskDeleteTaskEventImpl> get copyWith =>
      __$$TaskDeleteTaskEventImplCopyWithImpl<_$TaskDeleteTaskEventImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function(int? taskId, int fromScreenIndex) openPutTask,
    required TResult Function(TaskEntity task) savePuttedTask,
    required TResult Function(TaskEntity task, int fromScreenIndex) deleteTask,
    required TResult Function(
            int taskId, TaskStatus status, int fromScreenIndex)
        changeTaskStatus,
    required TResult Function() runImportanceAlgorithm,
  }) {
    return deleteTask(task, fromScreenIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function(int? taskId, int fromScreenIndex)? openPutTask,
    TResult? Function(TaskEntity task)? savePuttedTask,
    TResult? Function(TaskEntity task, int fromScreenIndex)? deleteTask,
    TResult? Function(int taskId, TaskStatus status, int fromScreenIndex)?
        changeTaskStatus,
    TResult? Function()? runImportanceAlgorithm,
  }) {
    return deleteTask?.call(task, fromScreenIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function(int? taskId, int fromScreenIndex)? openPutTask,
    TResult Function(TaskEntity task)? savePuttedTask,
    TResult Function(TaskEntity task, int fromScreenIndex)? deleteTask,
    TResult Function(int taskId, TaskStatus status, int fromScreenIndex)?
        changeTaskStatus,
    TResult Function()? runImportanceAlgorithm,
    required TResult orElse(),
  }) {
    if (deleteTask != null) {
      return deleteTask(task, fromScreenIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_TaskLoadEvent value) load,
    required TResult Function(_TaskOpenPutTaskEvent value) openPutTask,
    required TResult Function(_TaskSavePuttedTaskEvent value) savePuttedTask,
    required TResult Function(_TaskDeleteTaskEvent value) deleteTask,
    required TResult Function(_TaskChangeTaskStatusEvent value)
        changeTaskStatus,
    required TResult Function(_TaskRunImportanceAlgorithmEvent value)
        runImportanceAlgorithm,
  }) {
    return deleteTask(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_TaskLoadEvent value)? load,
    TResult? Function(_TaskOpenPutTaskEvent value)? openPutTask,
    TResult? Function(_TaskSavePuttedTaskEvent value)? savePuttedTask,
    TResult? Function(_TaskDeleteTaskEvent value)? deleteTask,
    TResult? Function(_TaskChangeTaskStatusEvent value)? changeTaskStatus,
    TResult? Function(_TaskRunImportanceAlgorithmEvent value)?
        runImportanceAlgorithm,
  }) {
    return deleteTask?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_TaskLoadEvent value)? load,
    TResult Function(_TaskOpenPutTaskEvent value)? openPutTask,
    TResult Function(_TaskSavePuttedTaskEvent value)? savePuttedTask,
    TResult Function(_TaskDeleteTaskEvent value)? deleteTask,
    TResult Function(_TaskChangeTaskStatusEvent value)? changeTaskStatus,
    TResult Function(_TaskRunImportanceAlgorithmEvent value)?
        runImportanceAlgorithm,
    required TResult orElse(),
  }) {
    if (deleteTask != null) {
      return deleteTask(this);
    }
    return orElse();
  }
}

abstract class _TaskDeleteTaskEvent implements TaskEvent {
  const factory _TaskDeleteTaskEvent(
      {required final TaskEntity task,
      required final int fromScreenIndex}) = _$TaskDeleteTaskEventImpl;

  TaskEntity get task;
  int get fromScreenIndex;
  @JsonKey(ignore: true)
  _$$TaskDeleteTaskEventImplCopyWith<_$TaskDeleteTaskEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$TaskChangeTaskStatusEventImplCopyWith<$Res> {
  factory _$$TaskChangeTaskStatusEventImplCopyWith(
          _$TaskChangeTaskStatusEventImpl value,
          $Res Function(_$TaskChangeTaskStatusEventImpl) then) =
      __$$TaskChangeTaskStatusEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int taskId, TaskStatus status, int fromScreenIndex});
}

/// @nodoc
class __$$TaskChangeTaskStatusEventImplCopyWithImpl<$Res>
    extends _$TaskEventCopyWithImpl<$Res, _$TaskChangeTaskStatusEventImpl>
    implements _$$TaskChangeTaskStatusEventImplCopyWith<$Res> {
  __$$TaskChangeTaskStatusEventImplCopyWithImpl(
      _$TaskChangeTaskStatusEventImpl _value,
      $Res Function(_$TaskChangeTaskStatusEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? taskId = null,
    Object? status = null,
    Object? fromScreenIndex = null,
  }) {
    return _then(_$TaskChangeTaskStatusEventImpl(
      taskId: null == taskId
          ? _value.taskId
          : taskId // ignore: cast_nullable_to_non_nullable
              as int,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as TaskStatus,
      fromScreenIndex: null == fromScreenIndex
          ? _value.fromScreenIndex
          : fromScreenIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$TaskChangeTaskStatusEventImpl implements _TaskChangeTaskStatusEvent {
  const _$TaskChangeTaskStatusEventImpl(
      {required this.taskId,
      required this.status,
      required this.fromScreenIndex});

  @override
  final int taskId;
  @override
  final TaskStatus status;
  @override
  final int fromScreenIndex;

  @override
  String toString() {
    return 'TaskEvent.changeTaskStatus(taskId: $taskId, status: $status, fromScreenIndex: $fromScreenIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$TaskChangeTaskStatusEventImpl &&
            (identical(other.taskId, taskId) || other.taskId == taskId) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.fromScreenIndex, fromScreenIndex) ||
                other.fromScreenIndex == fromScreenIndex));
  }

  @override
  int get hashCode => Object.hash(runtimeType, taskId, status, fromScreenIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$TaskChangeTaskStatusEventImplCopyWith<_$TaskChangeTaskStatusEventImpl>
      get copyWith => __$$TaskChangeTaskStatusEventImplCopyWithImpl<
          _$TaskChangeTaskStatusEventImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function(int? taskId, int fromScreenIndex) openPutTask,
    required TResult Function(TaskEntity task) savePuttedTask,
    required TResult Function(TaskEntity task, int fromScreenIndex) deleteTask,
    required TResult Function(
            int taskId, TaskStatus status, int fromScreenIndex)
        changeTaskStatus,
    required TResult Function() runImportanceAlgorithm,
  }) {
    return changeTaskStatus(taskId, status, fromScreenIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function(int? taskId, int fromScreenIndex)? openPutTask,
    TResult? Function(TaskEntity task)? savePuttedTask,
    TResult? Function(TaskEntity task, int fromScreenIndex)? deleteTask,
    TResult? Function(int taskId, TaskStatus status, int fromScreenIndex)?
        changeTaskStatus,
    TResult? Function()? runImportanceAlgorithm,
  }) {
    return changeTaskStatus?.call(taskId, status, fromScreenIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function(int? taskId, int fromScreenIndex)? openPutTask,
    TResult Function(TaskEntity task)? savePuttedTask,
    TResult Function(TaskEntity task, int fromScreenIndex)? deleteTask,
    TResult Function(int taskId, TaskStatus status, int fromScreenIndex)?
        changeTaskStatus,
    TResult Function()? runImportanceAlgorithm,
    required TResult orElse(),
  }) {
    if (changeTaskStatus != null) {
      return changeTaskStatus(taskId, status, fromScreenIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_TaskLoadEvent value) load,
    required TResult Function(_TaskOpenPutTaskEvent value) openPutTask,
    required TResult Function(_TaskSavePuttedTaskEvent value) savePuttedTask,
    required TResult Function(_TaskDeleteTaskEvent value) deleteTask,
    required TResult Function(_TaskChangeTaskStatusEvent value)
        changeTaskStatus,
    required TResult Function(_TaskRunImportanceAlgorithmEvent value)
        runImportanceAlgorithm,
  }) {
    return changeTaskStatus(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_TaskLoadEvent value)? load,
    TResult? Function(_TaskOpenPutTaskEvent value)? openPutTask,
    TResult? Function(_TaskSavePuttedTaskEvent value)? savePuttedTask,
    TResult? Function(_TaskDeleteTaskEvent value)? deleteTask,
    TResult? Function(_TaskChangeTaskStatusEvent value)? changeTaskStatus,
    TResult? Function(_TaskRunImportanceAlgorithmEvent value)?
        runImportanceAlgorithm,
  }) {
    return changeTaskStatus?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_TaskLoadEvent value)? load,
    TResult Function(_TaskOpenPutTaskEvent value)? openPutTask,
    TResult Function(_TaskSavePuttedTaskEvent value)? savePuttedTask,
    TResult Function(_TaskDeleteTaskEvent value)? deleteTask,
    TResult Function(_TaskChangeTaskStatusEvent value)? changeTaskStatus,
    TResult Function(_TaskRunImportanceAlgorithmEvent value)?
        runImportanceAlgorithm,
    required TResult orElse(),
  }) {
    if (changeTaskStatus != null) {
      return changeTaskStatus(this);
    }
    return orElse();
  }
}

abstract class _TaskChangeTaskStatusEvent implements TaskEvent {
  const factory _TaskChangeTaskStatusEvent(
      {required final int taskId,
      required final TaskStatus status,
      required final int fromScreenIndex}) = _$TaskChangeTaskStatusEventImpl;

  int get taskId;
  TaskStatus get status;
  int get fromScreenIndex;
  @JsonKey(ignore: true)
  _$$TaskChangeTaskStatusEventImplCopyWith<_$TaskChangeTaskStatusEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$TaskRunImportanceAlgorithmEventImplCopyWith<$Res> {
  factory _$$TaskRunImportanceAlgorithmEventImplCopyWith(
          _$TaskRunImportanceAlgorithmEventImpl value,
          $Res Function(_$TaskRunImportanceAlgorithmEventImpl) then) =
      __$$TaskRunImportanceAlgorithmEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$TaskRunImportanceAlgorithmEventImplCopyWithImpl<$Res>
    extends _$TaskEventCopyWithImpl<$Res, _$TaskRunImportanceAlgorithmEventImpl>
    implements _$$TaskRunImportanceAlgorithmEventImplCopyWith<$Res> {
  __$$TaskRunImportanceAlgorithmEventImplCopyWithImpl(
      _$TaskRunImportanceAlgorithmEventImpl _value,
      $Res Function(_$TaskRunImportanceAlgorithmEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$TaskRunImportanceAlgorithmEventImpl
    implements _TaskRunImportanceAlgorithmEvent {
  const _$TaskRunImportanceAlgorithmEventImpl();

  @override
  String toString() {
    return 'TaskEvent.runImportanceAlgorithm()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$TaskRunImportanceAlgorithmEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function(int? taskId, int fromScreenIndex) openPutTask,
    required TResult Function(TaskEntity task) savePuttedTask,
    required TResult Function(TaskEntity task, int fromScreenIndex) deleteTask,
    required TResult Function(
            int taskId, TaskStatus status, int fromScreenIndex)
        changeTaskStatus,
    required TResult Function() runImportanceAlgorithm,
  }) {
    return runImportanceAlgorithm();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function(int? taskId, int fromScreenIndex)? openPutTask,
    TResult? Function(TaskEntity task)? savePuttedTask,
    TResult? Function(TaskEntity task, int fromScreenIndex)? deleteTask,
    TResult? Function(int taskId, TaskStatus status, int fromScreenIndex)?
        changeTaskStatus,
    TResult? Function()? runImportanceAlgorithm,
  }) {
    return runImportanceAlgorithm?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function(int? taskId, int fromScreenIndex)? openPutTask,
    TResult Function(TaskEntity task)? savePuttedTask,
    TResult Function(TaskEntity task, int fromScreenIndex)? deleteTask,
    TResult Function(int taskId, TaskStatus status, int fromScreenIndex)?
        changeTaskStatus,
    TResult Function()? runImportanceAlgorithm,
    required TResult orElse(),
  }) {
    if (runImportanceAlgorithm != null) {
      return runImportanceAlgorithm();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_TaskLoadEvent value) load,
    required TResult Function(_TaskOpenPutTaskEvent value) openPutTask,
    required TResult Function(_TaskSavePuttedTaskEvent value) savePuttedTask,
    required TResult Function(_TaskDeleteTaskEvent value) deleteTask,
    required TResult Function(_TaskChangeTaskStatusEvent value)
        changeTaskStatus,
    required TResult Function(_TaskRunImportanceAlgorithmEvent value)
        runImportanceAlgorithm,
  }) {
    return runImportanceAlgorithm(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_TaskLoadEvent value)? load,
    TResult? Function(_TaskOpenPutTaskEvent value)? openPutTask,
    TResult? Function(_TaskSavePuttedTaskEvent value)? savePuttedTask,
    TResult? Function(_TaskDeleteTaskEvent value)? deleteTask,
    TResult? Function(_TaskChangeTaskStatusEvent value)? changeTaskStatus,
    TResult? Function(_TaskRunImportanceAlgorithmEvent value)?
        runImportanceAlgorithm,
  }) {
    return runImportanceAlgorithm?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_TaskLoadEvent value)? load,
    TResult Function(_TaskOpenPutTaskEvent value)? openPutTask,
    TResult Function(_TaskSavePuttedTaskEvent value)? savePuttedTask,
    TResult Function(_TaskDeleteTaskEvent value)? deleteTask,
    TResult Function(_TaskChangeTaskStatusEvent value)? changeTaskStatus,
    TResult Function(_TaskRunImportanceAlgorithmEvent value)?
        runImportanceAlgorithm,
    required TResult orElse(),
  }) {
    if (runImportanceAlgorithm != null) {
      return runImportanceAlgorithm(this);
    }
    return orElse();
  }
}

abstract class _TaskRunImportanceAlgorithmEvent implements TaskEvent {
  const factory _TaskRunImportanceAlgorithmEvent() =
      _$TaskRunImportanceAlgorithmEventImpl;
}

/// @nodoc
mixin _$TaskState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(
            List<TaskBaseEntity> tasks,
            List<TaskBaseEntity> mostImportanceTasks,
            DateTime? lastImportanceAlgorithmRunTime,
            int initialScreenIndex)
        loaded,
    required TResult Function(
            TaskEntity? task, List<TaskEntity> allTasks, int fromScreenIndex)
        openPutTaskScreen,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(
            List<TaskBaseEntity> tasks,
            List<TaskBaseEntity> mostImportanceTasks,
            DateTime? lastImportanceAlgorithmRunTime,
            int initialScreenIndex)?
        loaded,
    TResult? Function(
            TaskEntity? task, List<TaskEntity> allTasks, int fromScreenIndex)?
        openPutTaskScreen,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(
            List<TaskBaseEntity> tasks,
            List<TaskBaseEntity> mostImportanceTasks,
            DateTime? lastImportanceAlgorithmRunTime,
            int initialScreenIndex)?
        loaded,
    TResult Function(
            TaskEntity? task, List<TaskEntity> allTasks, int fromScreenIndex)?
        openPutTaskScreen,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_TaskInitialState value) initial,
    required TResult Function(_TaskLoaderShowState value) loaderShow,
    required TResult Function(_TaskLoaderHideState value) loaderHide,
    required TResult Function(_TaskLoadedState value) loaded,
    required TResult Function(_TaskOpenPutTaskScreenState value)
        openPutTaskScreen,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_TaskInitialState value)? initial,
    TResult? Function(_TaskLoaderShowState value)? loaderShow,
    TResult? Function(_TaskLoaderHideState value)? loaderHide,
    TResult? Function(_TaskLoadedState value)? loaded,
    TResult? Function(_TaskOpenPutTaskScreenState value)? openPutTaskScreen,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_TaskInitialState value)? initial,
    TResult Function(_TaskLoaderShowState value)? loaderShow,
    TResult Function(_TaskLoaderHideState value)? loaderHide,
    TResult Function(_TaskLoadedState value)? loaded,
    TResult Function(_TaskOpenPutTaskScreenState value)? openPutTaskScreen,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $TaskStateCopyWith<$Res> {
  factory $TaskStateCopyWith(TaskState value, $Res Function(TaskState) then) =
      _$TaskStateCopyWithImpl<$Res, TaskState>;
}

/// @nodoc
class _$TaskStateCopyWithImpl<$Res, $Val extends TaskState>
    implements $TaskStateCopyWith<$Res> {
  _$TaskStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$TaskInitialStateImplCopyWith<$Res> {
  factory _$$TaskInitialStateImplCopyWith(_$TaskInitialStateImpl value,
          $Res Function(_$TaskInitialStateImpl) then) =
      __$$TaskInitialStateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$TaskInitialStateImplCopyWithImpl<$Res>
    extends _$TaskStateCopyWithImpl<$Res, _$TaskInitialStateImpl>
    implements _$$TaskInitialStateImplCopyWith<$Res> {
  __$$TaskInitialStateImplCopyWithImpl(_$TaskInitialStateImpl _value,
      $Res Function(_$TaskInitialStateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$TaskInitialStateImpl implements _TaskInitialState {
  const _$TaskInitialStateImpl();

  @override
  String toString() {
    return 'TaskState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$TaskInitialStateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(
            List<TaskBaseEntity> tasks,
            List<TaskBaseEntity> mostImportanceTasks,
            DateTime? lastImportanceAlgorithmRunTime,
            int initialScreenIndex)
        loaded,
    required TResult Function(
            TaskEntity? task, List<TaskEntity> allTasks, int fromScreenIndex)
        openPutTaskScreen,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(
            List<TaskBaseEntity> tasks,
            List<TaskBaseEntity> mostImportanceTasks,
            DateTime? lastImportanceAlgorithmRunTime,
            int initialScreenIndex)?
        loaded,
    TResult? Function(
            TaskEntity? task, List<TaskEntity> allTasks, int fromScreenIndex)?
        openPutTaskScreen,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(
            List<TaskBaseEntity> tasks,
            List<TaskBaseEntity> mostImportanceTasks,
            DateTime? lastImportanceAlgorithmRunTime,
            int initialScreenIndex)?
        loaded,
    TResult Function(
            TaskEntity? task, List<TaskEntity> allTasks, int fromScreenIndex)?
        openPutTaskScreen,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_TaskInitialState value) initial,
    required TResult Function(_TaskLoaderShowState value) loaderShow,
    required TResult Function(_TaskLoaderHideState value) loaderHide,
    required TResult Function(_TaskLoadedState value) loaded,
    required TResult Function(_TaskOpenPutTaskScreenState value)
        openPutTaskScreen,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_TaskInitialState value)? initial,
    TResult? Function(_TaskLoaderShowState value)? loaderShow,
    TResult? Function(_TaskLoaderHideState value)? loaderHide,
    TResult? Function(_TaskLoadedState value)? loaded,
    TResult? Function(_TaskOpenPutTaskScreenState value)? openPutTaskScreen,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_TaskInitialState value)? initial,
    TResult Function(_TaskLoaderShowState value)? loaderShow,
    TResult Function(_TaskLoaderHideState value)? loaderHide,
    TResult Function(_TaskLoadedState value)? loaded,
    TResult Function(_TaskOpenPutTaskScreenState value)? openPutTaskScreen,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _TaskInitialState implements TaskState {
  const factory _TaskInitialState() = _$TaskInitialStateImpl;
}

/// @nodoc
abstract class _$$TaskLoaderShowStateImplCopyWith<$Res> {
  factory _$$TaskLoaderShowStateImplCopyWith(_$TaskLoaderShowStateImpl value,
          $Res Function(_$TaskLoaderShowStateImpl) then) =
      __$$TaskLoaderShowStateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$TaskLoaderShowStateImplCopyWithImpl<$Res>
    extends _$TaskStateCopyWithImpl<$Res, _$TaskLoaderShowStateImpl>
    implements _$$TaskLoaderShowStateImplCopyWith<$Res> {
  __$$TaskLoaderShowStateImplCopyWithImpl(_$TaskLoaderShowStateImpl _value,
      $Res Function(_$TaskLoaderShowStateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$TaskLoaderShowStateImpl implements _TaskLoaderShowState {
  const _$TaskLoaderShowStateImpl();

  @override
  String toString() {
    return 'TaskState.loaderShow()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$TaskLoaderShowStateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(
            List<TaskBaseEntity> tasks,
            List<TaskBaseEntity> mostImportanceTasks,
            DateTime? lastImportanceAlgorithmRunTime,
            int initialScreenIndex)
        loaded,
    required TResult Function(
            TaskEntity? task, List<TaskEntity> allTasks, int fromScreenIndex)
        openPutTaskScreen,
  }) {
    return loaderShow();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(
            List<TaskBaseEntity> tasks,
            List<TaskBaseEntity> mostImportanceTasks,
            DateTime? lastImportanceAlgorithmRunTime,
            int initialScreenIndex)?
        loaded,
    TResult? Function(
            TaskEntity? task, List<TaskEntity> allTasks, int fromScreenIndex)?
        openPutTaskScreen,
  }) {
    return loaderShow?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(
            List<TaskBaseEntity> tasks,
            List<TaskBaseEntity> mostImportanceTasks,
            DateTime? lastImportanceAlgorithmRunTime,
            int initialScreenIndex)?
        loaded,
    TResult Function(
            TaskEntity? task, List<TaskEntity> allTasks, int fromScreenIndex)?
        openPutTaskScreen,
    required TResult orElse(),
  }) {
    if (loaderShow != null) {
      return loaderShow();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_TaskInitialState value) initial,
    required TResult Function(_TaskLoaderShowState value) loaderShow,
    required TResult Function(_TaskLoaderHideState value) loaderHide,
    required TResult Function(_TaskLoadedState value) loaded,
    required TResult Function(_TaskOpenPutTaskScreenState value)
        openPutTaskScreen,
  }) {
    return loaderShow(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_TaskInitialState value)? initial,
    TResult? Function(_TaskLoaderShowState value)? loaderShow,
    TResult? Function(_TaskLoaderHideState value)? loaderHide,
    TResult? Function(_TaskLoadedState value)? loaded,
    TResult? Function(_TaskOpenPutTaskScreenState value)? openPutTaskScreen,
  }) {
    return loaderShow?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_TaskInitialState value)? initial,
    TResult Function(_TaskLoaderShowState value)? loaderShow,
    TResult Function(_TaskLoaderHideState value)? loaderHide,
    TResult Function(_TaskLoadedState value)? loaded,
    TResult Function(_TaskOpenPutTaskScreenState value)? openPutTaskScreen,
    required TResult orElse(),
  }) {
    if (loaderShow != null) {
      return loaderShow(this);
    }
    return orElse();
  }
}

abstract class _TaskLoaderShowState implements TaskState {
  const factory _TaskLoaderShowState() = _$TaskLoaderShowStateImpl;
}

/// @nodoc
abstract class _$$TaskLoaderHideStateImplCopyWith<$Res> {
  factory _$$TaskLoaderHideStateImplCopyWith(_$TaskLoaderHideStateImpl value,
          $Res Function(_$TaskLoaderHideStateImpl) then) =
      __$$TaskLoaderHideStateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$TaskLoaderHideStateImplCopyWithImpl<$Res>
    extends _$TaskStateCopyWithImpl<$Res, _$TaskLoaderHideStateImpl>
    implements _$$TaskLoaderHideStateImplCopyWith<$Res> {
  __$$TaskLoaderHideStateImplCopyWithImpl(_$TaskLoaderHideStateImpl _value,
      $Res Function(_$TaskLoaderHideStateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$TaskLoaderHideStateImpl implements _TaskLoaderHideState {
  const _$TaskLoaderHideStateImpl();

  @override
  String toString() {
    return 'TaskState.loaderHide()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$TaskLoaderHideStateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(
            List<TaskBaseEntity> tasks,
            List<TaskBaseEntity> mostImportanceTasks,
            DateTime? lastImportanceAlgorithmRunTime,
            int initialScreenIndex)
        loaded,
    required TResult Function(
            TaskEntity? task, List<TaskEntity> allTasks, int fromScreenIndex)
        openPutTaskScreen,
  }) {
    return loaderHide();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(
            List<TaskBaseEntity> tasks,
            List<TaskBaseEntity> mostImportanceTasks,
            DateTime? lastImportanceAlgorithmRunTime,
            int initialScreenIndex)?
        loaded,
    TResult? Function(
            TaskEntity? task, List<TaskEntity> allTasks, int fromScreenIndex)?
        openPutTaskScreen,
  }) {
    return loaderHide?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(
            List<TaskBaseEntity> tasks,
            List<TaskBaseEntity> mostImportanceTasks,
            DateTime? lastImportanceAlgorithmRunTime,
            int initialScreenIndex)?
        loaded,
    TResult Function(
            TaskEntity? task, List<TaskEntity> allTasks, int fromScreenIndex)?
        openPutTaskScreen,
    required TResult orElse(),
  }) {
    if (loaderHide != null) {
      return loaderHide();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_TaskInitialState value) initial,
    required TResult Function(_TaskLoaderShowState value) loaderShow,
    required TResult Function(_TaskLoaderHideState value) loaderHide,
    required TResult Function(_TaskLoadedState value) loaded,
    required TResult Function(_TaskOpenPutTaskScreenState value)
        openPutTaskScreen,
  }) {
    return loaderHide(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_TaskInitialState value)? initial,
    TResult? Function(_TaskLoaderShowState value)? loaderShow,
    TResult? Function(_TaskLoaderHideState value)? loaderHide,
    TResult? Function(_TaskLoadedState value)? loaded,
    TResult? Function(_TaskOpenPutTaskScreenState value)? openPutTaskScreen,
  }) {
    return loaderHide?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_TaskInitialState value)? initial,
    TResult Function(_TaskLoaderShowState value)? loaderShow,
    TResult Function(_TaskLoaderHideState value)? loaderHide,
    TResult Function(_TaskLoadedState value)? loaded,
    TResult Function(_TaskOpenPutTaskScreenState value)? openPutTaskScreen,
    required TResult orElse(),
  }) {
    if (loaderHide != null) {
      return loaderHide(this);
    }
    return orElse();
  }
}

abstract class _TaskLoaderHideState implements TaskState {
  const factory _TaskLoaderHideState() = _$TaskLoaderHideStateImpl;
}

/// @nodoc
abstract class _$$TaskLoadedStateImplCopyWith<$Res> {
  factory _$$TaskLoadedStateImplCopyWith(_$TaskLoadedStateImpl value,
          $Res Function(_$TaskLoadedStateImpl) then) =
      __$$TaskLoadedStateImplCopyWithImpl<$Res>;
  @useResult
  $Res call(
      {List<TaskBaseEntity> tasks,
      List<TaskBaseEntity> mostImportanceTasks,
      DateTime? lastImportanceAlgorithmRunTime,
      int initialScreenIndex});
}

/// @nodoc
class __$$TaskLoadedStateImplCopyWithImpl<$Res>
    extends _$TaskStateCopyWithImpl<$Res, _$TaskLoadedStateImpl>
    implements _$$TaskLoadedStateImplCopyWith<$Res> {
  __$$TaskLoadedStateImplCopyWithImpl(
      _$TaskLoadedStateImpl _value, $Res Function(_$TaskLoadedStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? tasks = null,
    Object? mostImportanceTasks = null,
    Object? lastImportanceAlgorithmRunTime = freezed,
    Object? initialScreenIndex = null,
  }) {
    return _then(_$TaskLoadedStateImpl(
      tasks: null == tasks
          ? _value._tasks
          : tasks // ignore: cast_nullable_to_non_nullable
              as List<TaskBaseEntity>,
      mostImportanceTasks: null == mostImportanceTasks
          ? _value._mostImportanceTasks
          : mostImportanceTasks // ignore: cast_nullable_to_non_nullable
              as List<TaskBaseEntity>,
      lastImportanceAlgorithmRunTime: freezed == lastImportanceAlgorithmRunTime
          ? _value.lastImportanceAlgorithmRunTime
          : lastImportanceAlgorithmRunTime // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      initialScreenIndex: null == initialScreenIndex
          ? _value.initialScreenIndex
          : initialScreenIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$TaskLoadedStateImpl implements _TaskLoadedState {
  const _$TaskLoadedStateImpl(
      {required final List<TaskBaseEntity> tasks,
      required final List<TaskBaseEntity> mostImportanceTasks,
      required this.lastImportanceAlgorithmRunTime,
      required this.initialScreenIndex})
      : _tasks = tasks,
        _mostImportanceTasks = mostImportanceTasks;

  final List<TaskBaseEntity> _tasks;
  @override
  List<TaskBaseEntity> get tasks {
    if (_tasks is EqualUnmodifiableListView) return _tasks;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_tasks);
  }

  final List<TaskBaseEntity> _mostImportanceTasks;
  @override
  List<TaskBaseEntity> get mostImportanceTasks {
    if (_mostImportanceTasks is EqualUnmodifiableListView)
      return _mostImportanceTasks;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_mostImportanceTasks);
  }

  @override
  final DateTime? lastImportanceAlgorithmRunTime;
  @override
  final int initialScreenIndex;

  @override
  String toString() {
    return 'TaskState.loaded(tasks: $tasks, mostImportanceTasks: $mostImportanceTasks, lastImportanceAlgorithmRunTime: $lastImportanceAlgorithmRunTime, initialScreenIndex: $initialScreenIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$TaskLoadedStateImpl &&
            const DeepCollectionEquality().equals(other._tasks, _tasks) &&
            const DeepCollectionEquality()
                .equals(other._mostImportanceTasks, _mostImportanceTasks) &&
            (identical(other.lastImportanceAlgorithmRunTime,
                    lastImportanceAlgorithmRunTime) ||
                other.lastImportanceAlgorithmRunTime ==
                    lastImportanceAlgorithmRunTime) &&
            (identical(other.initialScreenIndex, initialScreenIndex) ||
                other.initialScreenIndex == initialScreenIndex));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_tasks),
      const DeepCollectionEquality().hash(_mostImportanceTasks),
      lastImportanceAlgorithmRunTime,
      initialScreenIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$TaskLoadedStateImplCopyWith<_$TaskLoadedStateImpl> get copyWith =>
      __$$TaskLoadedStateImplCopyWithImpl<_$TaskLoadedStateImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(
            List<TaskBaseEntity> tasks,
            List<TaskBaseEntity> mostImportanceTasks,
            DateTime? lastImportanceAlgorithmRunTime,
            int initialScreenIndex)
        loaded,
    required TResult Function(
            TaskEntity? task, List<TaskEntity> allTasks, int fromScreenIndex)
        openPutTaskScreen,
  }) {
    return loaded(tasks, mostImportanceTasks, lastImportanceAlgorithmRunTime,
        initialScreenIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(
            List<TaskBaseEntity> tasks,
            List<TaskBaseEntity> mostImportanceTasks,
            DateTime? lastImportanceAlgorithmRunTime,
            int initialScreenIndex)?
        loaded,
    TResult? Function(
            TaskEntity? task, List<TaskEntity> allTasks, int fromScreenIndex)?
        openPutTaskScreen,
  }) {
    return loaded?.call(tasks, mostImportanceTasks,
        lastImportanceAlgorithmRunTime, initialScreenIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(
            List<TaskBaseEntity> tasks,
            List<TaskBaseEntity> mostImportanceTasks,
            DateTime? lastImportanceAlgorithmRunTime,
            int initialScreenIndex)?
        loaded,
    TResult Function(
            TaskEntity? task, List<TaskEntity> allTasks, int fromScreenIndex)?
        openPutTaskScreen,
    required TResult orElse(),
  }) {
    if (loaded != null) {
      return loaded(tasks, mostImportanceTasks, lastImportanceAlgorithmRunTime,
          initialScreenIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_TaskInitialState value) initial,
    required TResult Function(_TaskLoaderShowState value) loaderShow,
    required TResult Function(_TaskLoaderHideState value) loaderHide,
    required TResult Function(_TaskLoadedState value) loaded,
    required TResult Function(_TaskOpenPutTaskScreenState value)
        openPutTaskScreen,
  }) {
    return loaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_TaskInitialState value)? initial,
    TResult? Function(_TaskLoaderShowState value)? loaderShow,
    TResult? Function(_TaskLoaderHideState value)? loaderHide,
    TResult? Function(_TaskLoadedState value)? loaded,
    TResult? Function(_TaskOpenPutTaskScreenState value)? openPutTaskScreen,
  }) {
    return loaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_TaskInitialState value)? initial,
    TResult Function(_TaskLoaderShowState value)? loaderShow,
    TResult Function(_TaskLoaderHideState value)? loaderHide,
    TResult Function(_TaskLoadedState value)? loaded,
    TResult Function(_TaskOpenPutTaskScreenState value)? openPutTaskScreen,
    required TResult orElse(),
  }) {
    if (loaded != null) {
      return loaded(this);
    }
    return orElse();
  }
}

abstract class _TaskLoadedState implements TaskState {
  const factory _TaskLoadedState(
      {required final List<TaskBaseEntity> tasks,
      required final List<TaskBaseEntity> mostImportanceTasks,
      required final DateTime? lastImportanceAlgorithmRunTime,
      required final int initialScreenIndex}) = _$TaskLoadedStateImpl;

  List<TaskBaseEntity> get tasks;
  List<TaskBaseEntity> get mostImportanceTasks;
  DateTime? get lastImportanceAlgorithmRunTime;
  int get initialScreenIndex;
  @JsonKey(ignore: true)
  _$$TaskLoadedStateImplCopyWith<_$TaskLoadedStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$TaskOpenPutTaskScreenStateImplCopyWith<$Res> {
  factory _$$TaskOpenPutTaskScreenStateImplCopyWith(
          _$TaskOpenPutTaskScreenStateImpl value,
          $Res Function(_$TaskOpenPutTaskScreenStateImpl) then) =
      __$$TaskOpenPutTaskScreenStateImplCopyWithImpl<$Res>;
  @useResult
  $Res call({TaskEntity? task, List<TaskEntity> allTasks, int fromScreenIndex});
}

/// @nodoc
class __$$TaskOpenPutTaskScreenStateImplCopyWithImpl<$Res>
    extends _$TaskStateCopyWithImpl<$Res, _$TaskOpenPutTaskScreenStateImpl>
    implements _$$TaskOpenPutTaskScreenStateImplCopyWith<$Res> {
  __$$TaskOpenPutTaskScreenStateImplCopyWithImpl(
      _$TaskOpenPutTaskScreenStateImpl _value,
      $Res Function(_$TaskOpenPutTaskScreenStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? task = freezed,
    Object? allTasks = null,
    Object? fromScreenIndex = null,
  }) {
    return _then(_$TaskOpenPutTaskScreenStateImpl(
      task: freezed == task
          ? _value.task
          : task // ignore: cast_nullable_to_non_nullable
              as TaskEntity?,
      allTasks: null == allTasks
          ? _value._allTasks
          : allTasks // ignore: cast_nullable_to_non_nullable
              as List<TaskEntity>,
      fromScreenIndex: null == fromScreenIndex
          ? _value.fromScreenIndex
          : fromScreenIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$TaskOpenPutTaskScreenStateImpl implements _TaskOpenPutTaskScreenState {
  const _$TaskOpenPutTaskScreenStateImpl(
      {required this.task,
      required final List<TaskEntity> allTasks,
      required this.fromScreenIndex})
      : _allTasks = allTasks;

  @override
  final TaskEntity? task;
  final List<TaskEntity> _allTasks;
  @override
  List<TaskEntity> get allTasks {
    if (_allTasks is EqualUnmodifiableListView) return _allTasks;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_allTasks);
  }

  @override
  final int fromScreenIndex;

  @override
  String toString() {
    return 'TaskState.openPutTaskScreen(task: $task, allTasks: $allTasks, fromScreenIndex: $fromScreenIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$TaskOpenPutTaskScreenStateImpl &&
            (identical(other.task, task) || other.task == task) &&
            const DeepCollectionEquality().equals(other._allTasks, _allTasks) &&
            (identical(other.fromScreenIndex, fromScreenIndex) ||
                other.fromScreenIndex == fromScreenIndex));
  }

  @override
  int get hashCode => Object.hash(runtimeType, task,
      const DeepCollectionEquality().hash(_allTasks), fromScreenIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$TaskOpenPutTaskScreenStateImplCopyWith<_$TaskOpenPutTaskScreenStateImpl>
      get copyWith => __$$TaskOpenPutTaskScreenStateImplCopyWithImpl<
          _$TaskOpenPutTaskScreenStateImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(
            List<TaskBaseEntity> tasks,
            List<TaskBaseEntity> mostImportanceTasks,
            DateTime? lastImportanceAlgorithmRunTime,
            int initialScreenIndex)
        loaded,
    required TResult Function(
            TaskEntity? task, List<TaskEntity> allTasks, int fromScreenIndex)
        openPutTaskScreen,
  }) {
    return openPutTaskScreen(task, allTasks, fromScreenIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(
            List<TaskBaseEntity> tasks,
            List<TaskBaseEntity> mostImportanceTasks,
            DateTime? lastImportanceAlgorithmRunTime,
            int initialScreenIndex)?
        loaded,
    TResult? Function(
            TaskEntity? task, List<TaskEntity> allTasks, int fromScreenIndex)?
        openPutTaskScreen,
  }) {
    return openPutTaskScreen?.call(task, allTasks, fromScreenIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(
            List<TaskBaseEntity> tasks,
            List<TaskBaseEntity> mostImportanceTasks,
            DateTime? lastImportanceAlgorithmRunTime,
            int initialScreenIndex)?
        loaded,
    TResult Function(
            TaskEntity? task, List<TaskEntity> allTasks, int fromScreenIndex)?
        openPutTaskScreen,
    required TResult orElse(),
  }) {
    if (openPutTaskScreen != null) {
      return openPutTaskScreen(task, allTasks, fromScreenIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_TaskInitialState value) initial,
    required TResult Function(_TaskLoaderShowState value) loaderShow,
    required TResult Function(_TaskLoaderHideState value) loaderHide,
    required TResult Function(_TaskLoadedState value) loaded,
    required TResult Function(_TaskOpenPutTaskScreenState value)
        openPutTaskScreen,
  }) {
    return openPutTaskScreen(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_TaskInitialState value)? initial,
    TResult? Function(_TaskLoaderShowState value)? loaderShow,
    TResult? Function(_TaskLoaderHideState value)? loaderHide,
    TResult? Function(_TaskLoadedState value)? loaded,
    TResult? Function(_TaskOpenPutTaskScreenState value)? openPutTaskScreen,
  }) {
    return openPutTaskScreen?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_TaskInitialState value)? initial,
    TResult Function(_TaskLoaderShowState value)? loaderShow,
    TResult Function(_TaskLoaderHideState value)? loaderHide,
    TResult Function(_TaskLoadedState value)? loaded,
    TResult Function(_TaskOpenPutTaskScreenState value)? openPutTaskScreen,
    required TResult orElse(),
  }) {
    if (openPutTaskScreen != null) {
      return openPutTaskScreen(this);
    }
    return orElse();
  }
}

abstract class _TaskOpenPutTaskScreenState implements TaskState {
  const factory _TaskOpenPutTaskScreenState(
      {required final TaskEntity? task,
      required final List<TaskEntity> allTasks,
      required final int fromScreenIndex}) = _$TaskOpenPutTaskScreenStateImpl;

  TaskEntity? get task;
  List<TaskEntity> get allTasks;
  int get fromScreenIndex;
  @JsonKey(ignore: true)
  _$$TaskOpenPutTaskScreenStateImplCopyWith<_$TaskOpenPutTaskScreenStateImpl>
      get copyWith => throw _privateConstructorUsedError;
}
