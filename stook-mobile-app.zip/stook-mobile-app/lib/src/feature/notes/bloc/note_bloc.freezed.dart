// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'note_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$NoteEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function(int? noteId, int fromScreenIndex) putNote,
    required TResult Function(int noteId, int fromScreenIndex) deleteNote,
    required TResult Function(Note note, int fromScreenIndex) savePuttedNote,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function(int? noteId, int fromScreenIndex)? putNote,
    TResult? Function(int noteId, int fromScreenIndex)? deleteNote,
    TResult? Function(Note note, int fromScreenIndex)? savePuttedNote,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function(int? noteId, int fromScreenIndex)? putNote,
    TResult Function(int noteId, int fromScreenIndex)? deleteNote,
    TResult Function(Note note, int fromScreenIndex)? savePuttedNote,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Load value) load,
    required TResult Function(_PutNote value) putNote,
    required TResult Function(_DeleteNote value) deleteNote,
    required TResult Function(_SavePuttedNote value) savePuttedNote,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Load value)? load,
    TResult? Function(_PutNote value)? putNote,
    TResult? Function(_DeleteNote value)? deleteNote,
    TResult? Function(_SavePuttedNote value)? savePuttedNote,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Load value)? load,
    TResult Function(_PutNote value)? putNote,
    TResult Function(_DeleteNote value)? deleteNote,
    TResult Function(_SavePuttedNote value)? savePuttedNote,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $NoteEventCopyWith<$Res> {
  factory $NoteEventCopyWith(NoteEvent value, $Res Function(NoteEvent) then) =
      _$NoteEventCopyWithImpl<$Res, NoteEvent>;
}

/// @nodoc
class _$NoteEventCopyWithImpl<$Res, $Val extends NoteEvent>
    implements $NoteEventCopyWith<$Res> {
  _$NoteEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$LoadImplCopyWith<$Res> {
  factory _$$LoadImplCopyWith(
          _$LoadImpl value, $Res Function(_$LoadImpl) then) =
      __$$LoadImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$LoadImplCopyWithImpl<$Res>
    extends _$NoteEventCopyWithImpl<$Res, _$LoadImpl>
    implements _$$LoadImplCopyWith<$Res> {
  __$$LoadImplCopyWithImpl(_$LoadImpl _value, $Res Function(_$LoadImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$LoadImpl implements _Load {
  const _$LoadImpl();

  @override
  String toString() {
    return 'NoteEvent.load()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$LoadImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function(int? noteId, int fromScreenIndex) putNote,
    required TResult Function(int noteId, int fromScreenIndex) deleteNote,
    required TResult Function(Note note, int fromScreenIndex) savePuttedNote,
  }) {
    return load();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function(int? noteId, int fromScreenIndex)? putNote,
    TResult? Function(int noteId, int fromScreenIndex)? deleteNote,
    TResult? Function(Note note, int fromScreenIndex)? savePuttedNote,
  }) {
    return load?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function(int? noteId, int fromScreenIndex)? putNote,
    TResult Function(int noteId, int fromScreenIndex)? deleteNote,
    TResult Function(Note note, int fromScreenIndex)? savePuttedNote,
    required TResult orElse(),
  }) {
    if (load != null) {
      return load();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Load value) load,
    required TResult Function(_PutNote value) putNote,
    required TResult Function(_DeleteNote value) deleteNote,
    required TResult Function(_SavePuttedNote value) savePuttedNote,
  }) {
    return load(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Load value)? load,
    TResult? Function(_PutNote value)? putNote,
    TResult? Function(_DeleteNote value)? deleteNote,
    TResult? Function(_SavePuttedNote value)? savePuttedNote,
  }) {
    return load?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Load value)? load,
    TResult Function(_PutNote value)? putNote,
    TResult Function(_DeleteNote value)? deleteNote,
    TResult Function(_SavePuttedNote value)? savePuttedNote,
    required TResult orElse(),
  }) {
    if (load != null) {
      return load(this);
    }
    return orElse();
  }
}

abstract class _Load implements NoteEvent {
  const factory _Load() = _$LoadImpl;
}

/// @nodoc
abstract class _$$PutNoteImplCopyWith<$Res> {
  factory _$$PutNoteImplCopyWith(
          _$PutNoteImpl value, $Res Function(_$PutNoteImpl) then) =
      __$$PutNoteImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int? noteId, int fromScreenIndex});
}

/// @nodoc
class __$$PutNoteImplCopyWithImpl<$Res>
    extends _$NoteEventCopyWithImpl<$Res, _$PutNoteImpl>
    implements _$$PutNoteImplCopyWith<$Res> {
  __$$PutNoteImplCopyWithImpl(
      _$PutNoteImpl _value, $Res Function(_$PutNoteImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? noteId = freezed,
    Object? fromScreenIndex = null,
  }) {
    return _then(_$PutNoteImpl(
      noteId: freezed == noteId
          ? _value.noteId
          : noteId // ignore: cast_nullable_to_non_nullable
              as int?,
      fromScreenIndex: null == fromScreenIndex
          ? _value.fromScreenIndex
          : fromScreenIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$PutNoteImpl implements _PutNote {
  const _$PutNoteImpl({required this.noteId, required this.fromScreenIndex});

  @override
  final int? noteId;
  @override
  final int fromScreenIndex;

  @override
  String toString() {
    return 'NoteEvent.putNote(noteId: $noteId, fromScreenIndex: $fromScreenIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PutNoteImpl &&
            (identical(other.noteId, noteId) || other.noteId == noteId) &&
            (identical(other.fromScreenIndex, fromScreenIndex) ||
                other.fromScreenIndex == fromScreenIndex));
  }

  @override
  int get hashCode => Object.hash(runtimeType, noteId, fromScreenIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PutNoteImplCopyWith<_$PutNoteImpl> get copyWith =>
      __$$PutNoteImplCopyWithImpl<_$PutNoteImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function(int? noteId, int fromScreenIndex) putNote,
    required TResult Function(int noteId, int fromScreenIndex) deleteNote,
    required TResult Function(Note note, int fromScreenIndex) savePuttedNote,
  }) {
    return putNote(noteId, fromScreenIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function(int? noteId, int fromScreenIndex)? putNote,
    TResult? Function(int noteId, int fromScreenIndex)? deleteNote,
    TResult? Function(Note note, int fromScreenIndex)? savePuttedNote,
  }) {
    return putNote?.call(noteId, fromScreenIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function(int? noteId, int fromScreenIndex)? putNote,
    TResult Function(int noteId, int fromScreenIndex)? deleteNote,
    TResult Function(Note note, int fromScreenIndex)? savePuttedNote,
    required TResult orElse(),
  }) {
    if (putNote != null) {
      return putNote(noteId, fromScreenIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Load value) load,
    required TResult Function(_PutNote value) putNote,
    required TResult Function(_DeleteNote value) deleteNote,
    required TResult Function(_SavePuttedNote value) savePuttedNote,
  }) {
    return putNote(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Load value)? load,
    TResult? Function(_PutNote value)? putNote,
    TResult? Function(_DeleteNote value)? deleteNote,
    TResult? Function(_SavePuttedNote value)? savePuttedNote,
  }) {
    return putNote?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Load value)? load,
    TResult Function(_PutNote value)? putNote,
    TResult Function(_DeleteNote value)? deleteNote,
    TResult Function(_SavePuttedNote value)? savePuttedNote,
    required TResult orElse(),
  }) {
    if (putNote != null) {
      return putNote(this);
    }
    return orElse();
  }
}

abstract class _PutNote implements NoteEvent {
  const factory _PutNote(
      {required final int? noteId,
      required final int fromScreenIndex}) = _$PutNoteImpl;

  int? get noteId;
  int get fromScreenIndex;
  @JsonKey(ignore: true)
  _$$PutNoteImplCopyWith<_$PutNoteImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$DeleteNoteImplCopyWith<$Res> {
  factory _$$DeleteNoteImplCopyWith(
          _$DeleteNoteImpl value, $Res Function(_$DeleteNoteImpl) then) =
      __$$DeleteNoteImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int noteId, int fromScreenIndex});
}

/// @nodoc
class __$$DeleteNoteImplCopyWithImpl<$Res>
    extends _$NoteEventCopyWithImpl<$Res, _$DeleteNoteImpl>
    implements _$$DeleteNoteImplCopyWith<$Res> {
  __$$DeleteNoteImplCopyWithImpl(
      _$DeleteNoteImpl _value, $Res Function(_$DeleteNoteImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? noteId = null,
    Object? fromScreenIndex = null,
  }) {
    return _then(_$DeleteNoteImpl(
      noteId: null == noteId
          ? _value.noteId
          : noteId // ignore: cast_nullable_to_non_nullable
              as int,
      fromScreenIndex: null == fromScreenIndex
          ? _value.fromScreenIndex
          : fromScreenIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$DeleteNoteImpl implements _DeleteNote {
  const _$DeleteNoteImpl({required this.noteId, required this.fromScreenIndex});

  @override
  final int noteId;
  @override
  final int fromScreenIndex;

  @override
  String toString() {
    return 'NoteEvent.deleteNote(noteId: $noteId, fromScreenIndex: $fromScreenIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DeleteNoteImpl &&
            (identical(other.noteId, noteId) || other.noteId == noteId) &&
            (identical(other.fromScreenIndex, fromScreenIndex) ||
                other.fromScreenIndex == fromScreenIndex));
  }

  @override
  int get hashCode => Object.hash(runtimeType, noteId, fromScreenIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$DeleteNoteImplCopyWith<_$DeleteNoteImpl> get copyWith =>
      __$$DeleteNoteImplCopyWithImpl<_$DeleteNoteImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function(int? noteId, int fromScreenIndex) putNote,
    required TResult Function(int noteId, int fromScreenIndex) deleteNote,
    required TResult Function(Note note, int fromScreenIndex) savePuttedNote,
  }) {
    return deleteNote(noteId, fromScreenIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function(int? noteId, int fromScreenIndex)? putNote,
    TResult? Function(int noteId, int fromScreenIndex)? deleteNote,
    TResult? Function(Note note, int fromScreenIndex)? savePuttedNote,
  }) {
    return deleteNote?.call(noteId, fromScreenIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function(int? noteId, int fromScreenIndex)? putNote,
    TResult Function(int noteId, int fromScreenIndex)? deleteNote,
    TResult Function(Note note, int fromScreenIndex)? savePuttedNote,
    required TResult orElse(),
  }) {
    if (deleteNote != null) {
      return deleteNote(noteId, fromScreenIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Load value) load,
    required TResult Function(_PutNote value) putNote,
    required TResult Function(_DeleteNote value) deleteNote,
    required TResult Function(_SavePuttedNote value) savePuttedNote,
  }) {
    return deleteNote(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Load value)? load,
    TResult? Function(_PutNote value)? putNote,
    TResult? Function(_DeleteNote value)? deleteNote,
    TResult? Function(_SavePuttedNote value)? savePuttedNote,
  }) {
    return deleteNote?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Load value)? load,
    TResult Function(_PutNote value)? putNote,
    TResult Function(_DeleteNote value)? deleteNote,
    TResult Function(_SavePuttedNote value)? savePuttedNote,
    required TResult orElse(),
  }) {
    if (deleteNote != null) {
      return deleteNote(this);
    }
    return orElse();
  }
}

abstract class _DeleteNote implements NoteEvent {
  const factory _DeleteNote(
      {required final int noteId,
      required final int fromScreenIndex}) = _$DeleteNoteImpl;

  int get noteId;
  int get fromScreenIndex;
  @JsonKey(ignore: true)
  _$$DeleteNoteImplCopyWith<_$DeleteNoteImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SavePuttedNoteImplCopyWith<$Res> {
  factory _$$SavePuttedNoteImplCopyWith(_$SavePuttedNoteImpl value,
          $Res Function(_$SavePuttedNoteImpl) then) =
      __$$SavePuttedNoteImplCopyWithImpl<$Res>;
  @useResult
  $Res call({Note note, int fromScreenIndex});
}

/// @nodoc
class __$$SavePuttedNoteImplCopyWithImpl<$Res>
    extends _$NoteEventCopyWithImpl<$Res, _$SavePuttedNoteImpl>
    implements _$$SavePuttedNoteImplCopyWith<$Res> {
  __$$SavePuttedNoteImplCopyWithImpl(
      _$SavePuttedNoteImpl _value, $Res Function(_$SavePuttedNoteImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? note = null,
    Object? fromScreenIndex = null,
  }) {
    return _then(_$SavePuttedNoteImpl(
      note: null == note
          ? _value.note
          : note // ignore: cast_nullable_to_non_nullable
              as Note,
      fromScreenIndex: null == fromScreenIndex
          ? _value.fromScreenIndex
          : fromScreenIndex // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$SavePuttedNoteImpl implements _SavePuttedNote {
  const _$SavePuttedNoteImpl(
      {required this.note, required this.fromScreenIndex});

  @override
  final Note note;
  @override
  final int fromScreenIndex;

  @override
  String toString() {
    return 'NoteEvent.savePuttedNote(note: $note, fromScreenIndex: $fromScreenIndex)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SavePuttedNoteImpl &&
            (identical(other.note, note) || other.note == note) &&
            (identical(other.fromScreenIndex, fromScreenIndex) ||
                other.fromScreenIndex == fromScreenIndex));
  }

  @override
  int get hashCode => Object.hash(runtimeType, note, fromScreenIndex);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SavePuttedNoteImplCopyWith<_$SavePuttedNoteImpl> get copyWith =>
      __$$SavePuttedNoteImplCopyWithImpl<_$SavePuttedNoteImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function(int? noteId, int fromScreenIndex) putNote,
    required TResult Function(int noteId, int fromScreenIndex) deleteNote,
    required TResult Function(Note note, int fromScreenIndex) savePuttedNote,
  }) {
    return savePuttedNote(note, fromScreenIndex);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function(int? noteId, int fromScreenIndex)? putNote,
    TResult? Function(int noteId, int fromScreenIndex)? deleteNote,
    TResult? Function(Note note, int fromScreenIndex)? savePuttedNote,
  }) {
    return savePuttedNote?.call(note, fromScreenIndex);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function(int? noteId, int fromScreenIndex)? putNote,
    TResult Function(int noteId, int fromScreenIndex)? deleteNote,
    TResult Function(Note note, int fromScreenIndex)? savePuttedNote,
    required TResult orElse(),
  }) {
    if (savePuttedNote != null) {
      return savePuttedNote(note, fromScreenIndex);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Load value) load,
    required TResult Function(_PutNote value) putNote,
    required TResult Function(_DeleteNote value) deleteNote,
    required TResult Function(_SavePuttedNote value) savePuttedNote,
  }) {
    return savePuttedNote(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Load value)? load,
    TResult? Function(_PutNote value)? putNote,
    TResult? Function(_DeleteNote value)? deleteNote,
    TResult? Function(_SavePuttedNote value)? savePuttedNote,
  }) {
    return savePuttedNote?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Load value)? load,
    TResult Function(_PutNote value)? putNote,
    TResult Function(_DeleteNote value)? deleteNote,
    TResult Function(_SavePuttedNote value)? savePuttedNote,
    required TResult orElse(),
  }) {
    if (savePuttedNote != null) {
      return savePuttedNote(this);
    }
    return orElse();
  }
}

abstract class _SavePuttedNote implements NoteEvent {
  const factory _SavePuttedNote(
      {required final Note note,
      required final int fromScreenIndex}) = _$SavePuttedNoteImpl;

  Note get note;
  int get fromScreenIndex;
  @JsonKey(ignore: true)
  _$$SavePuttedNoteImplCopyWith<_$SavePuttedNoteImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$NoteState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(List<Note> notes) loaded,
    required TResult Function(Note? note) openPutNoteScreen,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(List<Note> notes)? loaded,
    TResult? Function(Note? note)? openPutNoteScreen,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(List<Note> notes)? loaded,
    TResult Function(Note? note)? openPutNoteScreen,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_NoteLoaderShowState value) loaderShow,
    required TResult Function(_NoteLoaderHideState value) loaderHide,
    required TResult Function(_LoadedState value) loaded,
    required TResult Function(_NoteOpenedPutScreen value) openPutNoteScreen,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_NoteLoaderShowState value)? loaderShow,
    TResult? Function(_NoteLoaderHideState value)? loaderHide,
    TResult? Function(_LoadedState value)? loaded,
    TResult? Function(_NoteOpenedPutScreen value)? openPutNoteScreen,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_NoteLoaderShowState value)? loaderShow,
    TResult Function(_NoteLoaderHideState value)? loaderHide,
    TResult Function(_LoadedState value)? loaded,
    TResult Function(_NoteOpenedPutScreen value)? openPutNoteScreen,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $NoteStateCopyWith<$Res> {
  factory $NoteStateCopyWith(NoteState value, $Res Function(NoteState) then) =
      _$NoteStateCopyWithImpl<$Res, NoteState>;
}

/// @nodoc
class _$NoteStateCopyWithImpl<$Res, $Val extends NoteState>
    implements $NoteStateCopyWith<$Res> {
  _$NoteStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$NoteLoaderShowStateImplCopyWith<$Res> {
  factory _$$NoteLoaderShowStateImplCopyWith(_$NoteLoaderShowStateImpl value,
          $Res Function(_$NoteLoaderShowStateImpl) then) =
      __$$NoteLoaderShowStateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$NoteLoaderShowStateImplCopyWithImpl<$Res>
    extends _$NoteStateCopyWithImpl<$Res, _$NoteLoaderShowStateImpl>
    implements _$$NoteLoaderShowStateImplCopyWith<$Res> {
  __$$NoteLoaderShowStateImplCopyWithImpl(_$NoteLoaderShowStateImpl _value,
      $Res Function(_$NoteLoaderShowStateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$NoteLoaderShowStateImpl implements _NoteLoaderShowState {
  const _$NoteLoaderShowStateImpl();

  @override
  String toString() {
    return 'NoteState.loaderShow()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$NoteLoaderShowStateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(List<Note> notes) loaded,
    required TResult Function(Note? note) openPutNoteScreen,
  }) {
    return loaderShow();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(List<Note> notes)? loaded,
    TResult? Function(Note? note)? openPutNoteScreen,
  }) {
    return loaderShow?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(List<Note> notes)? loaded,
    TResult Function(Note? note)? openPutNoteScreen,
    required TResult orElse(),
  }) {
    if (loaderShow != null) {
      return loaderShow();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_NoteLoaderShowState value) loaderShow,
    required TResult Function(_NoteLoaderHideState value) loaderHide,
    required TResult Function(_LoadedState value) loaded,
    required TResult Function(_NoteOpenedPutScreen value) openPutNoteScreen,
  }) {
    return loaderShow(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_NoteLoaderShowState value)? loaderShow,
    TResult? Function(_NoteLoaderHideState value)? loaderHide,
    TResult? Function(_LoadedState value)? loaded,
    TResult? Function(_NoteOpenedPutScreen value)? openPutNoteScreen,
  }) {
    return loaderShow?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_NoteLoaderShowState value)? loaderShow,
    TResult Function(_NoteLoaderHideState value)? loaderHide,
    TResult Function(_LoadedState value)? loaded,
    TResult Function(_NoteOpenedPutScreen value)? openPutNoteScreen,
    required TResult orElse(),
  }) {
    if (loaderShow != null) {
      return loaderShow(this);
    }
    return orElse();
  }
}

abstract class _NoteLoaderShowState implements NoteState {
  const factory _NoteLoaderShowState() = _$NoteLoaderShowStateImpl;
}

/// @nodoc
abstract class _$$NoteLoaderHideStateImplCopyWith<$Res> {
  factory _$$NoteLoaderHideStateImplCopyWith(_$NoteLoaderHideStateImpl value,
          $Res Function(_$NoteLoaderHideStateImpl) then) =
      __$$NoteLoaderHideStateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$NoteLoaderHideStateImplCopyWithImpl<$Res>
    extends _$NoteStateCopyWithImpl<$Res, _$NoteLoaderHideStateImpl>
    implements _$$NoteLoaderHideStateImplCopyWith<$Res> {
  __$$NoteLoaderHideStateImplCopyWithImpl(_$NoteLoaderHideStateImpl _value,
      $Res Function(_$NoteLoaderHideStateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$NoteLoaderHideStateImpl implements _NoteLoaderHideState {
  const _$NoteLoaderHideStateImpl();

  @override
  String toString() {
    return 'NoteState.loaderHide()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$NoteLoaderHideStateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(List<Note> notes) loaded,
    required TResult Function(Note? note) openPutNoteScreen,
  }) {
    return loaderHide();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(List<Note> notes)? loaded,
    TResult? Function(Note? note)? openPutNoteScreen,
  }) {
    return loaderHide?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(List<Note> notes)? loaded,
    TResult Function(Note? note)? openPutNoteScreen,
    required TResult orElse(),
  }) {
    if (loaderHide != null) {
      return loaderHide();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_NoteLoaderShowState value) loaderShow,
    required TResult Function(_NoteLoaderHideState value) loaderHide,
    required TResult Function(_LoadedState value) loaded,
    required TResult Function(_NoteOpenedPutScreen value) openPutNoteScreen,
  }) {
    return loaderHide(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_NoteLoaderShowState value)? loaderShow,
    TResult? Function(_NoteLoaderHideState value)? loaderHide,
    TResult? Function(_LoadedState value)? loaded,
    TResult? Function(_NoteOpenedPutScreen value)? openPutNoteScreen,
  }) {
    return loaderHide?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_NoteLoaderShowState value)? loaderShow,
    TResult Function(_NoteLoaderHideState value)? loaderHide,
    TResult Function(_LoadedState value)? loaded,
    TResult Function(_NoteOpenedPutScreen value)? openPutNoteScreen,
    required TResult orElse(),
  }) {
    if (loaderHide != null) {
      return loaderHide(this);
    }
    return orElse();
  }
}

abstract class _NoteLoaderHideState implements NoteState {
  const factory _NoteLoaderHideState() = _$NoteLoaderHideStateImpl;
}

/// @nodoc
abstract class _$$LoadedStateImplCopyWith<$Res> {
  factory _$$LoadedStateImplCopyWith(
          _$LoadedStateImpl value, $Res Function(_$LoadedStateImpl) then) =
      __$$LoadedStateImplCopyWithImpl<$Res>;
  @useResult
  $Res call({List<Note> notes});
}

/// @nodoc
class __$$LoadedStateImplCopyWithImpl<$Res>
    extends _$NoteStateCopyWithImpl<$Res, _$LoadedStateImpl>
    implements _$$LoadedStateImplCopyWith<$Res> {
  __$$LoadedStateImplCopyWithImpl(
      _$LoadedStateImpl _value, $Res Function(_$LoadedStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? notes = null,
  }) {
    return _then(_$LoadedStateImpl(
      notes: null == notes
          ? _value._notes
          : notes // ignore: cast_nullable_to_non_nullable
              as List<Note>,
    ));
  }
}

/// @nodoc

class _$LoadedStateImpl implements _LoadedState {
  const _$LoadedStateImpl({required final List<Note> notes}) : _notes = notes;

  final List<Note> _notes;
  @override
  List<Note> get notes {
    if (_notes is EqualUnmodifiableListView) return _notes;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_notes);
  }

  @override
  String toString() {
    return 'NoteState.loaded(notes: $notes)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$LoadedStateImpl &&
            const DeepCollectionEquality().equals(other._notes, _notes));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_notes));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$LoadedStateImplCopyWith<_$LoadedStateImpl> get copyWith =>
      __$$LoadedStateImplCopyWithImpl<_$LoadedStateImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(List<Note> notes) loaded,
    required TResult Function(Note? note) openPutNoteScreen,
  }) {
    return loaded(notes);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(List<Note> notes)? loaded,
    TResult? Function(Note? note)? openPutNoteScreen,
  }) {
    return loaded?.call(notes);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(List<Note> notes)? loaded,
    TResult Function(Note? note)? openPutNoteScreen,
    required TResult orElse(),
  }) {
    if (loaded != null) {
      return loaded(notes);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_NoteLoaderShowState value) loaderShow,
    required TResult Function(_NoteLoaderHideState value) loaderHide,
    required TResult Function(_LoadedState value) loaded,
    required TResult Function(_NoteOpenedPutScreen value) openPutNoteScreen,
  }) {
    return loaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_NoteLoaderShowState value)? loaderShow,
    TResult? Function(_NoteLoaderHideState value)? loaderHide,
    TResult? Function(_LoadedState value)? loaded,
    TResult? Function(_NoteOpenedPutScreen value)? openPutNoteScreen,
  }) {
    return loaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_NoteLoaderShowState value)? loaderShow,
    TResult Function(_NoteLoaderHideState value)? loaderHide,
    TResult Function(_LoadedState value)? loaded,
    TResult Function(_NoteOpenedPutScreen value)? openPutNoteScreen,
    required TResult orElse(),
  }) {
    if (loaded != null) {
      return loaded(this);
    }
    return orElse();
  }
}

abstract class _LoadedState implements NoteState {
  const factory _LoadedState({required final List<Note> notes}) =
      _$LoadedStateImpl;

  List<Note> get notes;
  @JsonKey(ignore: true)
  _$$LoadedStateImplCopyWith<_$LoadedStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$NoteOpenedPutScreenImplCopyWith<$Res> {
  factory _$$NoteOpenedPutScreenImplCopyWith(_$NoteOpenedPutScreenImpl value,
          $Res Function(_$NoteOpenedPutScreenImpl) then) =
      __$$NoteOpenedPutScreenImplCopyWithImpl<$Res>;
  @useResult
  $Res call({Note? note});
}

/// @nodoc
class __$$NoteOpenedPutScreenImplCopyWithImpl<$Res>
    extends _$NoteStateCopyWithImpl<$Res, _$NoteOpenedPutScreenImpl>
    implements _$$NoteOpenedPutScreenImplCopyWith<$Res> {
  __$$NoteOpenedPutScreenImplCopyWithImpl(_$NoteOpenedPutScreenImpl _value,
      $Res Function(_$NoteOpenedPutScreenImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? note = freezed,
  }) {
    return _then(_$NoteOpenedPutScreenImpl(
      note: freezed == note
          ? _value.note
          : note // ignore: cast_nullable_to_non_nullable
              as Note?,
    ));
  }
}

/// @nodoc

class _$NoteOpenedPutScreenImpl implements _NoteOpenedPutScreen {
  const _$NoteOpenedPutScreenImpl({required this.note});

  @override
  final Note? note;

  @override
  String toString() {
    return 'NoteState.openPutNoteScreen(note: $note)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$NoteOpenedPutScreenImpl &&
            (identical(other.note, note) || other.note == note));
  }

  @override
  int get hashCode => Object.hash(runtimeType, note);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$NoteOpenedPutScreenImplCopyWith<_$NoteOpenedPutScreenImpl> get copyWith =>
      __$$NoteOpenedPutScreenImplCopyWithImpl<_$NoteOpenedPutScreenImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(List<Note> notes) loaded,
    required TResult Function(Note? note) openPutNoteScreen,
  }) {
    return openPutNoteScreen(note);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(List<Note> notes)? loaded,
    TResult? Function(Note? note)? openPutNoteScreen,
  }) {
    return openPutNoteScreen?.call(note);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(List<Note> notes)? loaded,
    TResult Function(Note? note)? openPutNoteScreen,
    required TResult orElse(),
  }) {
    if (openPutNoteScreen != null) {
      return openPutNoteScreen(note);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_NoteLoaderShowState value) loaderShow,
    required TResult Function(_NoteLoaderHideState value) loaderHide,
    required TResult Function(_LoadedState value) loaded,
    required TResult Function(_NoteOpenedPutScreen value) openPutNoteScreen,
  }) {
    return openPutNoteScreen(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_NoteLoaderShowState value)? loaderShow,
    TResult? Function(_NoteLoaderHideState value)? loaderHide,
    TResult? Function(_LoadedState value)? loaded,
    TResult? Function(_NoteOpenedPutScreen value)? openPutNoteScreen,
  }) {
    return openPutNoteScreen?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_NoteLoaderShowState value)? loaderShow,
    TResult Function(_NoteLoaderHideState value)? loaderHide,
    TResult Function(_LoadedState value)? loaded,
    TResult Function(_NoteOpenedPutScreen value)? openPutNoteScreen,
    required TResult orElse(),
  }) {
    if (openPutNoteScreen != null) {
      return openPutNoteScreen(this);
    }
    return orElse();
  }
}

abstract class _NoteOpenedPutScreen implements NoteState {
  const factory _NoteOpenedPutScreen({required final Note? note}) =
      _$NoteOpenedPutScreenImpl;

  Note? get note;
  @JsonKey(ignore: true)
  _$$NoteOpenedPutScreenImplCopyWith<_$NoteOpenedPutScreenImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
