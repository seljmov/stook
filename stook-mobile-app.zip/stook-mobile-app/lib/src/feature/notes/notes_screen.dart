import 'package:flutter/material.dart';

/// Страница экрана заметок.
class NotesScreen extends StatelessWidget {
  const NotesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('Заметки'),
    );
  }
}
