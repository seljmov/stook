// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'calendar_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$CalendarEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function() openSchedule,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function()? openSchedule,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function()? openSchedule,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_CalendarLoadEvent value) load,
    required TResult Function(_CalendarOpenScheduleEvent value) openSchedule,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_CalendarLoadEvent value)? load,
    TResult? Function(_CalendarOpenScheduleEvent value)? openSchedule,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_CalendarLoadEvent value)? load,
    TResult Function(_CalendarOpenScheduleEvent value)? openSchedule,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CalendarEventCopyWith<$Res> {
  factory $CalendarEventCopyWith(
          CalendarEvent value, $Res Function(CalendarEvent) then) =
      _$CalendarEventCopyWithImpl<$Res, CalendarEvent>;
}

/// @nodoc
class _$CalendarEventCopyWithImpl<$Res, $Val extends CalendarEvent>
    implements $CalendarEventCopyWith<$Res> {
  _$CalendarEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$CalendarLoadEventImplCopyWith<$Res> {
  factory _$$CalendarLoadEventImplCopyWith(_$CalendarLoadEventImpl value,
          $Res Function(_$CalendarLoadEventImpl) then) =
      __$$CalendarLoadEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$CalendarLoadEventImplCopyWithImpl<$Res>
    extends _$CalendarEventCopyWithImpl<$Res, _$CalendarLoadEventImpl>
    implements _$$CalendarLoadEventImplCopyWith<$Res> {
  __$$CalendarLoadEventImplCopyWithImpl(_$CalendarLoadEventImpl _value,
      $Res Function(_$CalendarLoadEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$CalendarLoadEventImpl implements _CalendarLoadEvent {
  const _$CalendarLoadEventImpl();

  @override
  String toString() {
    return 'CalendarEvent.load()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$CalendarLoadEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function() openSchedule,
  }) {
    return load();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function()? openSchedule,
  }) {
    return load?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function()? openSchedule,
    required TResult orElse(),
  }) {
    if (load != null) {
      return load();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_CalendarLoadEvent value) load,
    required TResult Function(_CalendarOpenScheduleEvent value) openSchedule,
  }) {
    return load(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_CalendarLoadEvent value)? load,
    TResult? Function(_CalendarOpenScheduleEvent value)? openSchedule,
  }) {
    return load?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_CalendarLoadEvent value)? load,
    TResult Function(_CalendarOpenScheduleEvent value)? openSchedule,
    required TResult orElse(),
  }) {
    if (load != null) {
      return load(this);
    }
    return orElse();
  }
}

abstract class _CalendarLoadEvent implements CalendarEvent {
  const factory _CalendarLoadEvent() = _$CalendarLoadEventImpl;
}

/// @nodoc
abstract class _$$CalendarOpenScheduleEventImplCopyWith<$Res> {
  factory _$$CalendarOpenScheduleEventImplCopyWith(
          _$CalendarOpenScheduleEventImpl value,
          $Res Function(_$CalendarOpenScheduleEventImpl) then) =
      __$$CalendarOpenScheduleEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$CalendarOpenScheduleEventImplCopyWithImpl<$Res>
    extends _$CalendarEventCopyWithImpl<$Res, _$CalendarOpenScheduleEventImpl>
    implements _$$CalendarOpenScheduleEventImplCopyWith<$Res> {
  __$$CalendarOpenScheduleEventImplCopyWithImpl(
      _$CalendarOpenScheduleEventImpl _value,
      $Res Function(_$CalendarOpenScheduleEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$CalendarOpenScheduleEventImpl implements _CalendarOpenScheduleEvent {
  const _$CalendarOpenScheduleEventImpl();

  @override
  String toString() {
    return 'CalendarEvent.openSchedule()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CalendarOpenScheduleEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function() openSchedule,
  }) {
    return openSchedule();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function()? openSchedule,
  }) {
    return openSchedule?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function()? openSchedule,
    required TResult orElse(),
  }) {
    if (openSchedule != null) {
      return openSchedule();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_CalendarLoadEvent value) load,
    required TResult Function(_CalendarOpenScheduleEvent value) openSchedule,
  }) {
    return openSchedule(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_CalendarLoadEvent value)? load,
    TResult? Function(_CalendarOpenScheduleEvent value)? openSchedule,
  }) {
    return openSchedule?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_CalendarLoadEvent value)? load,
    TResult Function(_CalendarOpenScheduleEvent value)? openSchedule,
    required TResult orElse(),
  }) {
    if (openSchedule != null) {
      return openSchedule(this);
    }
    return orElse();
  }
}

abstract class _CalendarOpenScheduleEvent implements CalendarEvent {
  const factory _CalendarOpenScheduleEvent() = _$CalendarOpenScheduleEventImpl;
}

/// @nodoc
mixin _$CalendarState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(
            List<CalendarDayEntity> days, List<CalendarTaskEntity> tasks)
        loaded,
    required TResult Function() scheduleOpened,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(
            List<CalendarDayEntity> days, List<CalendarTaskEntity> tasks)?
        loaded,
    TResult? Function()? scheduleOpened,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(
            List<CalendarDayEntity> days, List<CalendarTaskEntity> tasks)?
        loaded,
    TResult Function()? scheduleOpened,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_CalendarInitialState value) initial,
    required TResult Function(_CalendarLoaderShowState value) loaderShow,
    required TResult Function(_CalendarLoaderHideState value) loaderHide,
    required TResult Function(_CalendarLoadedState value) loaded,
    required TResult Function(_CalendarScheduleOpenedState value)
        scheduleOpened,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_CalendarInitialState value)? initial,
    TResult? Function(_CalendarLoaderShowState value)? loaderShow,
    TResult? Function(_CalendarLoaderHideState value)? loaderHide,
    TResult? Function(_CalendarLoadedState value)? loaded,
    TResult? Function(_CalendarScheduleOpenedState value)? scheduleOpened,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_CalendarInitialState value)? initial,
    TResult Function(_CalendarLoaderShowState value)? loaderShow,
    TResult Function(_CalendarLoaderHideState value)? loaderHide,
    TResult Function(_CalendarLoadedState value)? loaded,
    TResult Function(_CalendarScheduleOpenedState value)? scheduleOpened,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CalendarStateCopyWith<$Res> {
  factory $CalendarStateCopyWith(
          CalendarState value, $Res Function(CalendarState) then) =
      _$CalendarStateCopyWithImpl<$Res, CalendarState>;
}

/// @nodoc
class _$CalendarStateCopyWithImpl<$Res, $Val extends CalendarState>
    implements $CalendarStateCopyWith<$Res> {
  _$CalendarStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$CalendarInitialStateImplCopyWith<$Res> {
  factory _$$CalendarInitialStateImplCopyWith(_$CalendarInitialStateImpl value,
          $Res Function(_$CalendarInitialStateImpl) then) =
      __$$CalendarInitialStateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$CalendarInitialStateImplCopyWithImpl<$Res>
    extends _$CalendarStateCopyWithImpl<$Res, _$CalendarInitialStateImpl>
    implements _$$CalendarInitialStateImplCopyWith<$Res> {
  __$$CalendarInitialStateImplCopyWithImpl(_$CalendarInitialStateImpl _value,
      $Res Function(_$CalendarInitialStateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$CalendarInitialStateImpl implements _CalendarInitialState {
  const _$CalendarInitialStateImpl();

  @override
  String toString() {
    return 'CalendarState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CalendarInitialStateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(
            List<CalendarDayEntity> days, List<CalendarTaskEntity> tasks)
        loaded,
    required TResult Function() scheduleOpened,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(
            List<CalendarDayEntity> days, List<CalendarTaskEntity> tasks)?
        loaded,
    TResult? Function()? scheduleOpened,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(
            List<CalendarDayEntity> days, List<CalendarTaskEntity> tasks)?
        loaded,
    TResult Function()? scheduleOpened,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_CalendarInitialState value) initial,
    required TResult Function(_CalendarLoaderShowState value) loaderShow,
    required TResult Function(_CalendarLoaderHideState value) loaderHide,
    required TResult Function(_CalendarLoadedState value) loaded,
    required TResult Function(_CalendarScheduleOpenedState value)
        scheduleOpened,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_CalendarInitialState value)? initial,
    TResult? Function(_CalendarLoaderShowState value)? loaderShow,
    TResult? Function(_CalendarLoaderHideState value)? loaderHide,
    TResult? Function(_CalendarLoadedState value)? loaded,
    TResult? Function(_CalendarScheduleOpenedState value)? scheduleOpened,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_CalendarInitialState value)? initial,
    TResult Function(_CalendarLoaderShowState value)? loaderShow,
    TResult Function(_CalendarLoaderHideState value)? loaderHide,
    TResult Function(_CalendarLoadedState value)? loaded,
    TResult Function(_CalendarScheduleOpenedState value)? scheduleOpened,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _CalendarInitialState implements CalendarState {
  const factory _CalendarInitialState() = _$CalendarInitialStateImpl;
}

/// @nodoc
abstract class _$$CalendarLoaderShowStateImplCopyWith<$Res> {
  factory _$$CalendarLoaderShowStateImplCopyWith(
          _$CalendarLoaderShowStateImpl value,
          $Res Function(_$CalendarLoaderShowStateImpl) then) =
      __$$CalendarLoaderShowStateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$CalendarLoaderShowStateImplCopyWithImpl<$Res>
    extends _$CalendarStateCopyWithImpl<$Res, _$CalendarLoaderShowStateImpl>
    implements _$$CalendarLoaderShowStateImplCopyWith<$Res> {
  __$$CalendarLoaderShowStateImplCopyWithImpl(
      _$CalendarLoaderShowStateImpl _value,
      $Res Function(_$CalendarLoaderShowStateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$CalendarLoaderShowStateImpl implements _CalendarLoaderShowState {
  const _$CalendarLoaderShowStateImpl();

  @override
  String toString() {
    return 'CalendarState.loaderShow()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CalendarLoaderShowStateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(
            List<CalendarDayEntity> days, List<CalendarTaskEntity> tasks)
        loaded,
    required TResult Function() scheduleOpened,
  }) {
    return loaderShow();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(
            List<CalendarDayEntity> days, List<CalendarTaskEntity> tasks)?
        loaded,
    TResult? Function()? scheduleOpened,
  }) {
    return loaderShow?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(
            List<CalendarDayEntity> days, List<CalendarTaskEntity> tasks)?
        loaded,
    TResult Function()? scheduleOpened,
    required TResult orElse(),
  }) {
    if (loaderShow != null) {
      return loaderShow();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_CalendarInitialState value) initial,
    required TResult Function(_CalendarLoaderShowState value) loaderShow,
    required TResult Function(_CalendarLoaderHideState value) loaderHide,
    required TResult Function(_CalendarLoadedState value) loaded,
    required TResult Function(_CalendarScheduleOpenedState value)
        scheduleOpened,
  }) {
    return loaderShow(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_CalendarInitialState value)? initial,
    TResult? Function(_CalendarLoaderShowState value)? loaderShow,
    TResult? Function(_CalendarLoaderHideState value)? loaderHide,
    TResult? Function(_CalendarLoadedState value)? loaded,
    TResult? Function(_CalendarScheduleOpenedState value)? scheduleOpened,
  }) {
    return loaderShow?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_CalendarInitialState value)? initial,
    TResult Function(_CalendarLoaderShowState value)? loaderShow,
    TResult Function(_CalendarLoaderHideState value)? loaderHide,
    TResult Function(_CalendarLoadedState value)? loaded,
    TResult Function(_CalendarScheduleOpenedState value)? scheduleOpened,
    required TResult orElse(),
  }) {
    if (loaderShow != null) {
      return loaderShow(this);
    }
    return orElse();
  }
}

abstract class _CalendarLoaderShowState implements CalendarState {
  const factory _CalendarLoaderShowState() = _$CalendarLoaderShowStateImpl;
}

/// @nodoc
abstract class _$$CalendarLoaderHideStateImplCopyWith<$Res> {
  factory _$$CalendarLoaderHideStateImplCopyWith(
          _$CalendarLoaderHideStateImpl value,
          $Res Function(_$CalendarLoaderHideStateImpl) then) =
      __$$CalendarLoaderHideStateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$CalendarLoaderHideStateImplCopyWithImpl<$Res>
    extends _$CalendarStateCopyWithImpl<$Res, _$CalendarLoaderHideStateImpl>
    implements _$$CalendarLoaderHideStateImplCopyWith<$Res> {
  __$$CalendarLoaderHideStateImplCopyWithImpl(
      _$CalendarLoaderHideStateImpl _value,
      $Res Function(_$CalendarLoaderHideStateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$CalendarLoaderHideStateImpl implements _CalendarLoaderHideState {
  const _$CalendarLoaderHideStateImpl();

  @override
  String toString() {
    return 'CalendarState.loaderHide()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CalendarLoaderHideStateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(
            List<CalendarDayEntity> days, List<CalendarTaskEntity> tasks)
        loaded,
    required TResult Function() scheduleOpened,
  }) {
    return loaderHide();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(
            List<CalendarDayEntity> days, List<CalendarTaskEntity> tasks)?
        loaded,
    TResult? Function()? scheduleOpened,
  }) {
    return loaderHide?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(
            List<CalendarDayEntity> days, List<CalendarTaskEntity> tasks)?
        loaded,
    TResult Function()? scheduleOpened,
    required TResult orElse(),
  }) {
    if (loaderHide != null) {
      return loaderHide();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_CalendarInitialState value) initial,
    required TResult Function(_CalendarLoaderShowState value) loaderShow,
    required TResult Function(_CalendarLoaderHideState value) loaderHide,
    required TResult Function(_CalendarLoadedState value) loaded,
    required TResult Function(_CalendarScheduleOpenedState value)
        scheduleOpened,
  }) {
    return loaderHide(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_CalendarInitialState value)? initial,
    TResult? Function(_CalendarLoaderShowState value)? loaderShow,
    TResult? Function(_CalendarLoaderHideState value)? loaderHide,
    TResult? Function(_CalendarLoadedState value)? loaded,
    TResult? Function(_CalendarScheduleOpenedState value)? scheduleOpened,
  }) {
    return loaderHide?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_CalendarInitialState value)? initial,
    TResult Function(_CalendarLoaderShowState value)? loaderShow,
    TResult Function(_CalendarLoaderHideState value)? loaderHide,
    TResult Function(_CalendarLoadedState value)? loaded,
    TResult Function(_CalendarScheduleOpenedState value)? scheduleOpened,
    required TResult orElse(),
  }) {
    if (loaderHide != null) {
      return loaderHide(this);
    }
    return orElse();
  }
}

abstract class _CalendarLoaderHideState implements CalendarState {
  const factory _CalendarLoaderHideState() = _$CalendarLoaderHideStateImpl;
}

/// @nodoc
abstract class _$$CalendarLoadedStateImplCopyWith<$Res> {
  factory _$$CalendarLoadedStateImplCopyWith(_$CalendarLoadedStateImpl value,
          $Res Function(_$CalendarLoadedStateImpl) then) =
      __$$CalendarLoadedStateImplCopyWithImpl<$Res>;
  @useResult
  $Res call({List<CalendarDayEntity> days, List<CalendarTaskEntity> tasks});
}

/// @nodoc
class __$$CalendarLoadedStateImplCopyWithImpl<$Res>
    extends _$CalendarStateCopyWithImpl<$Res, _$CalendarLoadedStateImpl>
    implements _$$CalendarLoadedStateImplCopyWith<$Res> {
  __$$CalendarLoadedStateImplCopyWithImpl(_$CalendarLoadedStateImpl _value,
      $Res Function(_$CalendarLoadedStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? days = null,
    Object? tasks = null,
  }) {
    return _then(_$CalendarLoadedStateImpl(
      days: null == days
          ? _value._days
          : days // ignore: cast_nullable_to_non_nullable
              as List<CalendarDayEntity>,
      tasks: null == tasks
          ? _value._tasks
          : tasks // ignore: cast_nullable_to_non_nullable
              as List<CalendarTaskEntity>,
    ));
  }
}

/// @nodoc

class _$CalendarLoadedStateImpl implements _CalendarLoadedState {
  const _$CalendarLoadedStateImpl(
      {required final List<CalendarDayEntity> days,
      required final List<CalendarTaskEntity> tasks})
      : _days = days,
        _tasks = tasks;

  final List<CalendarDayEntity> _days;
  @override
  List<CalendarDayEntity> get days {
    if (_days is EqualUnmodifiableListView) return _days;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_days);
  }

  final List<CalendarTaskEntity> _tasks;
  @override
  List<CalendarTaskEntity> get tasks {
    if (_tasks is EqualUnmodifiableListView) return _tasks;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_tasks);
  }

  @override
  String toString() {
    return 'CalendarState.loaded(days: $days, tasks: $tasks)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CalendarLoadedStateImpl &&
            const DeepCollectionEquality().equals(other._days, _days) &&
            const DeepCollectionEquality().equals(other._tasks, _tasks));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_days),
      const DeepCollectionEquality().hash(_tasks));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CalendarLoadedStateImplCopyWith<_$CalendarLoadedStateImpl> get copyWith =>
      __$$CalendarLoadedStateImplCopyWithImpl<_$CalendarLoadedStateImpl>(
          this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(
            List<CalendarDayEntity> days, List<CalendarTaskEntity> tasks)
        loaded,
    required TResult Function() scheduleOpened,
  }) {
    return loaded(days, tasks);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(
            List<CalendarDayEntity> days, List<CalendarTaskEntity> tasks)?
        loaded,
    TResult? Function()? scheduleOpened,
  }) {
    return loaded?.call(days, tasks);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(
            List<CalendarDayEntity> days, List<CalendarTaskEntity> tasks)?
        loaded,
    TResult Function()? scheduleOpened,
    required TResult orElse(),
  }) {
    if (loaded != null) {
      return loaded(days, tasks);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_CalendarInitialState value) initial,
    required TResult Function(_CalendarLoaderShowState value) loaderShow,
    required TResult Function(_CalendarLoaderHideState value) loaderHide,
    required TResult Function(_CalendarLoadedState value) loaded,
    required TResult Function(_CalendarScheduleOpenedState value)
        scheduleOpened,
  }) {
    return loaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_CalendarInitialState value)? initial,
    TResult? Function(_CalendarLoaderShowState value)? loaderShow,
    TResult? Function(_CalendarLoaderHideState value)? loaderHide,
    TResult? Function(_CalendarLoadedState value)? loaded,
    TResult? Function(_CalendarScheduleOpenedState value)? scheduleOpened,
  }) {
    return loaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_CalendarInitialState value)? initial,
    TResult Function(_CalendarLoaderShowState value)? loaderShow,
    TResult Function(_CalendarLoaderHideState value)? loaderHide,
    TResult Function(_CalendarLoadedState value)? loaded,
    TResult Function(_CalendarScheduleOpenedState value)? scheduleOpened,
    required TResult orElse(),
  }) {
    if (loaded != null) {
      return loaded(this);
    }
    return orElse();
  }
}

abstract class _CalendarLoadedState implements CalendarState {
  const factory _CalendarLoadedState(
          {required final List<CalendarDayEntity> days,
          required final List<CalendarTaskEntity> tasks}) =
      _$CalendarLoadedStateImpl;

  List<CalendarDayEntity> get days;
  List<CalendarTaskEntity> get tasks;
  @JsonKey(ignore: true)
  _$$CalendarLoadedStateImplCopyWith<_$CalendarLoadedStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$CalendarScheduleOpenedStateImplCopyWith<$Res> {
  factory _$$CalendarScheduleOpenedStateImplCopyWith(
          _$CalendarScheduleOpenedStateImpl value,
          $Res Function(_$CalendarScheduleOpenedStateImpl) then) =
      __$$CalendarScheduleOpenedStateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$CalendarScheduleOpenedStateImplCopyWithImpl<$Res>
    extends _$CalendarStateCopyWithImpl<$Res, _$CalendarScheduleOpenedStateImpl>
    implements _$$CalendarScheduleOpenedStateImplCopyWith<$Res> {
  __$$CalendarScheduleOpenedStateImplCopyWithImpl(
      _$CalendarScheduleOpenedStateImpl _value,
      $Res Function(_$CalendarScheduleOpenedStateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$CalendarScheduleOpenedStateImpl
    implements _CalendarScheduleOpenedState {
  const _$CalendarScheduleOpenedStateImpl();

  @override
  String toString() {
    return 'CalendarState.scheduleOpened()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CalendarScheduleOpenedStateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(
            List<CalendarDayEntity> days, List<CalendarTaskEntity> tasks)
        loaded,
    required TResult Function() scheduleOpened,
  }) {
    return scheduleOpened();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(
            List<CalendarDayEntity> days, List<CalendarTaskEntity> tasks)?
        loaded,
    TResult? Function()? scheduleOpened,
  }) {
    return scheduleOpened?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(
            List<CalendarDayEntity> days, List<CalendarTaskEntity> tasks)?
        loaded,
    TResult Function()? scheduleOpened,
    required TResult orElse(),
  }) {
    if (scheduleOpened != null) {
      return scheduleOpened();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_CalendarInitialState value) initial,
    required TResult Function(_CalendarLoaderShowState value) loaderShow,
    required TResult Function(_CalendarLoaderHideState value) loaderHide,
    required TResult Function(_CalendarLoadedState value) loaded,
    required TResult Function(_CalendarScheduleOpenedState value)
        scheduleOpened,
  }) {
    return scheduleOpened(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_CalendarInitialState value)? initial,
    TResult? Function(_CalendarLoaderShowState value)? loaderShow,
    TResult? Function(_CalendarLoaderHideState value)? loaderHide,
    TResult? Function(_CalendarLoadedState value)? loaded,
    TResult? Function(_CalendarScheduleOpenedState value)? scheduleOpened,
  }) {
    return scheduleOpened?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_CalendarInitialState value)? initial,
    TResult Function(_CalendarLoaderShowState value)? loaderShow,
    TResult Function(_CalendarLoaderHideState value)? loaderHide,
    TResult Function(_CalendarLoadedState value)? loaded,
    TResult Function(_CalendarScheduleOpenedState value)? scheduleOpened,
    required TResult orElse(),
  }) {
    if (scheduleOpened != null) {
      return scheduleOpened(this);
    }
    return orElse();
  }
}

abstract class _CalendarScheduleOpenedState implements CalendarState {
  const factory _CalendarScheduleOpenedState() =
      _$CalendarScheduleOpenedStateImpl;
}
