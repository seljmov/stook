// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'schedule_put_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$SchedulePutEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function(int currentWeekNumber, List<WeekEntity> weeks)
        save,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function(int currentWeekNumber, List<WeekEntity> weeks)? save,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function(int currentWeekNumber, List<WeekEntity> weeks)? save,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SchedulePutLoadEvent value) load,
    required TResult Function(_SchedulePutSaveEvent value) save,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SchedulePutLoadEvent value)? load,
    TResult? Function(_SchedulePutSaveEvent value)? save,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SchedulePutLoadEvent value)? load,
    TResult Function(_SchedulePutSaveEvent value)? save,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SchedulePutEventCopyWith<$Res> {
  factory $SchedulePutEventCopyWith(
          SchedulePutEvent value, $Res Function(SchedulePutEvent) then) =
      _$SchedulePutEventCopyWithImpl<$Res, SchedulePutEvent>;
}

/// @nodoc
class _$SchedulePutEventCopyWithImpl<$Res, $Val extends SchedulePutEvent>
    implements $SchedulePutEventCopyWith<$Res> {
  _$SchedulePutEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$SchedulePutLoadEventImplCopyWith<$Res> {
  factory _$$SchedulePutLoadEventImplCopyWith(_$SchedulePutLoadEventImpl value,
          $Res Function(_$SchedulePutLoadEventImpl) then) =
      __$$SchedulePutLoadEventImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$SchedulePutLoadEventImplCopyWithImpl<$Res>
    extends _$SchedulePutEventCopyWithImpl<$Res, _$SchedulePutLoadEventImpl>
    implements _$$SchedulePutLoadEventImplCopyWith<$Res> {
  __$$SchedulePutLoadEventImplCopyWithImpl(_$SchedulePutLoadEventImpl _value,
      $Res Function(_$SchedulePutLoadEventImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$SchedulePutLoadEventImpl implements _SchedulePutLoadEvent {
  const _$SchedulePutLoadEventImpl();

  @override
  String toString() {
    return 'SchedulePutEvent.load()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SchedulePutLoadEventImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function(int currentWeekNumber, List<WeekEntity> weeks)
        save,
  }) {
    return load();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function(int currentWeekNumber, List<WeekEntity> weeks)? save,
  }) {
    return load?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function(int currentWeekNumber, List<WeekEntity> weeks)? save,
    required TResult orElse(),
  }) {
    if (load != null) {
      return load();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SchedulePutLoadEvent value) load,
    required TResult Function(_SchedulePutSaveEvent value) save,
  }) {
    return load(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SchedulePutLoadEvent value)? load,
    TResult? Function(_SchedulePutSaveEvent value)? save,
  }) {
    return load?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SchedulePutLoadEvent value)? load,
    TResult Function(_SchedulePutSaveEvent value)? save,
    required TResult orElse(),
  }) {
    if (load != null) {
      return load(this);
    }
    return orElse();
  }
}

abstract class _SchedulePutLoadEvent implements SchedulePutEvent {
  const factory _SchedulePutLoadEvent() = _$SchedulePutLoadEventImpl;
}

/// @nodoc
abstract class _$$SchedulePutSaveEventImplCopyWith<$Res> {
  factory _$$SchedulePutSaveEventImplCopyWith(_$SchedulePutSaveEventImpl value,
          $Res Function(_$SchedulePutSaveEventImpl) then) =
      __$$SchedulePutSaveEventImplCopyWithImpl<$Res>;
  @useResult
  $Res call({int currentWeekNumber, List<WeekEntity> weeks});
}

/// @nodoc
class __$$SchedulePutSaveEventImplCopyWithImpl<$Res>
    extends _$SchedulePutEventCopyWithImpl<$Res, _$SchedulePutSaveEventImpl>
    implements _$$SchedulePutSaveEventImplCopyWith<$Res> {
  __$$SchedulePutSaveEventImplCopyWithImpl(_$SchedulePutSaveEventImpl _value,
      $Res Function(_$SchedulePutSaveEventImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? currentWeekNumber = null,
    Object? weeks = null,
  }) {
    return _then(_$SchedulePutSaveEventImpl(
      currentWeekNumber: null == currentWeekNumber
          ? _value.currentWeekNumber
          : currentWeekNumber // ignore: cast_nullable_to_non_nullable
              as int,
      weeks: null == weeks
          ? _value._weeks
          : weeks // ignore: cast_nullable_to_non_nullable
              as List<WeekEntity>,
    ));
  }
}

/// @nodoc

class _$SchedulePutSaveEventImpl implements _SchedulePutSaveEvent {
  const _$SchedulePutSaveEventImpl(
      {required this.currentWeekNumber, required final List<WeekEntity> weeks})
      : _weeks = weeks;

  @override
  final int currentWeekNumber;
  final List<WeekEntity> _weeks;
  @override
  List<WeekEntity> get weeks {
    if (_weeks is EqualUnmodifiableListView) return _weeks;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_weeks);
  }

  @override
  String toString() {
    return 'SchedulePutEvent.save(currentWeekNumber: $currentWeekNumber, weeks: $weeks)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SchedulePutSaveEventImpl &&
            (identical(other.currentWeekNumber, currentWeekNumber) ||
                other.currentWeekNumber == currentWeekNumber) &&
            const DeepCollectionEquality().equals(other._weeks, _weeks));
  }

  @override
  int get hashCode => Object.hash(runtimeType, currentWeekNumber,
      const DeepCollectionEquality().hash(_weeks));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SchedulePutSaveEventImplCopyWith<_$SchedulePutSaveEventImpl>
      get copyWith =>
          __$$SchedulePutSaveEventImplCopyWithImpl<_$SchedulePutSaveEventImpl>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() load,
    required TResult Function(int currentWeekNumber, List<WeekEntity> weeks)
        save,
  }) {
    return save(currentWeekNumber, weeks);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? load,
    TResult? Function(int currentWeekNumber, List<WeekEntity> weeks)? save,
  }) {
    return save?.call(currentWeekNumber, weeks);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? load,
    TResult Function(int currentWeekNumber, List<WeekEntity> weeks)? save,
    required TResult orElse(),
  }) {
    if (save != null) {
      return save(currentWeekNumber, weeks);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SchedulePutLoadEvent value) load,
    required TResult Function(_SchedulePutSaveEvent value) save,
  }) {
    return save(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SchedulePutLoadEvent value)? load,
    TResult? Function(_SchedulePutSaveEvent value)? save,
  }) {
    return save?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SchedulePutLoadEvent value)? load,
    TResult Function(_SchedulePutSaveEvent value)? save,
    required TResult orElse(),
  }) {
    if (save != null) {
      return save(this);
    }
    return orElse();
  }
}

abstract class _SchedulePutSaveEvent implements SchedulePutEvent {
  const factory _SchedulePutSaveEvent(
      {required final int currentWeekNumber,
      required final List<WeekEntity> weeks}) = _$SchedulePutSaveEventImpl;

  int get currentWeekNumber;
  List<WeekEntity> get weeks;
  @JsonKey(ignore: true)
  _$$SchedulePutSaveEventImplCopyWith<_$SchedulePutSaveEventImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$SchedulePutState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(List<WeekEntity> weeks) loaded,
    required TResult Function() successUpdate,
    required TResult Function(String message) errorUpdate,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(List<WeekEntity> weeks)? loaded,
    TResult? Function()? successUpdate,
    TResult? Function(String message)? errorUpdate,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(List<WeekEntity> weeks)? loaded,
    TResult Function()? successUpdate,
    TResult Function(String message)? errorUpdate,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SchedulePutInitialState value) initial,
    required TResult Function(_SchedulePutLoaderShowState value) loaderShow,
    required TResult Function(_SchedulePutLoaderHideState value) loaderHide,
    required TResult Function(_SchedulePutLoadedState value) loaded,
    required TResult Function(_SchedulePutSuccessUpdateState value)
        successUpdate,
    required TResult Function(_SchedulePutErrorUpdateState value) errorUpdate,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SchedulePutInitialState value)? initial,
    TResult? Function(_SchedulePutLoaderShowState value)? loaderShow,
    TResult? Function(_SchedulePutLoaderHideState value)? loaderHide,
    TResult? Function(_SchedulePutLoadedState value)? loaded,
    TResult? Function(_SchedulePutSuccessUpdateState value)? successUpdate,
    TResult? Function(_SchedulePutErrorUpdateState value)? errorUpdate,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SchedulePutInitialState value)? initial,
    TResult Function(_SchedulePutLoaderShowState value)? loaderShow,
    TResult Function(_SchedulePutLoaderHideState value)? loaderHide,
    TResult Function(_SchedulePutLoadedState value)? loaded,
    TResult Function(_SchedulePutSuccessUpdateState value)? successUpdate,
    TResult Function(_SchedulePutErrorUpdateState value)? errorUpdate,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SchedulePutStateCopyWith<$Res> {
  factory $SchedulePutStateCopyWith(
          SchedulePutState value, $Res Function(SchedulePutState) then) =
      _$SchedulePutStateCopyWithImpl<$Res, SchedulePutState>;
}

/// @nodoc
class _$SchedulePutStateCopyWithImpl<$Res, $Val extends SchedulePutState>
    implements $SchedulePutStateCopyWith<$Res> {
  _$SchedulePutStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$SchedulePutInitialStateImplCopyWith<$Res> {
  factory _$$SchedulePutInitialStateImplCopyWith(
          _$SchedulePutInitialStateImpl value,
          $Res Function(_$SchedulePutInitialStateImpl) then) =
      __$$SchedulePutInitialStateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$SchedulePutInitialStateImplCopyWithImpl<$Res>
    extends _$SchedulePutStateCopyWithImpl<$Res, _$SchedulePutInitialStateImpl>
    implements _$$SchedulePutInitialStateImplCopyWith<$Res> {
  __$$SchedulePutInitialStateImplCopyWithImpl(
      _$SchedulePutInitialStateImpl _value,
      $Res Function(_$SchedulePutInitialStateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$SchedulePutInitialStateImpl implements _SchedulePutInitialState {
  const _$SchedulePutInitialStateImpl();

  @override
  String toString() {
    return 'SchedulePutState.initial()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SchedulePutInitialStateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(List<WeekEntity> weeks) loaded,
    required TResult Function() successUpdate,
    required TResult Function(String message) errorUpdate,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(List<WeekEntity> weeks)? loaded,
    TResult? Function()? successUpdate,
    TResult? Function(String message)? errorUpdate,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(List<WeekEntity> weeks)? loaded,
    TResult Function()? successUpdate,
    TResult Function(String message)? errorUpdate,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SchedulePutInitialState value) initial,
    required TResult Function(_SchedulePutLoaderShowState value) loaderShow,
    required TResult Function(_SchedulePutLoaderHideState value) loaderHide,
    required TResult Function(_SchedulePutLoadedState value) loaded,
    required TResult Function(_SchedulePutSuccessUpdateState value)
        successUpdate,
    required TResult Function(_SchedulePutErrorUpdateState value) errorUpdate,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SchedulePutInitialState value)? initial,
    TResult? Function(_SchedulePutLoaderShowState value)? loaderShow,
    TResult? Function(_SchedulePutLoaderHideState value)? loaderHide,
    TResult? Function(_SchedulePutLoadedState value)? loaded,
    TResult? Function(_SchedulePutSuccessUpdateState value)? successUpdate,
    TResult? Function(_SchedulePutErrorUpdateState value)? errorUpdate,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SchedulePutInitialState value)? initial,
    TResult Function(_SchedulePutLoaderShowState value)? loaderShow,
    TResult Function(_SchedulePutLoaderHideState value)? loaderHide,
    TResult Function(_SchedulePutLoadedState value)? loaded,
    TResult Function(_SchedulePutSuccessUpdateState value)? successUpdate,
    TResult Function(_SchedulePutErrorUpdateState value)? errorUpdate,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _SchedulePutInitialState implements SchedulePutState {
  const factory _SchedulePutInitialState() = _$SchedulePutInitialStateImpl;
}

/// @nodoc
abstract class _$$SchedulePutLoaderShowStateImplCopyWith<$Res> {
  factory _$$SchedulePutLoaderShowStateImplCopyWith(
          _$SchedulePutLoaderShowStateImpl value,
          $Res Function(_$SchedulePutLoaderShowStateImpl) then) =
      __$$SchedulePutLoaderShowStateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$SchedulePutLoaderShowStateImplCopyWithImpl<$Res>
    extends _$SchedulePutStateCopyWithImpl<$Res,
        _$SchedulePutLoaderShowStateImpl>
    implements _$$SchedulePutLoaderShowStateImplCopyWith<$Res> {
  __$$SchedulePutLoaderShowStateImplCopyWithImpl(
      _$SchedulePutLoaderShowStateImpl _value,
      $Res Function(_$SchedulePutLoaderShowStateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$SchedulePutLoaderShowStateImpl implements _SchedulePutLoaderShowState {
  const _$SchedulePutLoaderShowStateImpl();

  @override
  String toString() {
    return 'SchedulePutState.loaderShow()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SchedulePutLoaderShowStateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(List<WeekEntity> weeks) loaded,
    required TResult Function() successUpdate,
    required TResult Function(String message) errorUpdate,
  }) {
    return loaderShow();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(List<WeekEntity> weeks)? loaded,
    TResult? Function()? successUpdate,
    TResult? Function(String message)? errorUpdate,
  }) {
    return loaderShow?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(List<WeekEntity> weeks)? loaded,
    TResult Function()? successUpdate,
    TResult Function(String message)? errorUpdate,
    required TResult orElse(),
  }) {
    if (loaderShow != null) {
      return loaderShow();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SchedulePutInitialState value) initial,
    required TResult Function(_SchedulePutLoaderShowState value) loaderShow,
    required TResult Function(_SchedulePutLoaderHideState value) loaderHide,
    required TResult Function(_SchedulePutLoadedState value) loaded,
    required TResult Function(_SchedulePutSuccessUpdateState value)
        successUpdate,
    required TResult Function(_SchedulePutErrorUpdateState value) errorUpdate,
  }) {
    return loaderShow(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SchedulePutInitialState value)? initial,
    TResult? Function(_SchedulePutLoaderShowState value)? loaderShow,
    TResult? Function(_SchedulePutLoaderHideState value)? loaderHide,
    TResult? Function(_SchedulePutLoadedState value)? loaded,
    TResult? Function(_SchedulePutSuccessUpdateState value)? successUpdate,
    TResult? Function(_SchedulePutErrorUpdateState value)? errorUpdate,
  }) {
    return loaderShow?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SchedulePutInitialState value)? initial,
    TResult Function(_SchedulePutLoaderShowState value)? loaderShow,
    TResult Function(_SchedulePutLoaderHideState value)? loaderHide,
    TResult Function(_SchedulePutLoadedState value)? loaded,
    TResult Function(_SchedulePutSuccessUpdateState value)? successUpdate,
    TResult Function(_SchedulePutErrorUpdateState value)? errorUpdate,
    required TResult orElse(),
  }) {
    if (loaderShow != null) {
      return loaderShow(this);
    }
    return orElse();
  }
}

abstract class _SchedulePutLoaderShowState implements SchedulePutState {
  const factory _SchedulePutLoaderShowState() =
      _$SchedulePutLoaderShowStateImpl;
}

/// @nodoc
abstract class _$$SchedulePutLoaderHideStateImplCopyWith<$Res> {
  factory _$$SchedulePutLoaderHideStateImplCopyWith(
          _$SchedulePutLoaderHideStateImpl value,
          $Res Function(_$SchedulePutLoaderHideStateImpl) then) =
      __$$SchedulePutLoaderHideStateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$SchedulePutLoaderHideStateImplCopyWithImpl<$Res>
    extends _$SchedulePutStateCopyWithImpl<$Res,
        _$SchedulePutLoaderHideStateImpl>
    implements _$$SchedulePutLoaderHideStateImplCopyWith<$Res> {
  __$$SchedulePutLoaderHideStateImplCopyWithImpl(
      _$SchedulePutLoaderHideStateImpl _value,
      $Res Function(_$SchedulePutLoaderHideStateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$SchedulePutLoaderHideStateImpl implements _SchedulePutLoaderHideState {
  const _$SchedulePutLoaderHideStateImpl();

  @override
  String toString() {
    return 'SchedulePutState.loaderHide()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SchedulePutLoaderHideStateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(List<WeekEntity> weeks) loaded,
    required TResult Function() successUpdate,
    required TResult Function(String message) errorUpdate,
  }) {
    return loaderHide();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(List<WeekEntity> weeks)? loaded,
    TResult? Function()? successUpdate,
    TResult? Function(String message)? errorUpdate,
  }) {
    return loaderHide?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(List<WeekEntity> weeks)? loaded,
    TResult Function()? successUpdate,
    TResult Function(String message)? errorUpdate,
    required TResult orElse(),
  }) {
    if (loaderHide != null) {
      return loaderHide();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SchedulePutInitialState value) initial,
    required TResult Function(_SchedulePutLoaderShowState value) loaderShow,
    required TResult Function(_SchedulePutLoaderHideState value) loaderHide,
    required TResult Function(_SchedulePutLoadedState value) loaded,
    required TResult Function(_SchedulePutSuccessUpdateState value)
        successUpdate,
    required TResult Function(_SchedulePutErrorUpdateState value) errorUpdate,
  }) {
    return loaderHide(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SchedulePutInitialState value)? initial,
    TResult? Function(_SchedulePutLoaderShowState value)? loaderShow,
    TResult? Function(_SchedulePutLoaderHideState value)? loaderHide,
    TResult? Function(_SchedulePutLoadedState value)? loaded,
    TResult? Function(_SchedulePutSuccessUpdateState value)? successUpdate,
    TResult? Function(_SchedulePutErrorUpdateState value)? errorUpdate,
  }) {
    return loaderHide?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SchedulePutInitialState value)? initial,
    TResult Function(_SchedulePutLoaderShowState value)? loaderShow,
    TResult Function(_SchedulePutLoaderHideState value)? loaderHide,
    TResult Function(_SchedulePutLoadedState value)? loaded,
    TResult Function(_SchedulePutSuccessUpdateState value)? successUpdate,
    TResult Function(_SchedulePutErrorUpdateState value)? errorUpdate,
    required TResult orElse(),
  }) {
    if (loaderHide != null) {
      return loaderHide(this);
    }
    return orElse();
  }
}

abstract class _SchedulePutLoaderHideState implements SchedulePutState {
  const factory _SchedulePutLoaderHideState() =
      _$SchedulePutLoaderHideStateImpl;
}

/// @nodoc
abstract class _$$SchedulePutLoadedStateImplCopyWith<$Res> {
  factory _$$SchedulePutLoadedStateImplCopyWith(
          _$SchedulePutLoadedStateImpl value,
          $Res Function(_$SchedulePutLoadedStateImpl) then) =
      __$$SchedulePutLoadedStateImplCopyWithImpl<$Res>;
  @useResult
  $Res call({List<WeekEntity> weeks});
}

/// @nodoc
class __$$SchedulePutLoadedStateImplCopyWithImpl<$Res>
    extends _$SchedulePutStateCopyWithImpl<$Res, _$SchedulePutLoadedStateImpl>
    implements _$$SchedulePutLoadedStateImplCopyWith<$Res> {
  __$$SchedulePutLoadedStateImplCopyWithImpl(
      _$SchedulePutLoadedStateImpl _value,
      $Res Function(_$SchedulePutLoadedStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? weeks = null,
  }) {
    return _then(_$SchedulePutLoadedStateImpl(
      weeks: null == weeks
          ? _value._weeks
          : weeks // ignore: cast_nullable_to_non_nullable
              as List<WeekEntity>,
    ));
  }
}

/// @nodoc

class _$SchedulePutLoadedStateImpl implements _SchedulePutLoadedState {
  const _$SchedulePutLoadedStateImpl({required final List<WeekEntity> weeks})
      : _weeks = weeks;

  final List<WeekEntity> _weeks;
  @override
  List<WeekEntity> get weeks {
    if (_weeks is EqualUnmodifiableListView) return _weeks;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_weeks);
  }

  @override
  String toString() {
    return 'SchedulePutState.loaded(weeks: $weeks)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SchedulePutLoadedStateImpl &&
            const DeepCollectionEquality().equals(other._weeks, _weeks));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_weeks));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SchedulePutLoadedStateImplCopyWith<_$SchedulePutLoadedStateImpl>
      get copyWith => __$$SchedulePutLoadedStateImplCopyWithImpl<
          _$SchedulePutLoadedStateImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(List<WeekEntity> weeks) loaded,
    required TResult Function() successUpdate,
    required TResult Function(String message) errorUpdate,
  }) {
    return loaded(weeks);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(List<WeekEntity> weeks)? loaded,
    TResult? Function()? successUpdate,
    TResult? Function(String message)? errorUpdate,
  }) {
    return loaded?.call(weeks);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(List<WeekEntity> weeks)? loaded,
    TResult Function()? successUpdate,
    TResult Function(String message)? errorUpdate,
    required TResult orElse(),
  }) {
    if (loaded != null) {
      return loaded(weeks);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SchedulePutInitialState value) initial,
    required TResult Function(_SchedulePutLoaderShowState value) loaderShow,
    required TResult Function(_SchedulePutLoaderHideState value) loaderHide,
    required TResult Function(_SchedulePutLoadedState value) loaded,
    required TResult Function(_SchedulePutSuccessUpdateState value)
        successUpdate,
    required TResult Function(_SchedulePutErrorUpdateState value) errorUpdate,
  }) {
    return loaded(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SchedulePutInitialState value)? initial,
    TResult? Function(_SchedulePutLoaderShowState value)? loaderShow,
    TResult? Function(_SchedulePutLoaderHideState value)? loaderHide,
    TResult? Function(_SchedulePutLoadedState value)? loaded,
    TResult? Function(_SchedulePutSuccessUpdateState value)? successUpdate,
    TResult? Function(_SchedulePutErrorUpdateState value)? errorUpdate,
  }) {
    return loaded?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SchedulePutInitialState value)? initial,
    TResult Function(_SchedulePutLoaderShowState value)? loaderShow,
    TResult Function(_SchedulePutLoaderHideState value)? loaderHide,
    TResult Function(_SchedulePutLoadedState value)? loaded,
    TResult Function(_SchedulePutSuccessUpdateState value)? successUpdate,
    TResult Function(_SchedulePutErrorUpdateState value)? errorUpdate,
    required TResult orElse(),
  }) {
    if (loaded != null) {
      return loaded(this);
    }
    return orElse();
  }
}

abstract class _SchedulePutLoadedState implements SchedulePutState {
  const factory _SchedulePutLoadedState(
      {required final List<WeekEntity> weeks}) = _$SchedulePutLoadedStateImpl;

  List<WeekEntity> get weeks;
  @JsonKey(ignore: true)
  _$$SchedulePutLoadedStateImplCopyWith<_$SchedulePutLoadedStateImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SchedulePutSuccessUpdateStateImplCopyWith<$Res> {
  factory _$$SchedulePutSuccessUpdateStateImplCopyWith(
          _$SchedulePutSuccessUpdateStateImpl value,
          $Res Function(_$SchedulePutSuccessUpdateStateImpl) then) =
      __$$SchedulePutSuccessUpdateStateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$SchedulePutSuccessUpdateStateImplCopyWithImpl<$Res>
    extends _$SchedulePutStateCopyWithImpl<$Res,
        _$SchedulePutSuccessUpdateStateImpl>
    implements _$$SchedulePutSuccessUpdateStateImplCopyWith<$Res> {
  __$$SchedulePutSuccessUpdateStateImplCopyWithImpl(
      _$SchedulePutSuccessUpdateStateImpl _value,
      $Res Function(_$SchedulePutSuccessUpdateStateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$SchedulePutSuccessUpdateStateImpl
    implements _SchedulePutSuccessUpdateState {
  const _$SchedulePutSuccessUpdateStateImpl();

  @override
  String toString() {
    return 'SchedulePutState.successUpdate()';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SchedulePutSuccessUpdateStateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(List<WeekEntity> weeks) loaded,
    required TResult Function() successUpdate,
    required TResult Function(String message) errorUpdate,
  }) {
    return successUpdate();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(List<WeekEntity> weeks)? loaded,
    TResult? Function()? successUpdate,
    TResult? Function(String message)? errorUpdate,
  }) {
    return successUpdate?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(List<WeekEntity> weeks)? loaded,
    TResult Function()? successUpdate,
    TResult Function(String message)? errorUpdate,
    required TResult orElse(),
  }) {
    if (successUpdate != null) {
      return successUpdate();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SchedulePutInitialState value) initial,
    required TResult Function(_SchedulePutLoaderShowState value) loaderShow,
    required TResult Function(_SchedulePutLoaderHideState value) loaderHide,
    required TResult Function(_SchedulePutLoadedState value) loaded,
    required TResult Function(_SchedulePutSuccessUpdateState value)
        successUpdate,
    required TResult Function(_SchedulePutErrorUpdateState value) errorUpdate,
  }) {
    return successUpdate(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SchedulePutInitialState value)? initial,
    TResult? Function(_SchedulePutLoaderShowState value)? loaderShow,
    TResult? Function(_SchedulePutLoaderHideState value)? loaderHide,
    TResult? Function(_SchedulePutLoadedState value)? loaded,
    TResult? Function(_SchedulePutSuccessUpdateState value)? successUpdate,
    TResult? Function(_SchedulePutErrorUpdateState value)? errorUpdate,
  }) {
    return successUpdate?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SchedulePutInitialState value)? initial,
    TResult Function(_SchedulePutLoaderShowState value)? loaderShow,
    TResult Function(_SchedulePutLoaderHideState value)? loaderHide,
    TResult Function(_SchedulePutLoadedState value)? loaded,
    TResult Function(_SchedulePutSuccessUpdateState value)? successUpdate,
    TResult Function(_SchedulePutErrorUpdateState value)? errorUpdate,
    required TResult orElse(),
  }) {
    if (successUpdate != null) {
      return successUpdate(this);
    }
    return orElse();
  }
}

abstract class _SchedulePutSuccessUpdateState implements SchedulePutState {
  const factory _SchedulePutSuccessUpdateState() =
      _$SchedulePutSuccessUpdateStateImpl;
}

/// @nodoc
abstract class _$$SchedulePutErrorUpdateStateImplCopyWith<$Res> {
  factory _$$SchedulePutErrorUpdateStateImplCopyWith(
          _$SchedulePutErrorUpdateStateImpl value,
          $Res Function(_$SchedulePutErrorUpdateStateImpl) then) =
      __$$SchedulePutErrorUpdateStateImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String message});
}

/// @nodoc
class __$$SchedulePutErrorUpdateStateImplCopyWithImpl<$Res>
    extends _$SchedulePutStateCopyWithImpl<$Res,
        _$SchedulePutErrorUpdateStateImpl>
    implements _$$SchedulePutErrorUpdateStateImplCopyWith<$Res> {
  __$$SchedulePutErrorUpdateStateImplCopyWithImpl(
      _$SchedulePutErrorUpdateStateImpl _value,
      $Res Function(_$SchedulePutErrorUpdateStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? message = null,
  }) {
    return _then(_$SchedulePutErrorUpdateStateImpl(
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$SchedulePutErrorUpdateStateImpl
    implements _SchedulePutErrorUpdateState {
  const _$SchedulePutErrorUpdateStateImpl({required this.message});

  @override
  final String message;

  @override
  String toString() {
    return 'SchedulePutState.errorUpdate(message: $message)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SchedulePutErrorUpdateStateImpl &&
            (identical(other.message, message) || other.message == message));
  }

  @override
  int get hashCode => Object.hash(runtimeType, message);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SchedulePutErrorUpdateStateImplCopyWith<_$SchedulePutErrorUpdateStateImpl>
      get copyWith => __$$SchedulePutErrorUpdateStateImplCopyWithImpl<
          _$SchedulePutErrorUpdateStateImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() loaderShow,
    required TResult Function() loaderHide,
    required TResult Function(List<WeekEntity> weeks) loaded,
    required TResult Function() successUpdate,
    required TResult Function(String message) errorUpdate,
  }) {
    return errorUpdate(message);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? loaderShow,
    TResult? Function()? loaderHide,
    TResult? Function(List<WeekEntity> weeks)? loaded,
    TResult? Function()? successUpdate,
    TResult? Function(String message)? errorUpdate,
  }) {
    return errorUpdate?.call(message);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? loaderShow,
    TResult Function()? loaderHide,
    TResult Function(List<WeekEntity> weeks)? loaded,
    TResult Function()? successUpdate,
    TResult Function(String message)? errorUpdate,
    required TResult orElse(),
  }) {
    if (errorUpdate != null) {
      return errorUpdate(message);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SchedulePutInitialState value) initial,
    required TResult Function(_SchedulePutLoaderShowState value) loaderShow,
    required TResult Function(_SchedulePutLoaderHideState value) loaderHide,
    required TResult Function(_SchedulePutLoadedState value) loaded,
    required TResult Function(_SchedulePutSuccessUpdateState value)
        successUpdate,
    required TResult Function(_SchedulePutErrorUpdateState value) errorUpdate,
  }) {
    return errorUpdate(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SchedulePutInitialState value)? initial,
    TResult? Function(_SchedulePutLoaderShowState value)? loaderShow,
    TResult? Function(_SchedulePutLoaderHideState value)? loaderHide,
    TResult? Function(_SchedulePutLoadedState value)? loaded,
    TResult? Function(_SchedulePutSuccessUpdateState value)? successUpdate,
    TResult? Function(_SchedulePutErrorUpdateState value)? errorUpdate,
  }) {
    return errorUpdate?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SchedulePutInitialState value)? initial,
    TResult Function(_SchedulePutLoaderShowState value)? loaderShow,
    TResult Function(_SchedulePutLoaderHideState value)? loaderHide,
    TResult Function(_SchedulePutLoadedState value)? loaded,
    TResult Function(_SchedulePutSuccessUpdateState value)? successUpdate,
    TResult Function(_SchedulePutErrorUpdateState value)? errorUpdate,
    required TResult orElse(),
  }) {
    if (errorUpdate != null) {
      return errorUpdate(this);
    }
    return orElse();
  }
}

abstract class _SchedulePutErrorUpdateState implements SchedulePutState {
  const factory _SchedulePutErrorUpdateState({required final String message}) =
      _$SchedulePutErrorUpdateStateImpl;

  String get message;
  @JsonKey(ignore: true)
  _$$SchedulePutErrorUpdateStateImplCopyWith<_$SchedulePutErrorUpdateStateImpl>
      get copyWith => throw _privateConstructorUsedError;
}
